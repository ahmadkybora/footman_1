<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');

/*Auth::routes(['verify' => true]);*/

Route::get('test', 'HomeController@test');

//Route::get('{any}', 'HomeController@index')->where('any', '.*');



Route::get('run-commands', function (){
    //abort(404);

    // Run artisan commands.
    /*\Illuminate\Support\Facades\Artisan::call('storage:link');*/

    // Link storage directory to root of project or server (public_html).
    $target_folder = $_SERVER['DOCUMENT_ROOT'].'/server/core/storage/app/public';
    $link_folder = $_SERVER['DOCUMENT_ROOT'].'/server/storage';
    symlink($target_folder,$link_folder);
    echo 'Symlink Process Successfully Completed';
});
