<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::namespace('Api')->middleware(['cors'])->name('api.')->group(function () {
    /*
    |--------------------------------------------------------------------------
    | Authenticable And Account Routes.
    |--------------------------------------------------------------------------
    */
    Route::middleware(['auth:api'])->group(function () {
        /*
        |--------------------------------------------------------------------------
        | Authenticable Routes Not Related To Specific Account Or Role.
        |--------------------------------------------------------------------------
        */
        Route::post('verify-mobile', 'AuthController@verifyMobile')->name('verify.mobile');
        Route::get('logout', 'AuthController@logout');
        Route::get('test', 'UserController@test');
        /*Route::middleware(['check.mobile'])->group(function () {
            Route::post('reset-password', 'UserController@resetPassword')->middleware('scope:reset-password');
            Route::post('change-password', 'UserController@changePassword');
            Route::patch('update-account', 'UserController@update');
        });*/

        /*
        |--------------------------------------------------------------------------
        | Accounts Routes.
        |--------------------------------------------------------------------------
        */
        Route::prefix('account')->middleware(['verified'])->name('account.')->group(function (){
            /*
            |--------------------------------------------------------------------------
            | Admins Routes.
            |--------------------------------------------------------------------------
            */
            Route::namespace('Admin')->prefix('admin')->middleware(['check.account:admin'])->name('admin.')->group(function (){
                Route::get('users', 'UserController@users');
                Route::resource('user' , 'UserController')->except(['create']);
                Route::resource('ticket' , 'TicketController')->except(['create']);
                Route::patch('ticket/details/{ticket}', 'TicketController@storeDetails');
                Route::resource('product/category', 'ProductCategoryController');
                Route::resource('product/voucher', 'ProductVoucherController');
                Route::resource('product' , 'ProductController')->except(['create', 'edit']);
                Route::resource('product/voucher', 'ProductVoucherController')->except(['index', 'create', 'edit']);
                Route::get('product/voucher/download/{productVoucher}', 'ProductVoucherController@download')->name('download-product-voucher');
                Route::resource('transaction' , 'TransactionController');
                Route::get('transaction/download/{transaction}', 'TransactionController@download')->name('download-transaction');
                Route::resource('order' , 'OrderController')->except(['create', 'store', 'edit', 'update', 'destroy']);
                Route::get('brands', 'BrandController@brands');
                Route::resource('brand', 'BrandController');
                Route::namespace('Setting')->prefix('setting')->middleware([])->name('setting.')->group(function (){
                    Route::resource('role', 'RoleController')->except(['create', 'edit']);
                    Route::get('roles', 'RoleController@roles');
                    Route::get('permissions', 'RoleController@permissions');
                });
            });

            /*
            |--------------------------------------------------------------------------
            | Customers (Sellers And Buyers)Routes.
            |--------------------------------------------------------------------------
            */
            Route::get('/','UserController@show');
            Route::patch('/','UserController@update');
            Route::patch('change-password', 'UserController@changePassword');

            Route::resource('product','ProductController')->except(['edit']);
            Route::resource('product/voucher', 'ProductVoucherController')->except(['index', 'show']);
            Route::get('product/voucher/download/{productVoucher}', 'ProductVoucherController@download')->name('download-product-voucher');

            Route::resource('transaction', 'TransactionController')->except(['create', 'edit']);
            Route::get('transaction/download/{transaction}', 'TransactionController@download')->name('download-transaction');

            Route::get('cart', 'OrderController@cart');
            Route::delete('cart', 'OrderController@cartDelete');
            Route::resource('order', 'OrderController')->except(['create', 'store', 'edit', 'update', 'destroy']);
            Route::get('orders', 'OrderController@orders');
            Route::post('order/cart/add', 'OrderController@addToCart');
            Route::delete('order/cart/remove', 'OrderController@removeFromCart');

            Route::resource('ticket', 'TicketController')->except(['create', 'edit', 'update', 'destroy']);
            Route::get('ticket/details/{ticket}', 'TicketController@indexDetails');
            Route::patch('ticket/details/{ticket}', 'TicketController@storeDetails');

            Route::post('transaction/pay', 'TransactionController@pay');

            Route::resource('seller-ticket', 'SellerTicketController')->except(['create', 'edit', 'update', 'destroy']);
            Route::get('seller-ticket/details/seller', 'SellerTicketController@sellerIndex');
            Route::patch('seller-ticket/details/{SellerTicket}', 'SellerTicketController@storeSellerDetails');

        });
    });

    /*
    |--------------------------------------------------------------------------
    | Public And Non Authenticable Routes.
    |--------------------------------------------------------------------------
    */
    /*
     * Public Routes.
     */
    Route::post('location', 'UserController@location')->name('location');
    Route::get('/', 'HomeController@index');
    Route::get('product/{product}', 'HomeController@product');
    Route::get('product-category/{productCategory:slug}', 'HomeController@productOfCategory');
    Route::get('brands','HomeController@brands');
    Route::get('product-brand/{brand:slug}', 'HomeController@productOfBrand');
    Route::post('filter', 'ProductController@filter');

    /*
     * Authentication Routes.
     */
    Route::post('register', 'AuthController@register');
    Route::post('login', 'AuthController@login');
    Route::get('email/verify/{user:username}/{timestamp}', 'AuthController@verifyEmail')->name('verify.email');
    Route::get('check-auth', 'AuthController@checkAuth')->name('check.auth');
    Route::post('password/recovery', 'AuthController@recoveryPassword');
    Route::post('password/reset', 'AuthController@resetPassword');
});
