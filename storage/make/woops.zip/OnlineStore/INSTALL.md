composer create-project --prefer-dist laravel/laravel RawSystem
Installing laravel/laravel (v7.12.0)
  - Installing laravel/laravel (v7.12.0): Downloading (100%)
Created project in RawSystem
> @php -r "file_exists('.env') || copy('.env.example', '.env');"
Loading composer repositories with package information
Updating dependencies (including require-dev)
Package operations: 97 installs, 0 updates, 0 removals
  - Installing voku/portable-ascii (1.5.2): Downloading (100%)
  - Installing symfony/polyfill-ctype (v1.17.1): Downloading (100%)
  - Installing phpoption/phpoption (1.7.4): Downloading (100%)
  - Installing vlucas/phpdotenv (v4.1.7): Downloading (100%)
  - Installing symfony/css-selector (v5.1.2): Downloading (100%)
  - Installing tijsverkoyen/css-to-inline-styles (2.2.2): Downloading (100%)
  - Installing symfony/polyfill-php80 (v1.17.1): Downloading (100%)
  - Installing symfony/polyfill-mbstring (v1.17.1): Downloading (100%)
  - Installing symfony/var-dumper (v5.1.2): Downloading (100%)
  - Installing symfony/deprecation-contracts (v2.1.2): Downloading (100%)
  - Installing symfony/routing (v5.1.2): Downloading (100%)
  - Installing symfony/process (v5.1.2): Downloading (100%)
  - Installing symfony/polyfill-php72 (v1.17.0): Downloading (100%)
  - Installing symfony/polyfill-intl-idn (v1.17.1): Downloading (100%)
  - Installing symfony/mime (v5.1.2): Downloading (100%)
  - Installing psr/log (1.1.3): Downloading (100%)
  - Installing symfony/polyfill-php73 (v1.17.1): Downloading (100%)
  - Installing symfony/http-foundation (v5.1.2): Downloading (100%)
  - Installing psr/event-dispatcher (1.0.0): Downloading (100%)
  - Installing symfony/event-dispatcher-contracts (v2.1.2): Downloading (100%)
  - Installing symfony/event-dispatcher (v5.1.2): Downloading (100%)
  - Installing symfony/error-handler (v5.1.2): Downloading (100%)
  - Installing symfony/http-kernel (v5.1.2): Downloading (100%)
  - Installing symfony/finder (v5.1.2): Downloading (100%)
  - Installing symfony/polyfill-intl-normalizer (v1.17.1): Downloading (100%)
  - Installing symfony/polyfill-intl-grapheme (v1.17.1): Downloading (100%)
  - Installing symfony/string (v5.1.2): Downloading (100%)
  - Installing psr/container (1.0.0): Downloading (100%)
  - Installing symfony/service-contracts (v2.1.2): Downloading (100%)
  - Installing symfony/console (v5.1.2): Downloading (100%)
  - Installing symfony/polyfill-iconv (v1.17.1): Downloading (100%)
  - Installing doctrine/lexer (1.2.1): Downloading (100%)
  - Installing egulias/email-validator (2.1.18): Downloading (100%)
  - Installing swiftmailer/swiftmailer (v6.2.3): Downloading (100%)
  - Installing ramsey/collection (1.0.1): Downloading (100%)
  - Installing brick/math (0.8.15): Downloading (100%)
  - Installing ramsey/uuid (4.0.1): Downloading (100%)
  - Installing psr/simple-cache (1.0.1): Downloading (100%)
  - Installing opis/closure (3.5.5): Downloading (100%)
  - Installing symfony/translation-contracts (v2.1.2): Downloading (100%)
  - Installing symfony/translation (v5.1.2): Downloading (100%)
  - Installing nesbot/carbon (2.36.1): Downloading (100%)
  - Installing monolog/monolog (2.1.0): Downloading (100%)
  - Installing league/flysystem (1.0.69): Downloading (100%)
  - Installing league/commonmark (1.5.1): Downloading (100%)
  - Installing dragonmantank/cron-expression (v2.3.0): Downloading (100%)
  - Installing doctrine/inflector (2.0.3): Downloading (100%)
  - Installing laravel/framework (v7.18.0): Downloading (100%)
  - Installing fideloper/proxy (4.4.0): Downloading (100%)
  - Installing asm89/stack-cors (1.3.0): Downloading (100%)
  - Installing fruitcake/laravel-cors (v1.0.6): Downloading (100%)
  - Installing ralouphie/getallheaders (3.0.3): Downloading (100%)
  - Installing psr/http-message (1.0.1): Downloading (100%)
  - Installing guzzlehttp/psr7 (1.6.1): Downloading (100%)
  - Installing guzzlehttp/promises (v1.3.1): Downloading (100%)
  - Installing guzzlehttp/guzzle (6.5.5): Downloading (100%)
  - Installing dnoegel/php-xdg-base-dir (v0.1.1): Downloading (100%)
  - Installing nikic/php-parser (v4.6.0): Downloading (100%)
  - Installing psy/psysh (v0.10.4): Downloading (100%)
  - Installing laravel/tinker (v2.4.0): Downloading (100%)
  - Installing scrivo/highlight.php (v9.18.1.1): Downloading (100%)
  - Installing filp/whoops (2.7.3): Downloading (100%)
  - Installing facade/ignition-contracts (1.0.0): Downloading (100%)
  - Installing facade/flare-client-php (1.3.2): Downloading (100%)
  - Installing facade/ignition (2.0.7): Downloading (100%)
  - Installing fzaninotto/faker (v1.9.1): Downloading (100%)
  - Installing hamcrest/hamcrest-php (v2.0.0): Downloading (100%)
  - Installing mockery/mockery (1.3.1): Downloading (100%)
  - Installing nunomaduro/collision (v4.2.0): Downloading (100%)
  - Installing sebastian/version (2.0.1): Downloading (100%)
  - Installing sebastian/type (1.1.3): Downloading (100%)
  - Installing sebastian/resource-operations (2.0.1): Downloading (100%)
  - Installing sebastian/recursion-context (3.0.0): Downloading (100%)
  - Installing sebastian/object-reflector (1.1.1): Downloading (100%)
  - Installing sebastian/object-enumerator (3.0.3): Downloading (100%)
  - Installing sebastian/global-state (3.0.0): Downloading (100%)
  - Installing sebastian/exporter (3.1.2): Downloading (100%)
  - Installing sebastian/environment (4.2.3): Downloading (100%)
  - Installing sebastian/diff (3.0.2): Downloading (100%)
  - Installing sebastian/comparator (3.0.2): Downloading (100%)
  - Installing phpunit/php-timer (2.1.2): Downloading (100%)
  - Installing phpunit/php-text-template (1.2.1): Downloading (100%)
  - Installing phpunit/php-file-iterator (2.0.2): Downloading (100%)
  - Installing theseer/tokenizer (1.1.3): Downloading (100%)
  - Installing sebastian/code-unit-reverse-lookup (1.0.1): Downloading (100%)
  - Installing phpunit/php-token-stream (3.1.1): Downloading (100%)
  - Installing phpunit/php-code-coverage (7.0.10): Downloading (100%)
  - Installing doctrine/instantiator (1.3.1): Downloading (100%)
  - Installing phpdocumentor/reflection-common (2.2.0): Downloading (100%)
  - Installing webmozart/assert (1.9.0): Downloading (100%)
  - Installing phpdocumentor/type-resolver (1.3.0): Downloading (100%)
  - Installing phpdocumentor/reflection-docblock (5.1.0): Downloading (100%)
  - Installing phpspec/prophecy (v1.10.3): Downloading (100%)
  - Installing phar-io/version (2.0.1): Downloading (100%)
  - Installing phar-io/manifest (1.0.3): Downloading (100%)
  - Installing myclabs/deep-copy (1.10.1): Downloading (100%)
  - Installing phpunit/phpunit (8.5.8): Downloading (100%)
symfony/routing suggests installing symfony/config (For using the all-in-one router or any loader)
symfony/routing suggests installing symfony/yaml (For using the YAML loader)
symfony/routing suggests installing symfony/expression-language (For using expression matching)
symfony/routing suggests installing doctrine/annotations (For using the annotation loader)
symfony/event-dispatcher suggests installing symfony/dependency-injection
symfony/http-kernel suggests installing symfony/browser-kit
symfony/http-kernel suggests installing symfony/config
symfony/http-kernel suggests installing symfony/dependency-injection
symfony/service-contracts suggests installing symfony/service-implementation
symfony/console suggests installing symfony/lock
swiftmailer/swiftmailer suggests installing true/punycode (Needed to support internationalized email addresses, if ext-intl is not installed)
ramsey/uuid suggests installing ext-uuid (Enables the use of PeclUuidTimeGenerator and PeclUuidRandomGenerator.)
ramsey/uuid suggests installing ramsey/uuid-doctrine (Allows the use of Ramsey\Uuid\Uuid as Doctrine field type.)
ramsey/uuid suggests installing paragonie/random-lib (Provides RandomLib for use with the RandomLibAdapter)
symfony/translation suggests installing symfony/config
symfony/translation suggests installing symfony/yaml
monolog/monolog suggests installing graylog2/gelf-php (Allow sending log messages to a GrayLog2 server)
monolog/monolog suggests installing doctrine/couchdb (Allow sending log messages to a CouchDB server)
monolog/monolog suggests installing ruflin/elastica (Allow sending log messages to an Elastic Search server)
monolog/monolog suggests installing elasticsearch/elasticsearch (Allow sending log messages to an Elasticsearch server via official client)
monolog/monolog suggests installing php-amqplib/php-amqplib (Allow sending log messages to an AMQP server using php-amqplib)
monolog/monolog suggests installing ext-amqp (Allow sending log messages to an AMQP server (1.0+ required))
monolog/monolog suggests installing ext-mongodb (Allow sending log messages to a MongoDB server (via driver))
monolog/monolog suggests installing mongodb/mongodb (Allow sending log messages to a MongoDB server (via library))
monolog/monolog suggests installing aws/aws-sdk-php (Allow sending log messages to AWS services like DynamoDB)
monolog/monolog suggests installing rollbar/rollbar (Allow sending log messages to Rollbar)
monolog/monolog suggests installing php-console/php-console (Allow sending log messages to Google Chrome)
league/flysystem suggests installing league/flysystem-eventable-filesystem (Allows you to use EventableFilesystem)
league/flysystem suggests installing league/flysystem-rackspace (Allows you to use Rackspace Cloud Files)
league/flysystem suggests installing league/flysystem-azure (Allows you to use Windows Azure Blob storage)
league/flysystem suggests installing league/flysystem-webdav (Allows you to use WebDAV storage)
league/flysystem suggests installing league/flysystem-aws-s3-v2 (Allows you to use S3 storage with AWS SDK v2)
league/flysystem suggests installing league/flysystem-aws-s3-v3 (Allows you to use S3 storage with AWS SDK v3)
league/flysystem suggests installing spatie/flysystem-dropbox (Allows you to use Dropbox storage)
league/flysystem suggests installing srmklive/flysystem-dropbox-v2 (Allows you to use Dropbox storage for PHP 5 applications)
league/flysystem suggests installing league/flysystem-cached-adapter (Flysystem adapter decorator for metadata caching)
league/flysystem suggests installing ext-ftp (Allows you to use FTP server storage)
league/flysystem suggests installing league/flysystem-sftp (Allows you to use SFTP server storage via phpseclib)
league/flysystem suggests installing league/flysystem-ziparchive (Allows you to use ZipArchive adapter)
laravel/framework suggests installing ext-ftp (Required to use the Flysystem FTP driver.)
laravel/framework suggests installing ext-memcached (Required to use the memcache cache driver.)
laravel/framework suggests installing ext-pcntl (Required to use all features of the queue worker.)
laravel/framework suggests installing ext-posix (Required to use all features of the queue worker.)
laravel/framework suggests installing ext-redis (Required to use the Redis cache and queue drivers (^4.0|^5.0).)
laravel/framework suggests installing aws/aws-sdk-php (Required to use the SQS queue driver, DynamoDb failed job storage and SES mail driver (^3.0).)
laravel/framework suggests installing doctrine/dbal (Required to rename columns and drop SQLite columns (^2.6).)
laravel/framework suggests installing league/flysystem-aws-s3-v3 (Required to use the Flysystem S3 driver (^1.0).)
laravel/framework suggests installing league/flysystem-cached-adapter (Required to use the Flysystem cache (^1.0).)
laravel/framework suggests installing league/flysystem-sftp (Required to use the Flysystem SFTP driver (^1.0).)
laravel/framework suggests installing moontoast/math (Required to use ordered UUIDs (^1.1).)
laravel/framework suggests installing nyholm/psr7 (Required to use PSR-7 bridging features (^1.2).)
laravel/framework suggests installing pda/pheanstalk (Required to use the beanstalk queue driver (^4.0).)
laravel/framework suggests installing pusher/pusher-php-server (Required to use the Pusher broadcast driver (^4.0).)
laravel/framework suggests installing symfony/cache (Required to PSR-6 cache bridge (^5.0).)
laravel/framework suggests installing symfony/filesystem (Required to create relative storage directory symbolic links (^5.0).)
laravel/framework suggests installing symfony/psr-http-message-bridge (Required to use PSR-7 bridging features (^2.0).)
laravel/framework suggests installing wildbit/swiftmailer-postmark (Required to use Postmark mail driver (^3.0).)
guzzlehttp/psr7 suggests installing zendframework/zend-httphandlerrunner (Emit PSR-7 responses)
psy/psysh suggests installing ext-pcntl (Enabling the PCNTL extension makes PsySH a lot happier :))
psy/psysh suggests installing ext-posix (If you have PCNTL, you'll want the POSIX extension as well.)
psy/psysh suggests installing ext-pdo-sqlite (The doc command requires SQLite to work.)
psy/psysh suggests installing hoa/console (A pure PHP readline implementation. You'll want this if your PHP install doesn't already support readline or libedit.)
filp/whoops suggests installing whoops/soap (Formats errors as SOAP responses)
facade/ignition suggests installing laravel/telescope (^3.1)
sebastian/global-state suggests installing ext-uopz (*)
sebastian/environment suggests installing ext-posix (*)
phpunit/php-code-coverage suggests installing ext-xdebug (^2.7.2)
phpunit/phpunit suggests installing phpunit/php-invoker (^2.0.0)
phpunit/phpunit suggests installing ext-xdebug (*)
Writing lock file
Generating optimized autoload files
> Illuminate\Foundation\ComposerScripts::postAutoloadDump
> @php artisan package:discover --ansi
Discovered Package: facade/ignition
Discovered Package: fideloper/proxy
Discovered Package: fruitcake/laravel-cors
Discovered Package: laravel/tinker
Discovered Package: nesbot/carbon
Discovered Package: nunomaduro/collision
Package manifest generated successfully.
> @php artisan key:generate --ansi
Application key set successfully.
---------------------------------------------------------------------------------------------------------------------
Install Verta Package: v1.10.4 - https://hekmatinasser.github.io/verta
    cmd: composer require hekmatinasser/verta
    add following code to config/app.php provider section:
        Hekmatinasser\Verta\VertaServiceProvider::class,
    add following code to config/app.php alias section:
        'Verta' => Hekmatinasser\Verta\Verta::class,
---------------------------------------------------------------------------------------------------------------------
Install LaravelPermission Package: v3.13.0 - https://docs.spatie.be/laravel-permission/v3/installation-laravel
    cmd: composer require spatie/laravel-permission
    add following code to config/app.php provider section:
        Spatie\Permission\PermissionServiceProvider::class,
    cmd: php artisan vendor:publish --provider="Spatie\Permission\PermissionServiceProvider"
    cmd: php artisan migrate