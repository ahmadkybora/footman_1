<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            /*
             * این فیلد در هر دو نوع جدول مختص کاربر و سیستم وجود دارد. منتهی در جدول سفارش مختص کاربر کد جدول تراکنش مختص کاربر و در جدول سفارشات سیستم کد تراکنش سیستم قرار دارد.
             */
            $table->foreignId('transaction_id')->index()->nullable();

            /*
             * خریدار بر روی محصول کلیک کرده و در صفحه اختصاصی آن تعداد کوپن مورد تقاضا را وارد کرده و سپس بر روی دکمه افزودن به سبد خرید کلیک میکند.
             * سپس به این ستون کد محصول و تعداد کوپن های مورد تقاضا از آن محصول افزوده میشود.
             * هر زمان که اقدام به پرداخت سبد خرید نماید از این ستون تعداد کوپن های هر محصول استخراج شده و مقادیر metadata در جدول کوپن ها پر میشود که به معنای خرید قطعی آن کوپن ها است.
             *
             * Data structure:
             *      [[p#, quantity], [p#, quantity], ...]
             */
            $table->text('products');

            $table->decimal('price', 10, 3); // Total price of order.
            $table->foreignId('user_id')->index()->nullable(); // This field is not defined in orders_{x} tables.
            /*
             * هر سفارشی که ثبت میشود در جدول مخصوص سفارشات آن کاربر ثبت خواهد شد.
             * علاوه بر مورد بالا یک رکورد هم در جدول سفارشات سیستم یعنی orders ثبت خواهد شد که منتهی کد سفارش جدول اختصاصی خریدار باید در این فیلد ذخیره شود.
             * این فیلد در جدول مخصوص سفارشات کاربر وجود ندارد.
             *
             * این فیلد به صورت ضمنی بدست می آید. به این معنا که ابتدا از طریق user_id به جدول orders مربوط به کاربر وصل شده و سپس از طریق id جدول order سیستم و فیلد system_order_id جدول order کاربر میتوان به محتوی سفارش کاربر دسترسی پیدا کرد.
             */
            //$table->foreignId('buyer_order_id')->index()->nullable(); // Primary key (id)of each buyer order table (orders_{x} | x = {1, 2, 3, ...})

            /*
             * در صورتیکه وضعیت سفارش بر روی PENDING باشد. سفارش در سبد خرید کاربر نیز علاوه بر لیست سفارشات نمایش داده خواهد شد.
             */
            $table->enum('state', ['PAID', 'CANCELED', 'PENDING'])->nullable();

            $table->dateTime('stated_at')->nullable();
            $table->timestamps();

            $table->foreign('transaction_id')
                ->references('id')->on('transactions')
                ->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
