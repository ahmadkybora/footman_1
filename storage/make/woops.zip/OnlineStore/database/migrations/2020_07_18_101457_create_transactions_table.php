<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        /*
         * شارژ : کاربر کیف پول خود را چه از طریق درگاه و چه دستی (ثبت با رسید) شارژ میکند.
         * لذا تراکنش در جدول سیستم ثبت میشود با نوع CHARGE که اگر از طریق درگاه باشد تایید شده است
         *و اگر دستی باشد باید ادمین تایید کند در صورت تایید شدن فقط کیف پول کاربر شارژ شده است و به کیف پول ادمین کاری ندارد
         */
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('transaction_code')->unique();
            $table->decimal('amount');
            //$table->foreignId('system_transaction_id')->nullable(); // This field is defined just in transactions_{x} tables for each user.
            /*
             * اگر مقدار این فیلد null باشد، یعنی تراکنش مرتبط به حساب شرکت است.
             * اگر این فیلد مقدار داشته باشد یعنی تراکنش مرتبط به حساب کاربر دارای آن id است.
             * این فیلد در جداول تراکنش مختص هر کاربر وجود ندارد و به جای آن فیلد دیگری تعریف میشود.
             *
             *این فیلد نقض قانون بالا شد. یعنی این فیلد در هر صورت کد کاربر را خواهد داشت و از طریق فیلد type متوجه خواهیم شد تراکنش به حساب کاربر واریز شده یا از حساب ایشان حذف گردیده.
             * تراکنش خارج شده از حساب سیستم بالاخره به حساب یک کاربر باید واریز شود. پس این فیلد تهی نخواهد بود.
             */
            $table->foreignId('user_id')->index()->nullable();
            $table->foreignId('last_owner')->nullable();

            /*
             * Dictionary:
             *      DCU: Decreasing Cash Of User
             *      ICU: Increasing Cash Of User
             *
             * CHECKOUT: DCU.
             * CHARGE: ICU.
             */
            $table->enum('type', ['CHARGE', 'CHECKOUT', 'SELL', 'BUY'])->nullable(); // The reason of transaction.

            /*
             * System scheduled robot checks the transactions every special period (for example every night)and performs the related operations and sets the confirmed_at.
             *
             * زمانیکه خریدار پرداختی را انجام بدهد، یک رکورد تراکنش به میزان پرداخت کاربر به جدول transactions که مرتبط با سیستم است اضافه میشود. فیلد confirmed_at این رکورد در لحظه ثبت پر میشود و به کیف پول سیستم مبلغ اضافه میشود.
             * سپس یک رکورد دیگر هم در همین جدول ایجاد میشود که از نوع پرداختی است و فیلد confirmed_at آن null خواهد. این فیلد هم برای گزارشات ادمین است که مشخص کند چقدر واریزی قرار است انجام شود و هم به عنوان تراکنش واریز حق فروشنده.
             * پس از اجرای موفق دو عملیات فوق، مقدار پرداختی کاربر منهای سود شرکت به عنوان یک رکورد تراکنش به جدول تراکنش های مختص فروشنده اضافه میشود. فیلد confirmed_at این رکورد null خواهد بود و فیلد system_transaction_id آن برابر با id تراکنش فوق خواهد بود.
             * سپس ربات زمانبندی شده سیستم در بازه های مشخصی از زمان تراکنش ها را بررسی میکند و تراکنش های مختص فروشنده را تایید کرده و از طریق فیلد system_transaction_id تراکنش های مرتبط با این تراکنش ها را در جدول تراکنشهای سیستم تایید میکند و در نهایت مبلغ تایید شده از کیف پول سیستم کسر شده و به کیف پول فروشنده اضافه میگردد.
             *
             */
            $table->dateTime('confirmed_at')->nullable();

            $table->string('receipt_uri')->nullable();
            //$table->boolean('cashed_in'); // This field is defined just in transactions_{x} tables for each user.
            $table->timestamps();

            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
