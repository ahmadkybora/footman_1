<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductVouchersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_vouchers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->index()->nullable();
            /*
             * One of serial or image_uri is necessary.
             * image_uri is equivalent to serial field.
             */
            $table->string('serial')->nullable();
            $table->string('image_uri')->nullable();

            $table->decimal('purchase_price', 10, 3);
            /*
             * Extra data such as: order_id (id of orders), buyer_order_id (id of orders_{x}) buyer_id (id of users), sold_price.
             * sold_at is the paid_at of orders or orders_{x} tables.
             */
            $table->json('metadata')->nullable();

            $table->timestamps();

            $table->unique(['product_id', 'serial']);
            $table->foreign('product_id')
                ->references('id')->on('products')
                ->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_vouchers');
    }
}
