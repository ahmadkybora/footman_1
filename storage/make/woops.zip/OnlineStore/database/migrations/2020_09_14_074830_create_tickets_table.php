<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTicketsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->longText('body');
            $table->foreignId('user_id')->index()->nullable(); // Ticket (or response of ticket)sender id of users table.
            $table->enum('priority', ['HIGH', 'MEDIUM', 'LOW'])->default('LOW');
            /*
             * Values:
             *      null: system closes the ticket after specific period.
             *      int: any user whether admins or user.
             */
            $table->foreignId('closer_id')->index()->nullable();

            $table->dateTime('seen_at')->nullable();
            $table->timestamps(); // The column 'updated_at' refers to closed datetime.

            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('closer_id')
                ->references('id')->on('users')
                ->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tickets');
    }
}
