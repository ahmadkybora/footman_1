<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWalletsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wallets', function (Blueprint $table) {
            $table->id();
            /*
             * NULL: the wallet owner is the system.
             * Number: the user id of users table.
             */
            $table->foreignId('owner_id')->index()->nullable();
            $table->decimal('credit', 10, 3)->default(0);
            $table->decimal('cash', 10, 3)->default(0);
            $table->enum('state', ['LOCKED', 'NORMAL'])->default('NORMAL');
            $table->dateTime('state_modified_at')->nullable();
            $table->foreignId('state_modifier_id')->index()->nullable();

            $table->timestamps();

            $table->foreign('owner_id')
                ->references('id')->on('users')
                ->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('state_modifier_id')
                ->references('id')->on('users')
                ->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wallets');
    }
}
