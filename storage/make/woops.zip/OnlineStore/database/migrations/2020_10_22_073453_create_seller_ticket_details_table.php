<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSellerTicketDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('seller_ticket_details', function (Blueprint $table) {
            $table->id();
            $table->longText('body');
            $table->foreignId('from_id')->index()->nullable();
            $table->foreignId('to_id')->index()->nullable();
            $table->foreignId('seller_ticket_id')->index()->nullable();
            $table->dateTime('seen_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('seller_ticket_details');
    }
}
