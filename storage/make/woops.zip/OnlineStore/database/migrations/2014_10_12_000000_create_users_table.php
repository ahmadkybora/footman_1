<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\User;
use Illuminate\Support\Facades\Hash;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('mobile')->unique()->nullable();
            $table->dateTime('mobile_verified_at')->nullable();
            $table->string('username')->unique();
            $table->string('postal_code')->nullable();
            $table->string('password');
            $table->foreignId('city_id')->index()->nullable();
            $table->text('home_address')->nullable();
            $table->text('work_address')->nullable();
            //$table->boolean('is_admin')->default(false);
            $table->enum('state', ['ACTIVE', 'INACTIVE', 'SUSPENDED', 'PENDING'])->default('ACTIVE');
            $table->string('secret_key')->unique();
            $table->string('avatar_uri')->nullable();
            /*
             * Save data such as: email_verification_sent_at, mobile_verification_sent_at, ...
             */
            $table->json('metadata')->nullable();

            $table->rememberToken();
            $table->softDeletes();
            $table->timestamps();

            $table->foreign('city_id')
                ->references('id')->on('cities')
                ->onDelete('restrict')->onUpdate('cascade');
        });

        $user = new User();
        $user->first_name = "admin";
        $user->last_name = "admin";
        $user->email = "admin@yahoo.com";
        $user->username = "admin";
        $user->email_verified_at = now();
        $user->secret_key = rand(1,9);
        /**
         *
         * author: 9/14/2020 12:36 PM
         * felan nabayad profile carbari ra ba in user update konid be dalile
         * khata dar relation city
         */
//        $user->city_id = 1;
        $user->password = Hash::make("12345678");
        $user->save();

        $user = new User();
        $user->first_name = "admin_1";
        $user->last_name = "admin_1";
        $user->email = "admin_1@yahoo.com";
        $user->username = "admin_1";
        $user->email_verified_at = now();
        $user->secret_key = rand(1,8);
        /**
         *
         * author: 9/14/2020 12:36 PM
         * felan nabayad profile carbari ra ba in user update konid be dalile
         * khata dar relation city
         */
//        $user->city_id = 1;
        $user->password = Hash::make("12345678");
        $user->save();
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
