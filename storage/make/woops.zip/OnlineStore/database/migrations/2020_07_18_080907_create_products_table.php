<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->index()->nullable();
            $table->foreignId('category_id')->index()->nullable();
            $table->json('price'); // 4 price range
            $table->unsignedInteger('visited')->default(0);
            /*
             * state:
             *      active: admin accepted the product.
             *      inactive: the seller disabled the product.
             *      suspended: admin suspended the product.
             *      null: product is in waiting for review state. then admin must check the product and accept or suspend it.
             */
            $table->enum('state', ['active', 'inactive', 'suspended'])->nullable();

            $table->dateTime('stated_at')->nullable();
            $table->timestamps();

            $table->foreign('user_id')
                ->references('id')->on('users')
                ->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('category_id')
                ->references('id')->on('product_categories')
                ->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
