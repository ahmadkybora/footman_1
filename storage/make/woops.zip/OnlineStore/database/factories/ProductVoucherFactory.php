<?php

/**
 *
 * author : ahmad montazeri
 * @var \Illuminate\Database\Eloquent\Factory $factory
 */

use Faker\Generator as Faker;
use App\ProductVoucher;
use App\Product;

/**
 * algorithm: mr engineer dehghan
 * developer: ahmad montazeri
 */
$factory->define(ProductVoucher::class, function (Faker $faker) {
    $products = Product::all()->toArray();
    $key = array_rand($products);
    $serial = rand(100000,999999);

    $path = ('vouchers');
    if(!\Illuminate\Support\Facades\Storage::exists($path))
        \Illuminate\Support\Facades\Storage::makeDirectory($path);

    $image_uri = storage_path('app/vouchers');

    $dir = $image_uri;
    $width = 800;
    $height = 600;
    $category = 'sports';
    $fullpath = true;
    $randomize = true;
    $word = 'man-ahmad-montazeri-hastam';

    $image_uri = $faker->image($dir, $width, $height, $category,$fullpath, $randomize, $word);

    $purchase_price = rand(1, 1000);
    return [
        'product_id' => $products[$key]['id'],
        'serial' => $serial,
        'image_uri' => $image_uri,
        'purchase_price' => $purchase_price,
    ];
});
