<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Brand;
use App\Model;
use Faker\Generator as Faker;

$names = [];

$factory->define(Brand::class, function (Faker $faker) use(&$names) {
    $brands = Brand::pluck('name')->toArray();
    $names = array_merge($names, $brands);
    return [
        'name' => makeWord($names),
    ];
});

if (!function_exists('makeWord'))
{
    function makeWord(&$names)
    {
        do
        {
            $faker = \Faker\Factory::create();
            $name = $faker->unique()->words(3, true);
        } while (in_array($name, $names));
        $names[] = $name;
        return $name;
    }
}
