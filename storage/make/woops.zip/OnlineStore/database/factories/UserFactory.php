<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\User;
use Faker\Generator as Faker;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/
$names = [];

$factory->define(User::class, function (Faker $faker) use ($names) {
    $users = User::pluck('secret_key')->toArray();
    $names = array_merge($names, $users);
    return [
        'first_name' => $faker->firstName,
        'last_name' => $faker->lastName,
        'email' => time() . $faker->unique()->safeEmail,
        'username' => Str::of($faker->userName)->replace('.', '')->kebab() . time(),
        'email_verified_at' => now(),
        'mobile' => '09' . $faker->numberBetween(100000000, 999999999),
        'password' => Hash::make('12345678'),
        'remember_token' => Str::random(10),
        'state' => 1,
        'secret_key' => Str::kebab(makeWord($names)),
        //'present_code' => uniqid(),
    ];
});

if (!function_exists('makeWord'))
{
    function makeWord(&$names)
    {
        do
        {
            $faker = \Faker\Factory::create();
            $name = $faker->unique()->words(3, true);
        } while (in_array($name, $names));
        $names[] = $name;
        return $name;
    }
}
