<?php

/**
 * author:ahmad montazeri
 * @var \Illuminate\Database\Eloquent\Factory $factory
 */

use App\Brand;
use App\ProductCategory;
use Faker\Generator as Faker;

$names = [];

$factory->define(ProductCategory::class, function (Faker $faker) use($names) {
    $brands = Brand::all()->toArray();
    $categories = ProductCategory::pluck('name')->toArray();
    $key = array_rand($brands);
    $names = array_merge($names, $categories);

    $path = ('public/images/product-categories');
    if(!\Illuminate\Support\Facades\Storage::exists($path)){
        \Illuminate\Support\Facades\Storage::makeDirectory($path);
    }

    $image_uri = storage_path('app/public/images/product-categories');


    $dir = $image_uri;
    $width = 800;
    $height = 600;
    $category = 'sports';
    $fullpath = true;
    $randomize = true;
    $word = 'man-ahmad-montazeri-hastam';

    $image_uri = $faker->image($dir, $width, $height, $category,$fullpath, $randomize, $word);
    return [
        'name' => makeWord($names),
        'brand_id' => $brands[$key]['id'],
        'avatar_uri' => $image_uri,
    ];
});

if (!function_exists('makeWord'))
{
    function makeWord(&$names)
    {
        do
        {
            $faker = \Faker\Factory::create();
            $name = $faker->unique()->words(3, true);
        } while (in_array($name, $names));
        $names[] = $name;
        return $name;
    }
}
