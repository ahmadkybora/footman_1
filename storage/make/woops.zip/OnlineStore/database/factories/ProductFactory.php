<?php

/**
 *
 * author : ahmad montazeri
 * @var \Illuminate\Database\Eloquent\Factory $factory
 */

use Faker\Generator as Faker;
use App\Product;
use App\User;
use App\ProductCategory;

$factory->define(Product::class, function (Faker $faker) {
    $users = User::all()->toArray();
    $categories = ProductCategory::all()->toArray();
    $key_user = array_rand($users);
    $key_category = array_rand($categories);

    $t = rand(1, 100);
    $p = rand(10, 10000);

    $price_1 = [1, $t, $p];
    $price_2 = [$t + 1, ($t + 1) + ($t - 1), $p - 9];
    $price_3 = [($t + 1) + ($t - 1) + 1, ($t + 1) + ($t - 1) + 1 + ($t - 1), $p - 18];
    $price_4 = [($t + 1) + ($t - 1) + 1 + ($t - 1) + 1, ($t + 1) + ($t - 1) + 1 + ($t - 1) + 1 + ($t - 1), $p - 27];

    $prices = [$price_1, $price_2, $price_3, $price_4];

    return [
        'user_id' => $users[$key_user]['id'],
        'category_id' => $categories[$key_category]['id'],
        'price' => $prices,
    ];
});
