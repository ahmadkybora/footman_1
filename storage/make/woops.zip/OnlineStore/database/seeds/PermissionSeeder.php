<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionSeeder extends Seeder
{
    /**
     * Algorithm: elyas dehghan.
     * Development: Sina Khaghani.
     * Created At: 9/28/2020 15:00 by elyas dehghan
     * Modified At: 10/22/2020 11:29 Am by ahmad montazeri.
     *
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissions = ['create-user', 'update-user', 'view-user', 'view-users', 'delete-user', 'create-role'
            , 'update-role', 'view-role', 'view-roles', 'delete-role', 'create-transaction', 'update-transaction'
            , 'view-transaction', 'view-transactions', 'delete-transaction', 'view-ticket', 'view-tickets'
            , 'reply-ticket', 'close-ticket', 'create-product', 'update-product'
            , 'view-product', 'view-products','delete-product', 'view-seller-ticket', 'view-seller-tickets'
            , 'reply-seller-ticket', 'create-voucher', 'update-voucher', 'view-voucher'
            , 'view-vouchers', 'delete-voucher', 'create-order', 'update-order'
            , 'view-orders', 'view-order', 'delete-order', 'create-category', 'update-category'
            , 'view-category', 'view-categories', 'delete-category', 'view-brands', 'view-brand'
            , 'create-brand', 'update-brand', 'delete-brand'];

        foreach ($permissions as $permission)
        {
            $permissionSeed = new Permission();
            $permissionSeed->name = $permission;
            $permissionSeed->guard_name = "api";
            $permissionSeed->save();
        }

        $permissions = Permission::all();
        $role = \Spatie\Permission\Models\Role::find(1);
        $role->givePermissionTo($permissions);
        $role->save();
    }
}
