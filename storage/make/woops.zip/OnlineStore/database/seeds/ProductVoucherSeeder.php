<?php

use Illuminate\Database\Seeder;
use App\ProductVoucher;

class ProductVoucherSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * author : ahmad montazeri
     * @return void
     */
    public function run()
    {
        factory(ProductVoucher::class, 50)->create();
    }
}
