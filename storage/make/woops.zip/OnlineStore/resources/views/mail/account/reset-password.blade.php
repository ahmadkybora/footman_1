@component('mail::message')
<h1>Welcome To D-CodesLand</h1>
<img src="{{ asset('storage/images/system/logo-1.png') }}"><br>
<h1>Reset Your Password</h1>
<p>Dear User {{ $user->first_name }} {{ $user->last_name }}, Please Verify
Your Reset Password Via Click The Bellow Link. If You Don't Reset Your Password In Our Website, Please Do Not
Attention This Mail.</p>

{{--@component('mail::button', ['url' => route('api.password.reset', ['user' => $user->username, 'timestamp' => $timestamp, 'signature' => $signature])])--}}
{{--Reset Your Password Now--}}
{{--@endcomponent--}}

@component('mail::button', ['url' => 'http://d-codesland.ir/#/password/reset?username=' . $user->username . '&timestamp=' . $timestamp . '&signature=' . $signature])
    Reset Your Password Now
@endcomponent

<p>If You Have Problem With Click The Button, You Can Copy And Paste The
Bellow Link In Address Bar Of Browser And Execute It!</p>
{{--<span>{{route('api.password.reset', ['user' => $user->username, 'timestamp' => $timestamp, 'signature' => $signature])}}</span>--}}
<span class="link">{{url('http://localhost:4500/#/password/reset?username=' . $user->username . '&timestamp=' . $timestamp . '&signature=' . $signature)}}</span>
{{--Signature: {{ $signature }}<br>
Time: {{ $timestamp }}<br>
{{ $user->username }}--}}

Thanks,<br>
{{ config('app.name') }}
@endcomponent
