@component('mail::message')
<h1 style="text-align: center; font-weight: bold; width: 400px; max-width: 400px;">Welcome To D-CodesLand</h1>
<img src="{{ asset('storage/images/system/logo-1.png') }}" style="width: 400px;"><br>
<p style="text-align: center; font-weight: bold; margin: 30px 0; width: 400px; max-width: 400px;">Verify Your Email</p>
<p style="width: 400px; max-width: 400px;">Dear User {{ $user->first_name }} {{ $user->last_name }}, Please Verify Your Email Address Via Click The Bellow Link. If You Don't Create Account In Our Website, Please Do Not Attention This Mail.</p>

@component('mail::button', ['url' => route('api.verify.email', ['user' => $user->username, 'timestamp' => $timestamp, 'signature' => $signature])])
    Active Your Account Now
@endcomponent

<p style="width: 400px; max-width: 400px;">If You Have Problem With Click The Button, You Can Copy And Paste The Bellow Link In Address Bar Of Browser And Execute It!</p>
<span style="display: block; width: 400px; max-width: 400px;">{{ route('api.verify.email', ['user' => $user->username, 'timestamp' => $timestamp, 'signature' => $signature]) }}</span>
{{--Signature: {{ $signature }}<br>
Time: {{ $timestamp }}<br>
{{ $user->username }}--}}

Thanks,<br>
{{ config('app.name') }}
@endcomponent
