<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SellerTicketDetail extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'title',
        'description',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'from_id',
        'to_id',
    ];

    /*php ar
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */

    /**
     * Algorithm: sina khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 12:50 Am.
     * Modified At:. 10/22/2020 12:50 by ahmad montazeri.
     *
     * This method sets relation between users and ticket_details.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function sender()
    {
        return $this->belongsTo('App\User', 'from_id');
    }

    /**
     * Algorithm: sina khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 12:50 Am.
     * Modified At:. 10/22/2020 12:50 by ahmad montazeri.
     *
     * This method sets relation between users and ticket_details.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function receiver()
    {
        return $this->belongsTo('App\User', 'receiver_id');
    }

    /**
     * Algorithm: sina khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 12:50 Am.
     * Modified At:. 10/22/2020 12:50 by ahmad montazeri.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function sellerTicket()
    {
        return $this->belongsTo('App\SellerTicket', 'seller_ticket_id');
    }
}
