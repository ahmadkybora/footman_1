<?php

namespace App\Http\Controllers;

use App\Order;
use App\Product;
use App\Transaction;
use App\User;
use App\UserOrder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('front-end.index');
    }

    public function test()
    {
       /* $data = [
            'id' => 1,
            'name' => 'test',
            'email' => 'maillllllllll'
        ];
        $date = "2020-10-14 13:24:10";
        $carbon_date = Carbon::parse($date);
        $date3 = Carbon::now()->setHours(4)->setMinutes(38);
        $date2 = Carbon::parse('-24 hours');
        $date3 = Carbon::now();
        Queue::later($carbon_date,new TransactionJob($data));*/


        //Queue::pushOn('id',new TransactionJob());
        // Test the cash attribute
        /*$user = new User();
        $user->first_name = 'xxx';
        $user->last_name = 'xxx';
        $user->cash = 100;
        $user->email = 'a@a.com';
        $user->username = 'a@a.com';
        $user->password = 'a@a.com';
        $user->secret_key = 'a@a.com';
        return $user->save();*/

        //$user->removeRole('super admin');
        /*
         * Returns the cart of the user. the cart accessor simulates the dynamic attribute for the relation.
         */
        /*$user = User::find(15);
        Auth::loginUsingId(15);
        dd($user->cart);*/

        /*
         * Get all record of user order via the system order.
         */
        /*$t5 = Order::forUser(User::find(15))->where('amount', '>', 100)->get();
        dd($t5);*/

        /*
         * Update user transaction.
         */
        /*$t1 = Order::forUser(15)->where('id', '>', 0)->first();
        $t1->products = serialize([[1, 10], [2, 10]]);
        $t1->price = 3000;
        $t1->state = 'PAID';
        $t1->save();
        dd($t1);*/

        /*
         * Update system and user order.
         */
        /*$t3 = Order::where('id', '>', 0)->first();
        $t3->products = serialize([[1, 10], [2, 10]]);
        $t3->price = 3000;
        $t3->state = 'PAID';
        $t3->save();
        $t3->forUser(15)->save();
        dd($t3);*/

        /*
         * Insert order for system and user.
         */
      /*  $t2 = new Order();
        $t2->products = serialize([[1, 10], [2, 10]]);
        $t2->price = 3000;
        $t2->state = 'PAID';
        $t2->owner()->associate(15);
        $t2->save();
        $t2 = $t2->forUser(15)->save();
        dd($t2);*/


        /*
         * Insert order for user.
         */
        /*$t2 = new Order();
        $t2->products = serialize([[1, 10], [2, 10]]);
        $t2->price = 3000;
        $t2->state = 'PAID';
        $t2->forUser(15)->save();
        dd($t2);*/



        /*
         * The dynamic attribute products can returns all products of the order with their sold vouchers.
         * If this dynamic attribute used as method, the programmer can do eloquent operation on it.
         */
        /*$order = Order::find(1);
        dd($order->products);
        dd($order->products()->where('id', '>', 1)->get());*/




        /*
         * Testing recursive unset.
         */
        /*$x = [
            'hello' => 'H',
            'salam' => 'S',
            'google' => [
                'hello' => 'google hello',
                'goodnight' => 'google good night',
                'ddd',
                'xxx' => [
                    'goodbye' => ['goooood byyy', 'xvision'],
                    'sara' => 'Sara',
                ],
            ],
        ];
        dd($this->filtering($x, ['hello' => 1, 'goodbye' => null]));*/



        /*
         * Get all record of user transaction via the system transaction.
         */
        /*$t5 = Transaction::forUser(User::find(15))->where('amount', '>', 100)->get();
        dd($t5);*/

        /*
         * Update user transaction.
         */
        /*$t1 = Transaction::forUser(15)->where('id', '>', 0)->first();
        $t1->amount = 602;
        $t1->save();
        dd($t1);*/

        /*
         * Update system and user transaction.
         */
        /*$t3 = Transaction::where('id', '>', 0)->first();
        $t3->amount = 777;
        $t3->save();
        $t3->forUser(15)->save();
        dd($t3);*/

        /*
         * Insert transaction for system and user.
         */
        /*$t2 = new Transaction();
        $t2->transaction_code = '222';
        $t2->amount = 3000;
        $t2->owner()->associate(15);
        $t2->save();
        $t2 = $t2->forUser(15)->save();
        dd($t2);*/

        /*
         * Insert transaction for user.
         */
        /*$t2 = new Transaction();
        $t2->transaction_code = '708';
        $t2->amount = 3000;
        $t2->forUser(10)->save();
        dd($t2);*/



        /*
         * Check hash value with base code (for exm: password).
         */
        /*$hash = Hash::make(123);
        dd( Hash::check(123, $hash) );*/

        abort(404);
    }
}
