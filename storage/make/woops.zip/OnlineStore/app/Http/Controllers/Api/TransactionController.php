<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\PaymentRequest;
use App\Http\Requests\TransactionRequest;
use App\Jobs\TransactionJob;
use App\Order;
use App\Product;
use App\ProductVoucher;
use App\Transaction;
use App\UserTransaction;
use App\Http\Controllers\Controller;
use App\Wallet;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Storage;

class TransactionController extends Controller
{
    public $profit = 20; // This variable determines the percentage of system profit in the shopping cart (in method pay)
    /**
     * Display a listing of the resource.
     *
     * author: ahmad montazeri 9/13/2020 2:33 PM
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $transactions = Transaction::paginate(30)->toArray();
        if ($transactions)
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $transactions,
            ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * author: ahmad montazeri 9/13/2020 2:33 PM
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TransactionRequest $request)
    {
        return DB::transaction(function () use ($request) {
            $transaction = new Transaction();
            $transaction->transaction_code = $request->input('serial');
            $transaction->amount = $request->input('amount');
            $transaction->type = "CHARGE";
            if($request->hasFile('receipt_uri'))
            {
                $image = $request->file('receipt_uri');
                $transaction->receipt_uri = Storage::putFile('transactions', $image);
            }
            $transaction->owner()->associate($request->user());
            $system_result = $transaction->save();
            $user_result = /*$transaction->forUser(Auth::user())->save()*/ true;

//            $user_transaction = new UserTransaction();
//            $user_transaction->transaction_code = $request->input('serial');
//            $user_transaction->amount = $request->input('amount');
//            $user_transaction->systemTransaction()->associate($system_transaction);
//            $user_transaction->save();

            if ($system_result and $user_result)
                return response()->json([
                    'state' => true,
                    'message' => "success",
                    'data' => null,
                ], 200);
        });
    }

    /**
     * Display the specified resource.
     *
     * author: ahmad montazeri 9/13/2020 2:33 PM
     *
     * @param  \App\UserTransaction  $transaction
     * @return \Illuminate\Http\Response
     */
    public function show(UserTransaction $transaction)
    {
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $transaction,
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UserTransaction  $transaction
     * @return \Illuminate\Http\Response
     */
    public function edit(UserTransaction $transaction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * author: ahmad montazeri 9/13/2020 2:33 PM
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UserTransaction  $transaction
     * @return \Illuminate\Http\Response
     */
    public function update(TransactionRequest $request, UserTransaction $transaction)
    {
        if(Gate::denies('update', $transaction))
            return response()->json([
                'state' => false,
                'message' => 'forbidden',
                'data' =>null
            ], 403);

        return DB::transaction(function () use ($request, $transaction) {
            $transaction->transaction_code = $request->input('serial');
            $transaction->amount = $request->input('amount');
            if($request->hasFile('receipt_uri'))
            {
                $image = $request->file('receipt_uri');
                $transaction->receipt_uri = Storage::putFile('transactions', $image);
            }
            $user_result = $transaction->save();

            $system_transaction = Transaction::where('id', $transaction->system_transaction_id)->firstOrFail();
            $system_transaction->transaction_code = $request->input('serial');
            $system_transaction->amount = $request->input('amount');
            $system_transaction->last_owner = Auth::id();
            if($request->hasFile('receipt_uri'))
            {
                $image = $request->file('receipt_uri');
                $system_transaction->receipt_uri = Storage::putFile('transactions', $image);
            }

            $system_result = $system_transaction->save();

            if ($system_result and $user_result)
                return response()->json([
                    'state' => true,
                    'message' => "success",
                    'data' => null,
                ], 200);
        });
    }

    /**
     * Remove the specified resource from storage.
     *
     * author: ahmad montazeri 9/13/2020 2:33 PM
     *
     * @param  \App\UserTransaction  $transaction
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserTransaction $transaction)
    {
        if(Gate::denies('delete', $transaction))
            return response()->json([
                'state' => false,
                'message' => 'forbidden',
                'data' => null,
            ], 403);

        return DB::transaction(function () use ($transaction) {
            $system_transaction = Transaction::where('id', $transaction->system_transaction_id)->firstOrFail();
            $system_result = $system_transaction->delete();
            $user_result = $transaction->delete();

            if ($user_result and $system_result)
                return response()->json([
                    'state' => true,
                    'message' => "success",
                    'data' => null,
                ], 200);
        });
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/15/2020 12:00Am.
     * Modified At: 10/15/2020 12:00Am.
     *
     * This method create transaction for system, seller, buyer and update wallets for all and create job for confirm_at for transactions of type=SELL.
     */
    public function pay(PaymentRequest $request)
    {
        $cnt = 0;
        $user =Auth::user();
        $step = count($user->cart->items);
        // این حلقه روی تک تک محصولات سبد خرید مشتری پیمایش می کند
        foreach ($user->cart->items as $item)
        {
            $quantity[] = $item[1];
            if ($cnt<$step)
            {
                // این حلقه بازه ی تعداد محصول را پیمایش می کند سپس تعداد محصول را در قیمت آن بازه ضرب می کند
                foreach ($user->cart->products[$cnt]->price as $price)
                {
                    // این شرط بررسی می کند که اگر تعداد محصول در بازه تعداد محصولات در جدول محصولات قرار داشت قیمت نهایی آن محصول را محاسبه می کند
                    if ($item[1] >= $price[0] and $item[1] <= $price[1])
                    {
                        $product_item_price = $item[1] * $price[2]; // این متغیر مقدار نهایی هر محصول با توجه به بازه ی قیمت اون در جدول محصولات است
                        $product_item_price_all[] =$price[2];
                    }
                }
                // Record transactions for the system for each purchase
                $user_id = $this->findUserIdSeller($item[0]);
                $profit = 100 - $this->profit; // profit system

                // create transaction for seller in model transaction
                $transaction = new Transaction();
                $transaction->transaction_code = rand(1000000, 9999999);
                $transaction->amount = $product_item_price * ($profit / 100); //محاسبه درصد سود شرکت
                $transaction->user_id = $user_id;
                $transaction->last_owner = $user_id;
                $transaction->type = "SELL";
                $transaction->confirmed_at = null;
                $transaction->receipt_uri = null;
                $transaction->save();

                $data[] =$transaction->id;
                $cnt++;
            }
        }
        // ذخیره تراکنشهای فروشنده در صف
        $date =Carbon::now()->addDay(1)->setHours(00);
        Queue::later($date, new TransactionJob($data));

        //update wallet buyer When the user pays
        $user->decreaseCash($request->input('total_price'));
        $user->save();

        // Record the total amount of the user transaction for the system
        $transaction = new Transaction();
        $transaction->transaction_code = rand(1000000,9999999);
        $transaction->amount = $request->input('total_price');
        $transaction->user_id = Auth::id();
        $transaction->type = "BUY";
        $transaction->confirmed_at = Carbon::now();
        $transaction->save();

        //create order of buyer for system
        $order = new Order();
        $order->transaction_id = $transaction->id;
        $order->products = serialize($user->cart->items);
        $order->price = $request->input('total_price');
        $order->user_id = Auth::id();
        $order->state = 'PAID';
        $order->stated_at = Carbon::now();
        $order->save();

        $i=0;
        foreach ($user->cart->products as $product) //این حلقه روی تک تک محصولات پیمایش می کند سپس id رکورد جدول system_order  و id جدول خریدار و قیمت هر محصول در بازه ی تعیین شده ی آن را به صورت json در جدول ProductVoucher ثبت میکند
        {
            $data = [
                'order_id' => $order->id,
                'buyer_order_id' => $user->cart->id,
                'sold_price' => $product_item_price_all[$i],
            ];
            $productVoucher = ProductVoucher::where('product_id', $product->id)->whereNull('metadata')->take($quantity[$i])->update([
                'metadata' => json_encode($data)
            ]);
            $i++;
        }

        //update order buyer
        $cart = $user->cart;
        $cart->state = 'PAID';
        $cart->stated_at = Carbon::now();
        $cart->save();

        //update wallet system for new buy
        $wallet = Wallet::firstOrNew(['owner_id' => null]);
        $wallet->cash += $request->input('total_price');
        $wallet->save();

        if ($wallet)
            return response()->json([
                'state' => true,
                'message' => "success",
                'data' => null,
            ], 200);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/15/2020 12:00Am.
     * Modified At: 10/15/2020 12:00Am.
     *
     * This method find User_id from Products model by product_id
     * @param $id
     * @return mixed
     */
    public function findUserIdSeller($id)
    {
        $product = Product::find($id);
        return $product->user_id;
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 11/01/2020 11:00AM
     * Modified At:
     *
     * @param Transaction $transaction
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function download(UserTransaction $transaction)
    {
        $headers = [
            'Cache-Control'             => 'must-revalidate, post-check=0, pre-check=0',
            'Expires'                   => '0',
            'Pragma'                    => 'public',
            'Content-Type'              =>  Storage::disk('local')->mimeType($transaction->receipt_uri),
            'Content-Disposition'       => 'attachment; filename="' . $transaction->transaction_code . '"',
            'Content-Description'       => 'File Transfer',
            'Content-Transfer-Encoding' => 'binary',
            'Content-Length'            =>  Storage::disk('local')->size($transaction->receipt_uri),
            'Access-Control-Allow-Origin' => "*",
            'Access-Control-Allow-Methods' => "PUT,POST,DELETE,GET,OPTIONS",
            'Access-Control-Allow-Headers' => "Accept,Authorization,Content-Type",
        ];
        return response()->download(storage_path("app/$transaction->receipt_uri"), $transaction->transaction_code, $headers);
    }
}
