<?php

namespace App\Http\Controllers\Api\Admin\Setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/28/2020 4:32Pm.
     * Modified At: .
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Gate::denies('viewAny', Role::class))
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);

        $roles = Role::with('permissions')->paginate(30);
        $roles = $this->filtering($roles->toArray(), [
            'guard_name' => null,
            'pivot' => null
        ]);

        if($roles)
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $roles,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/28/2020 4:32Pm.
     * Modified At: .
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (Gate::denies('create', Role::class))
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);

        $role = $request->input('role');
        $r = new Role();
        $r->name = $role;
        $r->save();
        foreach ($request->input('permissions') as $index => $permission) {
            $r->givePermissionTo($permission);
        }
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => null,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param Role $role
     * @return void
     */
    public function show(Role $role)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Role $role
     * @return void
     */
    public function edit(Role $role)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/28/2020 4:32Pm.
     * Modified At: .
     *
     * @param  \Illuminate\Http\Request $request
     * @param Role $role
     * @return void
     */
    public function update(Request $request, Role $role)
    {
        if (Gate::denies('update', $role))
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);

        $role->syncPermissions($request->input('permissions'));
        $role->name = $request->input('role');

        if($role->save())
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => null,
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/28/2020 4:32Pm.
     * Modified At: .
     *
     * @param Role $role
     * @return void
     */
    public function destroy(Role $role)
    {
        if (Gate::denies('viewAny', $role))
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);

        $role->delete();
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => null,
        ]);
    }

    /**
     * send all permision.
     *
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/28/2020 4:32Pm.
     * Modified At: .
     *
     * @param Role $role
     * @return void
     */
    public function permissions()
    {
        $permissions = Permission::all();
        $permissions = $this->filtering($permissions->toArray(), [
            'guard_name' => null,
            'created_at' => null,
            'updated_at' => null,
        ]);

        if($permissions)
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $permissions,
        ]);
    }

    public function roles()
    {
        $roles = Role::all();

        if($roles)
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $roles,
        ]);
    }
}
