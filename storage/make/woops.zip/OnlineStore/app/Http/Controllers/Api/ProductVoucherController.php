<?php

namespace App\Http\Controllers\Api;

use App\Imports\ProductVoucherImport;
use App\Product;
use App\ProductVoucher;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\ProductVoucherRequest;
use Maatwebsite\Excel\Facades\Excel;

class ProductVoucherController extends Controller
{
    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: ??.
     * Modified At: 10/28/2020 15:48PM.
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: ??.
     * Modified At: 10/28/2020 15:48PM.
     * Display a listing of the resource.
     *
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProductVoucherRequest $request)
    {
        if (Gate::denies('create', ProductVoucher::class))
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);

        if ($request->hasFile('vouchers'))
        {
            $excel = Excel::import(new ProductVoucherImport($request->input('product')), request()->file('vouchers'));
            if ($excel)
                return response()->json([
                    'state' => true,
                    'message' => 'success',
                    'data' => 'vouchers',
                ], 200);
        }
        elseif ($request->only('serials') and $request->only('purchase_price'))
        {
            $serials = explode("\n", $request->input('serials'));
            foreach ($serials as $serial)
            {
                $pv = new ProductVoucher();
                $pv->serial = $serial;
                $pv->purchase_price = $request->input('purchase_price');
                $pv->product()->associate($request->input('product'))->save();
            }
            if ($pv->save())
                return response()->json([
                    'state' => true,
                    'message' => 'success',
                    'data' => 'serials',
                ], 200);

        }
        elseif ($request->hasFile('serial_image') and $request->only('purchase_price'))
        {
            foreach ($request->file('serial_image') as $index => $image)
            {
                $pv = new ProductVoucher();
                $pv->purchase_price = $request->input('purchase_price')[$index];
                $pv->image_uri = Storage::putFile('vouchers', $image);
                $pv->product()->associate($request->input('product'))->save();
            }

            if ($pv->save())
                return response()->json([
                    'state' => true,
                    'message' => 'success',
                    'data' => 'serial_image',
                ], 200);

        }
        elseif ($request->only('serial_code') and $request->only('purchase_price'))
        {
            foreach ($request->input('serial_code') as $index => $serial)
            {
                $pv = new ProductVoucher();
                $pv->serial = $serial;
                $pv->purchase_price = $request->input('purchase_price')[$index];
                $pv->product()->associate($request->input('product'))->save();
            }

            if ($pv->save())
                return response()->json([
                    'state' => true,
                    'message' => 'success',
                    'data' => 'serial_code',
                ], 200);
        }
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: ??.
     * Modified At: 10/28/2020 15:48PM.
     * Display a listing of the resource.
     *
     * Display the specified resource.
     *
     * @param  \App\ProductVoucher $productVoucher
     * @return \Illuminate\Http\Response
     */
    public function show(ProductVoucher $productVoucher)
    {
        //
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: ??.
     * Modified At: 10/28/2020 15:48PM.
     * Display a listing of the resource.
     *
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param ProductVoucher $voucher
     * @return \Illuminate\Http\Response
     */
    public function update(ProductVoucherRequest $request, ProductVoucher $voucher)
    {
        if (Gate::denies('update', $voucher))
            return response()->json([
                'state' => false,
                'message' => "forbidden!",
                'data' => null,
            ], 403);

        if ($voucher)
        {
            $voucher->serial = $request->input('serial');
            $voucher->purchase_price = $request->input('purchase_price');
            if ($request->hasFile('serial_image'))
            {
                if ($image = $request->file('serial_image'))
                {
                    $voucher->image_uri = Storage::putFile('vouchers', $image);
                }
            }
            $voucher->save();
            return response()->json([
                'state' => true,
                'message' => 'success!',
                'data' => '',
            ], 200);
        }
        else
        {
            return response()->json([
                'state' => true,
                'message' => 'not founded!',
                'data' => '',
            ], 404);
        }
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: ??.
     * Modified At: 10/28/2020 15:48PM.
     * Display a listing of the resource.
     *
     * Remove the specified resource from storage.
     *
     * @param  \App\ProductVoucher $productVoucher
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductVoucher $voucher)
    {
        if (Gate::denies('delete', $voucher))
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);

        $voucher->delete();
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => null,
        ]);
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: ??.
     * Modified At: 10/28/2020 15:48PM.
     * Display a listing of the resource.
     *
     * @param ProductVoucher $productVoucher
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function download(ProductVoucher $productVoucher)
    {
        $headers = [
            'Cache-Control'             => 'must-revalidate, post-check=0, pre-check=0',
            'Expires'                   => '0',
            'Pragma'                    => 'public',
            'Content-Type'              =>  Storage::disk('local')->mimeType($productVoucher->image_uri),
            'Content-Disposition'       => 'attachment; filename="' . $productVoucher->transaction_code . '"',
            'Content-Description'       => 'File Transfer',
            'Content-Transfer-Encoding' => 'binary',
            'Content-Length'            =>  Storage::disk('local')->size($productVoucher->image_uri),
            'Access-Control-Allow-Origin' => "*",
            'Access-Control-Allow-Methods' => "PUT,POST,DELETE,GET,OPTIONS",
            'Access-Control-Allow-Headers' => "Accept,Authorization,Content-Type",
        ];
        return response()->download(storage_path("app/$productVoucher->image_uri"), $productVoucher->transaction_code, $headers);
    }
}
