<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Requests\ProductRequest;
use App\Imports\ProductVoucherImport;
use App\Product;
use App\Http\Controllers\Controller;
use App\ProductVoucher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//use App\Http\Controllers\Api\ProductController as BaseProductController;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class ProductController extends Controller
{
    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/24/2020 11:00Am.
     * Modified At: 9/24/2020 11:00Am.
     *
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (Gate::denies('viewAny', Product::class))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        if (!$request->has('type'))
        {
            $admin_products = Product::select(['id','user_id', 'category_id','price' ,'created_at', 'updated_at'])->with( ['vouchers','category' => function($query)
            {
                $query->select(['id', 'name']);
            }])->where('user_id', Auth::id())->paginate(30);

            $seller_products = Product::select(['id','user_id', 'category_id','price' ,'created_at', 'updated_at'])->with(['vouchers','category' => function($query){
                $query->select(['id', 'name']);
            }])->whereNotNull('user_id')->where('user_id', '!=', Auth::id())->paginate(30);

            $system_products = Product::select(['id','user_id', 'category_id','price' ,'created_at', 'updated_at'])->with(['vouchers','category' => function($query){
                $query->select(['id', 'name']);
            }])->whereNull('user_id')->paginate(30);

            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => [
                    'admin_product' => $admin_products,
                    'seller_products' => $seller_products,
                    'system_products' => $system_products
                ]
            ],200);
        }
        else
        {
            switch ($request->input('type'))
            {
                case 'system':
                    $system_products = Product::select(['id','user_id', 'category_id','price' ,'created_at', 'updated_at'])->with(['vouchers','category' => function($query){
                        $query->select(['id', 'name']);
                    }])->whereNull('user_id')->paginate(30);
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => [
                            'system_products' => $system_products
                        ]
                    ],200);
                    break;
                case 'seller':
                    $seller_products = Product::select(['id','user_id', 'category_id','price' ,'created_at', 'updated_at'])->with(['vouchers','category' => function($query){
                        $query->select(['id', 'name']);
                    }])->whereNotNull('user_id')->where('user_id', '!=', Auth::id())->paginate(30);
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => [
                            'seller_products' => $seller_products,
                        ]
                    ],200);
                    break;
                case 'admin':
                    $admin_products = Product::select(['id','user_id', 'category_id','price' ,'created_at', 'updated_at'])->with( ['vouchers','category' => function($query)
                    {
                        $query->select(['id', 'name']);
                    }])->where('user_id', Auth::id())->paginate(30);
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => [
                            'admin_product' => $admin_products,
                        ]
                    ],200);
                    break;
            }
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function create()
     {
         //
     }

    /**
     * Algorithm: Ahmad montazeri.
     * Development: Sina Khaghani.
     * Created At: 9/24/2020 11:00Am.
     * Modified At: 9/24/2020 11:00Am.
     *
     * @param  \Illuminate\Http\Request  $request
     *     Store a newly created resource in storage.
     *     category(int): category id from product_category table, price(array): price of product, from(array): Start number Product number, to(array): End number Product number, user_id(int).
     *     The store voucher operation is done in four ways.
     *     The first method: Send coupons in Excel file
     *     Parameters: vouchers(file excel)
     *     The second method is an array.
     *     Parameters: purchase_price(array): price of product, serial_code(array): serial voucher
     *     The fourth method is in the form of a photograph.
     *     Parameters: serial_image(file image), purchase_price(array)
     * @return \Illuminate\Http\Response
     */
    public function store(ProductRequest $request)
    {
        if(Gate::denies('create', Product::class))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }

        $product = new Product($request->all());
        $product->category()->associate($request->input('category'));
        $prices = [];
        foreach ($request->input('price') as $index => $price)
        {
            $prices[] = [(int)$request->input('from')[$index], (int)$request->input('to')[$index], (int)$price];
        }
        /*
         * If using the cast attribute in model to cast price to array, we must don't use json_encode method.
         */
        //$product->price = json_encode($prices);
        $product->price = $prices;
        if(!is_null($request->input('seller')))
            $product->seller()->associate($request->input('seller'));
        if($product->save())
        {
            if ($request->hasFile('vouchers'))
            {
                $excel = Excel::import(new ProductVoucherImport($product->id), request()->file('vouchers'));
                if ($excel)
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => 'vouchers',
                    ], 200);
                else
                    return response()->json([
                        'state' => null,
                        'message' => 'success',
                        'data' => '',
                    ], 503);
            }
            elseif ($request->only('serials') and $request->only('purchase_price'))
            {
                $serials = explode("\n", $request->input('serials'));
                foreach ($serials as $serial) {
                    $productVoucher = new ProductVoucher();
                    $productVoucher->serial = $serial;
                    $productVoucher->purchase_price = $request->input('purchase_price');
                    $productVoucher->product_id = $product->id;
                    $productVoucher->save();
                }
                if ($productVoucher->save())
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => 'serials',
                    ], 200);
                return response()->json([
                    'state' => null,
                    'message' => 'success',
                    'data' => '',
                ], 503);
            }
            elseif ($request->hasFile('serial_image') and $request->only('purchase_price'))
            {
                foreach ($request->file('serial_image') as $index => $image)
                {
                    $productVoucher = new ProductVoucher();
                    $productVoucher->purchase_price = $request->input('purchase_price')[$index];
                    $productVoucher->product_id = $product->id;
                    $productVoucher->image_uri = Storage::putFile('vouchers', $image);
                    $productVoucher->save();
                }
                if ($productVoucher->save())
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => 'serial_image',
                    ], 200);
                else
                    return response()->json([
                        'state' => null,
                        'message' => 'success',
                        'data' => '',
                    ], 503);
            }
            elseif ($request->only('serial_code') and $request->only('purchase_price'))
            {
                foreach ($request->input('serial_code') as $index => $serial) {
                    $productVoucher = new ProductVoucher();
                    $productVoucher->serial = $serial;
                    $productVoucher->purchase_price = $request->input('purchase_price')[$index];
                    $productVoucher->product_id = $product->id;
                    $productVoucher->save();
                }
                if ($productVoucher->save())
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => 'serial_code',
                    ], 200);
                else
                    return response()->json([
                        'state' => null,
                        'message' => 'no',
                        'data' => '',
                    ], 503);
            }
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => '',
            ], 200);
        }
        else
        {
            return response()->json([
                'state' => null,
                'message' => 'success',
                'data' => '',
            ], 503);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        if (Gate::denies('view', $product))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => [
                'product' => $product->load(['vouchers', 'category' => function($query)
                {
                    $query->with(['brand']);
                }])
            ],
        ],200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Algorithm: Ahmad montazeri.
     * Development: Sina Khaghani.
     * Created At: 9/27/2020 11:00Am.
     * Modified At: 9/27/2020 11:00Am.
     *
     * @param  \Illuminate\Http\Request  $request
     *     Update the specified resource in storage.
     *     category(int): category id from product_category table,
     *     price(array): price of product,
     *     from(array): Start number Product number,
     *     to(array): End number Product number.
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(ProductRequest $request, Product $product)
    {
        if (Gate::denies('update', $product))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        $product->category()->associate($request->input('category'));
        $product->seller()->associate($request->input('user'));
        $prices = [];
        foreach ($request->input('price') as $index => $price)
        {
            $prices[] = [(int)$request->input('from')[$index], (int)$request->input('to')[$index], (int)$price];
        }
        $product->price = $prices;
        if ($product->save())
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ], 200);

        return response()->json([
            'state' => false,
            'message' => 'services unavailable',
            'data' => null,
        ], 503);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/27/2020 13:00Am.
     * Modified At: 9/27/2020 13:00Am.
     *
     * Remove the specified resource from storage.this methos
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        if (Gate::denies('delete', $product))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        $product->delete();
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => null
        ],200);
    }
}
