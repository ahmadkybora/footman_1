<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\OrderRequest;
use App\Http\Traits\General;
use App\Order;
use App\Http\Controllers\Controller;
use App\UserOrder;
use Illuminate\Auth\Access\Gate;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    use General;

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 10/28/2020 10:00 Am.
     * Modified At:.
     *
     * Display a listing of the resource.
     * این متد باید تمیز شود
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orders = UserOrder::paginate(30);
        $userOrder = $this->filtering($orders->toArray(), [
            'email' => null,
            'email_verified_at' => null,
            'mobile' => null,
            'mobile_verified_at' => null,
            'postal_code' => null,
            'city_id' => null,
            'home_address' => null,
            'work_address' => null,
            'stated_at' => null,
            'visited' => null,
            'deleted_at' => null,
            'avatar_uri' => null,
            'metadata' => null,
            'slug' => null,
            'brand_id' => null,
        ]);

        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $userOrder,
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(UserOrder $order)
    {
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $order,
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        //
    }


    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 9/21/2020 10PM
     * Modified At: 9/22/2020 10:39AM
     *
     * this method for add to cart.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function addToCart(OrderRequest $request)
    {
        /*$request->validate([
            'product' => 'required',
            'quantity' => 'required',
        ]);*/
        //return DB::transaction(function () use ($request) { // Group A
        /*$product = Product::where('id', $request->input('product'))->firstOrFail();
        foreach ($product->price as $index => $price) {
            if ($request->input('quantity') >= $price[0] and $request->input('quantity') <= $price[1])
            {
                $selected_price = $price[2];
                break;
            }
        }*/

        $total_price = $this->calculatePrice([[$request->input('product'), $request->input('quantity')]]);
        if (!$total_price)
            return response()->json([
                'state' => false,
                'message' => 'inventory is not enough',
                'data' => null,
            ], 200);

        $cart = $request->user()->cart;
        if (!$cart)
        {
            //$order = new Order(); // Group A
            $order = new UserOrder();
            $order->products = serialize([[(int)$request->input('product'), (int)$request->input('quantity')]]);
            $order->price = $total_price;

            //$order->owner()->associate(Auth::user()); // Group A
            //if ($order->save() and $order->forUser(Auth::user())->save()) // Group A

            if($order->save())
            {
                return response()->json([
                    'state' => true,
                    'message' => 'your cart is created.',
                    'data' => [
                        'products' => $this->sanitizeCart($order),
                        'total_price' => $total_price,
                    ],
                ], 201);
            }
            return response()->json([
                'state' => false,
                'message' => 'service is unavailable',
                'data' => null,
            ], 503);
        }
        else
        {
            $items = $cart->items;
            $found = false;
            foreach ($items as $index => $item)
            {
                if ($item[0] == $request->input('product'))
                {
                    $found = true;
                    //$items[$index][1] += (int)$request->input('quantity');
                    $items[$index][1] = (int)$request->input('quantity');
                }
            }
            if (!$found)
                $items[] = [(int)$request->input('product'), (int)$request->input('quantity')];

            $cart->products = serialize($items);
            $cart->price = $this->calculatePrice($items);

            // Group A
            /*$system_order = Order::where('id', $cart->system_order_id)->first();
            if ($system_order)
            {
                $system_order->products = serialize($items);
                $system_order->price = $cart->price;
                $system_order->save();
            }*/

            if ($cart->save())
                return response()->json([
                    'state' => true,
                    'message' => 'your product added to cart.',
                    'data' => [
                        'products' => $this->sanitizeCart($cart),
                        'total_price' => $cart->price,
                    ],
                ], 200);
        }
        //}); // Group A
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 9/21/2020 10PM
     * Modified At: 9/22/2020 10:39AM
     *
     * this method for remove product from cart.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function removeFromCart(OrderRequest $request)
    {
        $cart = $request->user()->cart;
        $items = $cart->items;
        foreach ($items as $index => $item){
            if($item[0] == $request->input('product'))
                unset($items[$index]);
        }
        if(!count($items))
        {
            $cart->delete();
            return response()->json([
                'state' => true,
                'message' => 'the product is removed and your cart is empty.',
                'data' => null,
            ], 200);
        }

        $cart->products = serialize($items);
        $cart->price = $this->calculatePrice($items);

        if ($cart->save())
            return response()->json([
                'state' => true,
                'message' => 'your product remove from cart.',
                'data' => [
                    'product' => $this->sanitizeCart($cart),
                    'total_price' => $cart->price,
                ],
            ], 200);
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 9/21/2020 10PM
     * Modified At: 9/22/2020 10:39AM
     *
     * this method for get cart.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function cart(Request $request)
    {
        $cart = $request->user()->cart;
        if (!is_null($cart))
        {
            $items = $cart->items;
            $cart->price = $this->calculatePrice($items);
            $sanitized_cart = $this->sanitizeCart($request->user()->cart);
            if ($cart and $sanitized_cart) {
                return response()->json([
                    'state' => true,
                    'message' => 'your product added to cart.',
                    'data' => [
                        'products' => $sanitized_cart,
                        'total_price' => $cart->price,
                    ],
                ], 200);
            }
        }

        return response()->json([
            'state' => false,
            'message' => 'you dont have cart',
            'data' => null,
        ], 200);
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 9/21/2020 10PM
     * Modified At: 9/22/2020 10:39AM
     *
     * this method for delete cart.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function cartDelete(Request $request)
    {
        $cart = $request->user()->cart;
        if ($cart)
        {
            $cart->delete();
            return response()->json([
                'state' => true,
                'message' => 'your cart is deleted.',
                'data' => null,
            ], 200);
        }

        return response()->json([
            'state' => false,
            'message' => 'you dont have cart',
            'data' => null,
        ], 200);
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 9/21/2020 10PM
     * Modified At: 9/22/2020 10:39AM
     *
     * this method for sanitize data and assign index to product.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function sanitizeCart(UserOrder $cart)
    {
        $products = $cart->products()->with(['category', 'seller' => function ($query) {
            $query->select('id', 'username', 'first_name', 'last_name');
        }])->get();
        $filtered_products = $this->filtering($products->toArray(), [
            'visited' => null,
            'state' => null,
            'stated_at' => null,
            'created_at' => null,
            'updated_at' => null,
            'vouchers' => null,
            'price' => null,
            'user_id' => null,
            'category_id' => null,
            'brand_id' => null,
        ]);

        foreach ($filtered_products as $index => $product)
        {
            foreach ($cart->items as $i => $item)
            {
                if ($filtered_products[$index]['id'] == $item[0])
                {
                    $filtered_products[$index]['quantity'] = $item[1];
                    $filtered_products[$index]['price'] = $products[$index]->priceOf($item[1]);
                }
            }
        }

        return $filtered_products;
    }

    public function orders()
    {
        $orders = UserOrder::all();
        $userOrder = $this->filtering($orders->toArray(), [
            'email' => null,
            'email_verified_at' => null,
            'mobile' => null,
            'mobile_verified_at' => null,
            'postal_code' => null,
            'city_id' => null,
            'home_address' => null,
            'work_address' => null,
            'state' => null,
            'stated_at' => null,
            'visited' => null,
            'deleted_at' => null,
            'avatar_uri' => null,
            'metadata' => null,
            'slug' => null,
            'brand_id' => null,
        ]);

        if($userOrder)
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $userOrder,
        ], 200);
    }
}
