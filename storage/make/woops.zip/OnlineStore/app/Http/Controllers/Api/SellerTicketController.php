<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\SellerTicketRequest;
use App\Product;
use App\ProductVoucher;
use App\SellerTicket;
use App\Http\Controllers\Controller;
use App\SellerTicketDetail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

class SellerTicketController extends Controller
{
    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:00 Am.
     * Modified At:.
     *
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Gate::denies('view-any', SellerTicket::class))
            return response()->json([
                'state' => false,
                'message' => 'forbidden',
                'data' => null,
            ], 403);

        $sellerTicketDetail = SellerTicket::where('buyer_id', Auth::id())->with(['sellerTicketDetails', 'voucher', 'seller' => function($query) {
            $query->select('id', 'first_name', 'last_name', 'username');
        }])->paginate(30);
        $sellerTicketDetail = $this->filtering($sellerTicketDetail->toArray(), [
            'serial' => null,
            'purchase_price' => null,
            'metadata' => null,
        ]);

        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $sellerTicketDetail,
        ]);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:00 Am.
     * Modified At:.
     *
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:00 Am.
     * Modified At:.
     *
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SellerTicketRequest $request)
    {
        if(Gate::denies('create', SellerTicket::class))
            return response()->json([
                'state' => false,
                'message' => 'forbidden',
                'data' => null,
            ], 403);

        $seller = ProductVoucher::where('id', $request->input('voucher'))->pluck('product_id')->first();
        $seller = Product::where('id', $seller)->pluck('user_id')->first();

        $sellerTicketDetail = new SellerTicket();
        $sellerTicketDetail->title = $request->input('title');
        $sellerTicketDetail->body = $request->input('body');
        $sellerTicketDetail->buyer()->associate(Auth::id());
        $sellerTicketDetail->seller()->associate($seller);
        $sellerTicketDetail->voucher()->associate($request->input('voucher'));

        if($sellerTicketDetail->save())
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ], 201);
    }

    /**
     * Algorithm: elyass dehghan.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:00 Am.
     * Modified At:.
     *
     * Display the specified resource.
     *
     * @param  \App\SellerTicket  $sellerTicket
     * @return \Illuminate\Http\Response
     */
    public function show(SellerTicket $sellerTicket)
    {
        if (Gate::denies('view', $sellerTicket))
            return response()->json([
                'state' => false,
                'message' => 'forbidden',
                'data' => null,
            ], 403);

        return DB::transaction(function () use ($sellerTicket)
        {
            if($sellerTicket->seller_id == Auth::id())
            {
                if ($sellerTicket->seen_at === null)
                {
                    $sellerTicket->seen_at = Carbon::now();
                    $sellerTicket->save();
                }
            }

            $sellerTicket->sellerTicketDetails()->where('to_id', Auth::id())->whereNull('seen_at')->update(['seen_at' => Carbon::now()]);
            /*foreach ($sellerTicket->seller_ticket_details as $index => $seller)
            {
                if ($seller->seen_at === null)
                {
                    $seller->seen_at = Carbon::now();
                    $std = $seller->save();
                }
            }*/

            $sellerTicket = $sellerTicket->load('sellerTicketDetails');
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $sellerTicket,
            ], 200);
        });
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:00 Am.
     * Modified At:.
     *
     * Show the form for editing the specified resource.
     *
     * @param  \App\SellerTicket  $sellerTicket
     * @return \Illuminate\Http\Response
     */
    public function edit(SellerTicket $sellerTicketDetail)
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:00 Am.
     * Modified At:.
     *
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SellerTicket  $sellerTicket
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SellerTicket $sellerTicket)
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:00 Am.
     * Modified At:.
     *
     * Remove the specified resource from storage.
     *
     * @param  \App\SellerTicket  $sellerTicket
     * @return \Illuminate\Http\Response
     */
    public function destroy(SellerTicket $sellerTicket)
    {
        //
    }
    
    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:00 Am.
     * Modified At:.
     *
     * @param SellerTicketRequest $request
     * @param SellerTicket $SellerTicket
     * @return \Illuminate\Http\JsonResponse
     */
    public function storeSellerDetails(SellerTicketRequest $request, SellerTicket $SellerTicket)
    {
        if(Gate::denies('restoreDetails', $SellerTicket))
            return response()->json([
                'state' => false,
                'message' => 'forbidden',
                'data' => null,
            ], 403);

        $sellerTicketDetail = new SellerTicketDetail();
        $sellerTicketDetail->body = $request->input('body');
        $sellerTicketDetail->from_id = Auth::id();

        if ($SellerTicket->seller_id == Auth::id())
            $sellerTicketDetail->to_id = $SellerTicket->buyer_id;
        else
            $sellerTicketDetail->to_id = $SellerTicket->seller_id;
        //$sellerTicketDetail->to_id = $SellerTicket->seller_id == Auth::id() ? $SellerTicket->buyer_id : ($SellerTicket->buyer_id == Auth::id() ? $SellerTicket->seller_id);
        $sellerTicketDetail->sellerTicket()->associate($SellerTicket->id);

        if ($sellerTicketDetail->save())
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $sellerTicketDetail,
            ], 200);
    }

    /**
     * Algorithm: elyass dehghan.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 12:00 Am.
     * Modified At:.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function sellerIndex()
    {
        $sellerIndex = SellerTicket::where('seller_id', Auth::id())->paginate(30);

        if ($sellerIndex)
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $sellerIndex,
            ], 200);
    }
}
