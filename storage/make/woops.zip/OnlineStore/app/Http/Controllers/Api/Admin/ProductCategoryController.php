<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Requests\CategoryRequest;
use App\ProductCategory;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

class ProductCategoryController extends Controller
{
    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/28/2020 12:00Am.
     * Modified At: 10/28/2020 12:10Am.
     *
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Gate::denies('viewAny', ProductCategory::class))
        {
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        }
        $category = ProductCategory::with('brand')->paginate(30);
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $category
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/28/2020 12:00Am.
     * Modified At: 10/28/2020 12:10Am.
     *
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     *      name(string): name of category.
     *      brand(int): id of brand.
     *      avatar_uri(file): image of category.
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryRequest $request)
    {
        if(Gate::denies('create', ProductCategory::class))
        {
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        }
        return DB::transaction(function () use ($request){
            $category = new ProductCategory();
            if ($request->hasFile('avatar_uri'))
            {
                $image = $request->file('avatar_uri');
                $category->avatar_uri = Storage::putFile('public/images/product-categories', $image);
            }
            $category->name = $request->input('name');
            $category->brand()->associate($request->input('brand'))->save();
            if ($category->save())
            {
                return response()->json([
                    'state' => true,
                    'message' => 'success',
                    'data' => null,
                ], 200);
            }
            return response()->json([
                'state' => null,
                'message' => 'server error',
                'data' => null,
            ], 503);
        });

    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/28/2020 12:20Am.
     * Modified At: 10/28/2020 12:10Am.
     *
     * Display the specified resource.
     *
     * @param  \App\ProductCategory  $category
     * @return \Illuminate\Http\Response
     */
    public function show(ProductCategory $category)
    {
        if(Gate::denies('view', ProductCategory::class))
        {
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        }
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $category->load('brand','products'),
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProductCategory  $category
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductCategory $category)
    {
        if(Gate::denies('view', ProductCategory::class))
        {
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        }
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $category,
        ], 200);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/28/2020 12:10Am.
     * Modified At: 10/28/2020 12:10Am.
     *
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     *      name(string): name of category.
     *      brand(int): id of brand.
     *      avatar_uri(file): image of category.
     * @param  \App\ProductCategory  $productCategory
     * @return \Illuminate\Http\Response
     */
    public function update(CategoryRequest $request, ProductCategory $category)
    {
        if(Gate::denies('update', ProductCategory::class))
        {
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        }
        return DB::transaction(function () use ($request,$category){
            if ($request->hasFile('avatar_uri'))
            {
                $image = $request->file('avatar_uri');
                $category->avatar_uri = Storage::putFile('public/images/product-categories', $image);
            }
            $category->name = $request->input('name');
            $category->brand()->associate($request->input('brand'))->save();
            if ($category->save())
            {
                return response()->json([
                    'state' => true,
                    'message' => 'success',
                    'data' => null,
                ], 200);
            }
            return response()->json([
                'state' => null,
                'message' => 'server error',
                'data' => null,
            ], 503);
        });
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/28/2020 12:10Am.
     * Modified At: 10/28/2020 12:10Am.
     *
     * Remove the specified resource from storage.
     *
     * @param  \App\ProductCategory  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductCategory $category)
    {
        if(Gate::denies('delete', ProductCategory::class))
        {
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        }
        if (!$category->products->count())
        {
            $category->delete();
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ], 200);
        }
        return response()->json([
            'state' => null,
            'message' => 'This category cannot be deleted, Delete product first',
            'data' => null,
        ], 503);
    }
}
