<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;
//use App\Http\Controllers\Api\UserController as BaseUserController;

class UserController extends Controller
{
    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/22/2020 9:00Am.
     * Modified At: 9/22/2020 9:00Am.
     *
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Gate::denies('view-any' ,User::class))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        $user =  User::where('id', '!=' ,Auth::id())->with(['city', 'city.region', 'city.region.country','roles.permissions'])->paginate(30);

        return response()->json([
            'state' => true,
            'message' => null,
            'data' => $user,
        ],200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/22/2020 9:00Am.
     * Modified At: 9/22/2020 9:00Am.
     *
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRequest $request, User $user)
    {
        if(Gate::denies('create', $user))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        $secret_keys = User::pluck('secret_key')->toArray();
        do {
            $secret_key = Str::random(5);
        } while (in_array($secret_key, $secret_keys));

        $user = new User();
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->email = $request->input('email');
        $user->mobile = $request->input('mobile');
        $user->username = $request->input('username');
        $user->postal_code = $request->input('postal_code');
        $user->password = Hash::make($request->input('password')) ;
        $user->city()->associate($request->input('city'));
        $user->home_address  = $request->input('home_address ');
        $user->work_address = $request->input('work_address');
        $user->state = $request->input('state');
        $user->secret_key = $secret_key;
        if($request->hasFile('avatar'))
        {
            $path = Storage::disk('public')->putFile('images/avatars', $request->file('avatar'));
            if (!empty($user->avatar_uri) and file_exists('storage/' . $user->avatar_uri));
            Storage::disk('public')->delete($user->avatar_uri);
            $user->avatar_uri = $path;

            //$user->avatar_uri = $request->file('avatar')->store('/public/images/avatars');
        }

        if($user->save())
        {
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ], 200);
        }

        return response()->json([
            'state' => false,
            'message' => 'server error',
            'data' => null,
        ], 500);

    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/22/2020 9:00Am.
     * Modified At: 9/22/2020 9:00Am.
     *
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        if (Gate::denies('view', $user))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        $user->load(['city.region.country','roles.permissions']);
        $user = $this->filtering($user->toArray(), [
            'created_at' => null,
            'updated_at' => null,
            'pivot' => null,
        ]);

        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $user,
        ], 200);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/22/2020 9:00Am.
     * Modified At: 9/22/2020 9:00Am.
     *
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        if(Gate::denies('view', $user))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }

        $role = $user->getRoleNames();
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => [$user,$role],
        ], 200);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/22/2020 9:00Am.
     * Modified At: 9/22/2020 9:00Am.
     *
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     *      roles(array): roles of user.
     *      first_name(string): first name of user.
     *      last_name(string): last name of user.
     *      email(string): email of user.
     *      mobile(string): mobile of user.
     *      username(string): user name of user.
     *      postal_code(string): user postal code number.
     *      password(string): password of user.
     *      city(bigint): user city id.
     *      home_address(string): user address.
     *      work_address(string): user work address.
     *      state(enum: active, inactive, suspended, pending): user permission.
     *      avatar_uri(string): user avatar.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, User $user)
    {
        if(Gate::denies('update', $user))
        {
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);
        }
        $user->syncRoles($request->input('roles'));
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->email = $request->input('email');
        $user->mobile = $request->input('mobile');
        $user->username = $request->input('username');
        $user->postal_code = $request->input('postal_code');
        if($request->has('password'))
            $user->password = Hash::make($request->input('password')) ;
        $user->city()->associate($request->input('city'));
        $user->home_address  = $request->input('home_address');
        $user->work_address = $request->input('work_address');
        $user->state = $request->input('state');
        if($request->hasFile('avatar'))
        {
            $path = Storage::disk('public')->putFile('images/avatars', $request->file('avatar'));
            if (!empty($user->avatar_uri) and file_exists('storage/' . $user->avatar_uri));
            Storage::disk('public')->delete($user->avatar_uri);
            $user->avatar_uri = $path;

            //$user->avatar_uri = $request->file('avatar')->store('/public/images/avatars');
        }

        if($user->save())
        {
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ], 200);
        }

        return response()->json([
            'state' => false,
            'message' => 'server error',
            'data' => null,
        ], 500);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/22/2020 9:00Am.
     * Modified At: 9/22/2020 9:00Am.
     *
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        if(Gate::denies('delete', $user))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        $user->delete();
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => null
        ],200);
    }

    public function users()
    {
        $users = User::all();

        if($users)
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $users
        ],200);
    }
}
