<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\Notifications\SignUp;
use App\Notifications\ResetPassword;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;


class AuthController extends Controller
{
    /**
     * Create a new user instance after a valid registration.
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(UserRequest $request)
    {
        /*$birt_date = explode('-', $request->input('birth_date'));
        $jdate = Verta::getGregorian($birt_date[0], $birt_date[1], $birt_date[2]);
        $birth_date = Carbon::createFromDate($jdate[0], $jdate[1], $jdate[2])->format('Y-m-d');*/

        // Mobile activation token
        /*$code = rand(10000, 99999);
        $this->sendSms($request->input('mobile'), $code);*/

        $secret_keys = User::pluck('secret_key')->toArray();
        do {
            $secret_key = Str::random(5);
        } while (in_array($secret_key, $secret_keys));

        $user = new User();
        $user->secret_key = $secret_key;
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->city()->associate($request->input('city'));
        $user->username = $request->input('username');
        $user->email = $request->input('email');
        $user->mobile = $request->input('mobile');
        $user->home_address = $request->input('home_address');
        $user->work_address = $request->input('work_address');
        //$user->birth_date = $birth_date;
        $user->password = Hash::make($request->input('password'));
        //$user->assignRole($request->input('level'));
        $user->metadata = json_encode([
            'email_verification_sent_at' => Carbon::now()->toDateTimeString(),
        ], JSON_UNESCAPED_UNICODE);
        /*$user->presenter_id = User::wherePresentCode($request->input('presenter_code'))->firstOrFail()->id;
        $user->present_code = uniqid();*/
        if ($user->save())
        {
            $user->notify(new SignUp());
            /*$tokenResult = $user->createToken('WebApp');
            $token = $tokenResult->token;
            $token->save();*/

            return response()->json([
                'state' => true,
                'message' => "thanks, you are registered successfully. please confirm your email...",
                'data' => null,
            ], 200);
        }

        return response()->json([
            'state' => false,
            'message' => "please try again later.",
            'data' => null,
        ], 500);
    }

    /**
     * This Method For Login user
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        if (Auth::attempt(['username' => $request->input('username'), 'password' => $request->input('password')]))
        {
            $expiry_duration = 1; // Unit is day.
            $user = $request->user();

            //$token = $user->createToken('WebApp')->accessToken;
            $tokenResult = $user->createToken('WebApp');
            $token = $tokenResult->token;
            if ($request->has('remember_me') and $request->input('remember_me'))
                $expiry_duration = 30;
            $token->expires_at = Carbon::now()->addDays($expiry_duration);
            $token->save();

            return response()->json([
                'state' => true,
                'message' => 'you are logged in.',
                'data' => [
                    'token' => $tokenResult->accessToken,
                    'token_type' => 'Bearer',
                    'token_expires_at' => Carbon::parse($token->expires_at)->toDateTimeString(),
                    'token_expiry_duration' => $expiry_duration,
                    'username' => $user->username,
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                ],
            ], 200);
        }

        return response()->json([
            'state' => false,
            'message' => 'the data is wrong.',
            'data' => null,
        ], 401);
    }

    /**
     * This Method For Logout User
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout(Request $request)
    {
        $request->user()->token()->revoke();
        return response()->json([
            'state' => true,
            'message' => 'you have successfully logged out.',
            'data' => null,
        ], 200);
    }

    /**
     * This Method For VerifyEmail
     *
     * @param Request $request
     * @param User $user
     * @param $timestamp
     * @return \Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function verifyEmail(Request $request, User $user, $timestamp)
    {
        if ($user->hasVerifiedEmail())
            return response()->json([
                'state' => false,
                'message' => 'your account has already been activated.',
                'data' => null,
            ], 200);

        $code = $user->id . $user->secret_key . $timestamp;
        $metadata = json_decode($user->metadata, true);
        if ($metadata['email_verification_sent_at'] >= Carbon::now()->subMinutes(15))
        {
            if (Hash::check($code, $request->input('signature')))
            {
                $tokenResult = $user->createToken('WebApp');
                $token = $tokenResult->token;
                $token->save();

                $user->email_verified_at = Carbon::now()->toDateTimeString(); // Equivalent to : $user->markEmailAsVerified();
                unset($metadata['email_verification_sent_at']);
                $user->metadata = json_encode($metadata, JSON_UNESCAPED_UNICODE);
                $user->save();

                /*return response()->json([
                    'state' => true,
                    'message' => 'your account is now activated.',
                    'data' => [
                        'token' => $tokenResult->accessToken,
                        'token_type' => 'Bearer',
                        'token_expires_at' => Carbon::parse($token->expires_at)->toDateTimeString(),
                    ],
                ], 200);*/
                return redirect('http://d-codesland.ir/#/verify?done');
            }

            /*return response()->json([
                'state' => false,
                'message' => 'the activation link is invalid.',
                'data' => null,
            ], 404);*/
            return redirect('http://d-codesland.ir/#/verify?failed');
        }

        /*return response()->json([
            'state' => false,
            'message' => 'the activation link expired.',
            'data' => null,
        ], 404);*/
        return redirect('http://d-codesland.ir/#/verify?expired');
    }

    /**
     * This Method For Checking Auth
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function checkAuth(Request $request)
    {
        if (Auth::guard('api')->check())
        {
            return response()->json([
                'state' => true,
                'message' => null,
                'data' => [
                    'first_name' => auth()->guard('api')->user()->first_name,
                    'last_name' => auth()->guard('api')->user()->last_name,
                    'username' => auth()->guard('api')->user()->username,
                ]
            ], 200);
        }

        return response()->json([
            'state' => false,
            'message' => null,
            'data' => null
        ], 200);
    }

    /**
     * This Method For Recovery Password
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function recoveryPassword(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email', 'exists:users,email'],
        ]);

        $email = $request->input('email');

        $user = User::where('email', $email)->firstOrFail();
        $user->metadata = json_encode([
            'reset_email_verification_sent_at' => Carbon::now()->toDateTimeString(),
        ], JSON_UNESCAPED_UNICODE);

        if ($user->save())
        {
            $user->notify(new ResetPassword());

            return response()->json([
                'state' => true,
                'message' => "thanks, a recovery email has been sent to your account",
                'data' => null,
            ], 200);
        }

        return response()->json([
            'state' => false,
            'message' => "please try again later.",
            'data' => null,
        ], 500);
    }

    /**
     * This Method for Reset Password
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function resetPassword(Request $request)
    {

        $request->validate([
            'password' => ['required', 'string', 'confirmed', 'min:8', 'max:15'],
        ]);

        $username = $request->input('username');
        $timestamp = $request->input('timestamp');
        $signature = rawurldecode($request->input('signature'));
        $password = $request->input('password');

        $user = User::where('username', $username)->firstOrFail();
        $token = $user->id . $user->secret_key . $timestamp;

        $metadata = json_decode($user->metadata, true);

        if (isset($metadata['reset_email_verification_sent_at']))
        {
            if ($metadata['reset_email_verification_sent_at'] >= Carbon::now()->subMinutes(1))
            {
                if (Hash::check($token, $signature))
                {
                    $user->password = Hash::make($password);
                    unset($metadata['reset_email_verification_sent_at']);
                    $user->metadata = json_encode($metadata, JSON_UNESCAPED_UNICODE);
                    if ($user->save())
                    {
                        return response()->json([
                            'state' => true,
                            'message' => 'your password was changed successfully.',
                            'data' => null,
                        ], 200);
                    }

                    return response()->json([
                        'state' => false,
                        'message' => 'sorry,please try again later.',
                        'data' => null,
                    ], 401);
                }

                return response()->json([
                    'state' => false,
                    'message' => 'your signature does not match.',
                    'data' => null,
                ], 401);
            }

            return response()->json([
                'state' => false,
                'message' => 'your reset password link has expired.',
                'data' => null,
            ], 401);
        }

        return response()->json(['state' => false,
            'message' => 'your reset password link is invalid.',
            'data' => null,], 404);
    }
}
