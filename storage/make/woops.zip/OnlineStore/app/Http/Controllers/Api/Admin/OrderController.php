<?php

namespace App\Http\Controllers\Api\Admin;

use App\Order;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class OrderController extends Controller
{
    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/13/2020 16:20Am.
     * Modified At: 10/13/2020 16:10Am.
     *
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Gate::denies('viewAny', Order::class))
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);

        $order = Order::with('owner')->paginate(30);
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $order,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/13/2020 16:20Am.
     * Modified At: 10/13/2020 16:10Am.
     *
     * Display the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        if (Gate::denies('view', $order))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $order->load('transaction'),
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        //
    }
}
