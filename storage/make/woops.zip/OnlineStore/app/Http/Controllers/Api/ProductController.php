<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\ProductRequest;
use App\Product;
use App\ProductVoucher;
use Illuminate\Http\Request;
use App\Brand;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Gate;
use App\Imports\ProductVoucherImport;
use Illuminate\Support\Facades\Storage;
use Excel;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     * Author:
     *      Ability: Ahamad Montazeri
     *      Access Control: Mahtab Hakimzade
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Gate::denies('view-any', Product::class))
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);

        $products = Product::select(['id', 'category_id', 'created_at', 'updated_at'])->with(['category' => function($query)
        {
            $query->select('id', 'name');
        }])->where('user_id', auth()->id())->paginate(30);


        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $products,
        ],200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        /*
         * Testing the Arr::except method.
         */
        /*$x = [
            'id' => 'ID',
            'name' => 'B1',
            'categories' => [
                'brand_id' => 'ID',
                'name' => 'C1',
            ],
        ];
        $x = Arr::except($x, ['id', 'categories.brand_id']);
        return $x;*/

        if(Gate::denies('create', Product::class))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }

        $brands = Brand::has('categories')->select('name', 'id')->with(['categories' => function ($query){
            $query->select('id', 'name', 'avatar_uri', 'brand_id');
        }])->get()->toArray();

        /*foreach ($brands as $key => $brand)
        {
            $excepts = [];
            for ($i = 0; $i < count($brand['categories']); $i++)
                $excepts[] = "categories.$i.brand_id";
            $brands[$key] = Arr::except($brand, array_merge(['id'], $excepts));
        }*/

        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $brands,
        ], 200);
    }

    /**
     * Store a newly created resource in storage.
     * category(int): category id from product_category table, price(array): price of product, from(array): Start number Product number, to(array): End number Product number.
     * The store voucher operation is done in four ways.
     * The first method: Send coupons in Excel file
     * Parameters: vouchers(file excel)
     * The second method is an array.
     * Parameters: purchase_price(array): price of product, serial_code(array): serial voucher
     * The fourth method is in the form of a photograph.
     * Parameters: serial_image(file image), purchase_price(array)
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProductRequest $request)
    {
        if(Gate::denies('create', Product::class))
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);

        $product = new Product($request->all());
        $product->category()->associate($request->input('category'));
        $prices = [];
        foreach ($request->input('price') as $index => $price)
        {
            $prices[] = [(int)$request->input('from')[$index], (int)$request->input('to')[$index], (int)$price];
        }
        /*
         * If using the cast attribute in model to cast price to array, we must don't use json_encode method.
         */
        //$product->price = json_encode($prices);
        $product->price = $prices;

        $product->user_id = auth()->id();
        if($product->save())
        {
            if ($request->hasFile('vouchers'))
            {
                $excel = Excel::import(new ProductVoucherImport($product->id), request()->file('vouchers'));
                if ($excel)
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => 'vouchers',
                    ], 200);
                else
                    return response()->json([
                        'state' => null,
                        'message' => 'success',
                        'data' => '',
                    ], 503);
            }
            elseif ($request->only('serials') and $request->only('purchase_price'))
            {
                $serials = explode("\n", $request->input('serials'));
                foreach ($serials as $serial) {
                    $productVoucher = new ProductVoucher();
                    $productVoucher->serial = $serial;
                    $productVoucher->purchase_price = $request->input('purchase_price');
                    $productVoucher->product_id = $product->id;
                    $productVoucher->save();
                }
                if ($productVoucher->save())
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => 'serials',
                    ], 200);
                return response()->json([
                    'state' => null,
                    'message' => 'success',
                    'data' => '',
                ], 503);
            }
            elseif ($request->hasFile('serial_image') and $request->only('purchase_price'))
            {
                foreach ($request->file('serial_image') as $index => $image)
                {
                    $productVoucher = new ProductVoucher();
                    $productVoucher->purchase_price = $request->input('purchase_price')[$index];
                    $productVoucher->product_id = $product->id;
                    $productVoucher->image_uri = Storage::putFile('vouchers', $image);
                    $productVoucher->save();
                }
                if ($productVoucher->save())
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => 'serial_image',
                    ], 200);
                else
                    return response()->json([
                        'state' => null,
                        'message' => 'success',
                        'data' => '',
                    ], 503);
            }
            elseif ($request->only('serial_code') and $request->only('purchase_price'))
            {
                foreach ($request->input('serial_code') as $index => $serial) {
                    $productVoucher = new ProductVoucher();
                    $productVoucher->serial = $serial;
                    $productVoucher->purchase_price = $request->input('purchase_price')[$index];
                    $productVoucher->product_id = $product->id;
                    $productVoucher->save();
                }
                if ($productVoucher->save())
                    return response()->json([
                        'state' => true,
                        'message' => 'success',
                        'data' => 'serial_code',
                    ], 200);
                else
                    return response()->json([
                        'state' => null,
                        'message' => 'no',
                        'data' => '',
                    ], 503);
            }
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => '',
            ], 200);
        }
        else
        {
            return response()->json([
                'state' => null,
                'message' => 'success',
                'data' => '',
            ], 503);
        }
    }

    /**
     * Display the specified resource.
     * Author:
     *      Ability: Ahamad Montazeri
     *      Access Control: Mahtab Hakimzade
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, Product $product)
    {
        if (Gate::denies('view', $product))
            return response()->json([
                'state' => false,
                'message' => "access denies",
                'data' => null,
            ], 403);

        if ($request->has('vouchers'))
        {
            $response = $product->load('vouchers');
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $response,
            ], 200);
        }
        else
        {
            return response()->json([
                'state' => true,
                'message' => 'access denise',
                'data' => null,
            ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     *Author: Mahtab Hakimzade
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        if (Gate::denies('update', $product))
            return response()->json([
                'state' => false,
                'message' => "access denies",
                'data' => null,
            ], 403);

        $product->category()->associate($request->input('category'));
        $prices = [];
        foreach ($request->input('price') as $index => $price)
        {
            $prices[] = [(int)$request->input('from')[$index], (int)$request->input('to')[$index], (int)$price];
        }
        $product->price = $prices;
        if ($product->save())
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ], 200);

        return response()->json([
            'state' => false,
            'message' => 'services unavailable',
            'data' => null,
        ], 503);
    }

    /**
     * Remove the specified resource from storage.
     *
     * Author: Mahtab Hakimzade
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        if (Gate::denies('delete', $product))
            return response()->json([
                'state' => false,
                'message' => "access denies",
                'data' => null,
            ], 403);

        $product->delete();
        return response()->json([
            'state' => true,
            'message' => "success",
            'data' => null,
        ], 200);
    }

    /**
     * this method for filter
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function filter(Request $request)
    {
        $products = Product::query()->select(!auth()->guard('api')->check() ? ['id', 'category_id'] : '*');

        if ($request->has('price'))
            $products->whereRaw('JSON_EXTRACT(`price`, "$[0][2]") < ' . $request->input('price')[1])->whereRaw('JSON_EXTRACT(`price`, "$[0][2]") > ' . $request->input('price')[0]);
        if ($request->has('categories'))
            $products->whereIn('category_id', $request->input('categories'));

        $products = $products->with(['category', 'seller' => function ($query){
            $query->select('id', 'username', 'first_name', 'last_name');
        }])->paginate(30)->toArray();

        $products = $this->filtering($products, [
            'created_at' => null,
            'updated_at' => null,
            'visited' => null,
            'state' => null,
            'state_at' => null,
        ]);

        if ($products)
            return response()->json([
                'state' => true,
                'message' => "success",
                'data' => $products,
            ], 200);
    }
}
