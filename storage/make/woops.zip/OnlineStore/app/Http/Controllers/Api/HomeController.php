<?php

namespace App\Http\Controllers\Api;

use App\Brand;
use App\Http\Controllers\Controller;
use App\Product;
use App\ProductCategory;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * author: ahmad montazeri Edit => 9/17/2020 11:40 PM
     * description: return 5 brand with 5 categories with products in home page
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $brands = Brand::with('categories')
            ->has('categories.products', '>=', 5)
            ->take(5)
            ->get();

        if ($brands)
        {
            $b = [];
            foreach ($brands as $brand) {
                $b[$brand->name] = Product::with(['category', 'seller' => function ($query) {
                    $query->select('id', 'username', 'first_name', 'last_name');
                }])->whereHas('category', function ($query) use ($brand) {
                    $query->where('brand_id', $brand->id);
                })->take(5)->get()->toArray();
            }
            $pc = $this->filtering($b, [
                'visited' => null,
                'state' => null,
                'stated_at' => null,
                'created_at' => null,
                'updated_at' => null,
                'user_id' => null,
                'category_id' => null,
                'brand_id' => null,
                'price' => (auth()->guard('api')->check() ? -1 : null),
                'seller' => (auth()->guard('api')->check() ? -1 : null),
            ]);

            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $pc,
            ], 200);
        }
    }

    /**
     * author: ahmad montazeri
     * description: return product by id in home page
     * @param Product $product
     * @return \Illuminate\Http\JsonResponse
     */
    public function product(Product $product)
    {
        $product = $this->filtering($product->load(['category', 'seller' => function ($query){
            $query->select('id', 'username', 'first_name', 'last_name');
        }])->toArray(), [
            'updated_at' => null,
            'created_at' => null,
            'visited' => null,
            'state' => null,
            'stated_at' => null,
            'brand_id' => null,
            'user_id' => null,
            'price' => (auth()->guard('api')->check() ? -1 : null),
            'seller' => (auth()->guard('api')->check() ? -1 : null),
        ]);

        if ($product)
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $product
            ], 200);
    }

    /**
     * author: ahmad montazeri
     * description: return product with seller and category for slug category
     * @param ProductCategory $productCategory
     * @return \Illuminate\Http\JsonResponse
     */
    public function productOfCategory(ProductCategory $productCategory)
    {
        $products = Product::with(['seller' => function ($query){
            $query->select('id', 'username', 'first_name', 'last_name');
        }, 'category'])->where('category_id', $productCategory->id)->paginate(30);
        $products = $this->filtering($products->toArray(), [
            'created_at' => null,
            'updated_at' => null,
            'brand_id' => null,
            'user_id' => null,
            'category_id' => null,
            'visited' => null,
            'state' =>null,
            'stated_at' => null,
            'price' => (auth()->guard('api')->check() ? -1 : null),
            'seller' => (auth()->guard('api')->check() ? -1 : null),
        ]);

        if ($products)
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $products,
            ], 200);
    }

    /**
     * author: ahmad montazeri 9/14/2020 4:15 PM
     * description: return all brands with categories & products & seller
     * @return \Illuminate\Http\JsonResponse
     */
    public function brands()
    {
        $brands = Brand::with(['categories.products.seller' => function ($query){
            $query->select('id', 'username', 'first_name', 'last_name');
        }])->get();
        $brands = $this->filtering($brands->toArray(), [
            'created_at' => null,
            'updated_at' => null,
            'brand_id' => null,
            'user_id' => null,
            'price' => (auth()->guard('api')->check() ? -1 : null),
            'seller' => (auth()->guard('api')->check() ? -1 : null),
            'category_id' => null,
            'visited' => null,
            'state' =>null,
            'stated_at' => null
        ]);

        if ($brands)
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $brands
            ], 200);
    }
    /**
     *
     * author: ahmad montazeri 9/14/2020 3:00 PM
     * description: return product with category & seller
     * @param Brand $brand
     * @return \Illuminate\Http\JsonResponse
     */
    public function productOfBrand(Brand $brand)
    {
        $brand->load(['categories' => function ($query){
            $query->select('id', 'name', 'brand_id');
        }]);

        $products = Product::with(['category', 'seller' => function ($query){
            $query->select('id', 'username', 'first_name', 'last_name');
        }])->whereIn('category_id', $brand->categories->pluck('id'))->latest()->paginate(30);
        $products = $this->filtering($products->toArray(), [
            'created_at' => null,
            'updated_at' => null,
            'brand_id' => null,
            'user_id' => null,
            'price' => (auth()->guard('api')->check() ? -1 : null),
            'seller' => (auth()->guard('api')->check() ? -1 :null),
            'category_id' => null,
            'visited' => null,
            'state' =>null,
            'stated_at' => null]);

        if ($brand and $products)
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => [
                    'categories' => $brand->categories,
                    'products' => $products,
                ],
            ], 200);
    }
}
