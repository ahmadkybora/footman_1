<?php

namespace App\Http\Controllers\Api\Admin;

use App\Brand;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class BrandController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Gate::denies('viewAny', Brand::class))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }
        $brands = Brand::paginate(30);

        return response()->json([
            'state' => true,
            'message' => null,
            'data' => $brands,
        ], 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (Gate::denies('create', Brand::class))
        {
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);
        }

        $brand = new Brand();
        $brand->name = $request->input('brand');
        if ($brand->save())
            return response()->json([
                'state' => true,
                'message' => 'the brand saved successfully.',
                'data' => $brand,
            ], 200);

        return response()->json([
            'state' => false,
            'message' => null,
            'data' => null,
        ], 500);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Brand  $brand
     * @return \Illuminate\Http\Response
     */
    public function show(Brand $brand)
    {
        return response()->json([
            'state' => true,
            'message' => null,
            'data' => $brand,
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Brand  $brand
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Brand $brand)
    {
        if (Gate::denies('create', Brand::class))
        {
            return response()->json([
                'state' => false,
                'message' => "forbidden",
                'data' => null,
            ], 403);
        }

        $brand->name = $request->input('brand');
        if ($brand->save())
            return response()->json([
                'state' => true,
                'message' => 'the brand saved successfully.',
                'data' => $brand,
            ], 200);

        return response()->json([
            'state' => false,
            'message' => null,
            'data' => null,
        ], 500);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Brand  $brand
     * @return \Illuminate\Http\Response
     */
    public function destroy(Brand $brand)
    {
        if (!$brand->categories->count())
        {
            $brand->delete();
            return response()->json([
                'state' => true,
                'message' => 'the brand deleted successfully.',
                'data' => null,
            ], 200);
        }
        return response()->json([
            'state' => false,
            'message' => 'this brand has some category, so you cant delete it.',
            'data' => null,
        ], 403);
    }

    /**
     * Algorithm: elyass dehghan.
     * Development: ahmad montazeri.
     * Created At: 11/01/2020 12:10Am.
     * Modified At:.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function brands()
    {
        $brands = Brand::all();
        $brands = $this->filtering($brands->toArray(), [
            'slug' => null,
            'created_at' => null,
            'updated_at' => null,
        ]);

        if($brands)
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $brands,
        ], 200);
    }
}
