<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Requests\TransactionRequest;
use App\Transaction;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class TransactionController extends Controller
{
    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/21/2020 2:30PM
     * Modified At: 10/11/2020
     *
     * this method for display all transaction.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if(Gate::denies('view-any', Transaction::class))
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);

        $transactions = Transaction::query()->with(['owner' => function ($query) {
            $query->select('id', 'username', 'first_name', 'last_name');
        }]);

        if ($request->has('state')) {
            switch ($request->input('state')) {
                case "all":
                    $transactions = $transactions->paginate(30);
                    break;

                case "accepted":
                    $transactions = $transactions->whereNotNull('confirmed_at')->paginate(30);
                    break;

                case "pending":
                    $transactions = $transactions->whereNull('confirmed_at')->paginate(30);
                    break;

                default :
                    $transactions = $transactions->paginate(30);
            }
        }
        else
        {
            $transactions = $transactions->paginate(30);
        }

        if ($transactions)
            return response()->json([
                'state' => true,
                'message' => 'success!',
                'data' => $transactions,
            ], 200);

        return response()->json([
            'state' => false,
            'message' => 'service is unavailable!',
            'data' => null,
        ], 503);
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/23/2020 2:22PM
     * Modified At:
     *
     * this method for create transaction.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function store(TransactionRequest $request)
    {
        if (Gate::denies('create', [Transaction::class, $request->input('user')]))
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);

        return DB::transaction(function () use ($request)
        {
            $transaction = new Transaction();
            $transaction->transaction_code = $request->input('serial');
            $transaction->amount = $request->input('amount');
            $transaction->type = $request->input('transaction_type');
            $transaction->last_owner = ($request->input('user') ?? Auth::id());
            $transaction->owner()->associate($request->input('user') ?? Auth::id());
            if ($request->hasFile('receipt_uri'))
            {
                $image = $request->file('receipt_uri');
                $transaction->receipt_uri = Storage::putFile('transactions', $image);
            }
            if ($request->has('state'))
            {
                if ($request->input('state') === "accepted")
                {
                    $transaction->confirmed_at = Carbon::now();
                }
            }
            $transaction_state = $transaction->save();

            $user = $transaction->owner;
            $user->increaseCash($request->amount);
            $wallet = $user->save();

            if ($transaction_state and $wallet)
                return response()->json([
                    'state' => true,
                    'message' => 'success!',
                    'data' => null,
                ], 201);

            return response()->json([
                'state' => false,
                'message' => 'service is unavailable!',
                'data' => null,
            ], 503);
        });
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/23/2020 2:35PM
     * Modified At:
     *
     * this method for display transaction.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function show(Transaction $transaction)
    {
        if(Gate::denies('view', $transaction))
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);

        $transaction->load(['owner' => function ($query) {
            $query->select('id', 'username', 'first_name', 'last_name');
        }]);
        if ($transaction)
            return response()->json([
                'state' => true,
                'message' => 'success!',
                'data' => $transaction,
            ], 200);

        return response()->json([
            'state' => false,
            'message' => 'service is unavailable!',
            'data' => null,
        ], 503);
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/22/2020 10:29PM
     * Modified At:
     *
     * this method for update transaction before access admin.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function update(TransactionRequest $request, Transaction $transaction)
    {
        if(Gate::denies('update', [$transaction, $request->input('user')]))
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);

        $transaction->last_owner = $transaction->user_id;
        $transaction->transaction_code = $request->input('serial');
        $transaction->amount = $request->input('amount');
        $transaction->type = $request->input('transaction_type');
        if($request->has('state'))
        {
            if($request->input('state') === "accepted")
            {
                $transaction->confirmed_at = Carbon::now();
                $user = $transaction->owner;
                $user->increaseCash($transaction->amount);
                $user->save();
            }
        }
        $transaction->owner()->associate($request->input('user') ?? Auth::id());
        if($request->hasFile('receipt_uri'))
        {
            $image = $request->file('receipt_uri');
            $transaction->receipt_uri = Storage::putFile('transactions', $image);
        }
        if ($transaction->save())
            return response()->json([
                'state' => true,
                'message' => 'success!',
                'data' => null,
            ], 200);

        return response()->json([
            'state' => false,
            'message' => 'service is unavailable!',
            'data' => null,
        ], 503);
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 9/23/2020 10:28PM
     * Modified At:
     *
     * this method for delete transaction.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function destroy(Transaction $transaction)
    {
        if(Gate::denies('delete', $transaction))
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);

        if ($transaction->delete())
            return response()->json([
                'state' => true,
                'message' => 'success!',
                'data' => null,
            ], 200);

        return response()->json([
            'state' => false,
            'message' => 'service is unavailable!',
            'data' => null,
        ], 503);
    }

    /**
     * Algorithm: ahmad montazeri.
     * Development: ahmad montazeri.
     * Created At: 11/01/2020 11:00AM
     * Modified At:
     *
     * @param Transaction $transaction
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse
     */
    public function download(Transaction $transaction)
    {
        $headers = [
            'Cache-Control'             => 'must-revalidate, post-check=0, pre-check=0',
            'Expires'                   => '0',
            'Pragma'                    => 'public',
            'Content-Type'              =>  Storage::disk('local')->mimeType($transaction->receipt_uri),
            'Content-Disposition'       => 'attachment; filename="' . $transaction->transaction_code . '"',
            'Content-Description'       => 'File Transfer',
            'Content-Transfer-Encoding' => 'binary',
            'Content-Length'            =>  Storage::disk('local')->size($transaction->receipt_uri),
            'Access-Control-Allow-Origin' => "*",
            'Access-Control-Allow-Methods' => "PUT,POST,DELETE,GET,OPTIONS",
            'Access-Control-Allow-Headers' => "Accept,Authorization,Content-Type",
        ];
        return response()->download(storage_path("app/$transaction->receipt_uri"), $transaction->transaction_code, $headers);
    }
}
