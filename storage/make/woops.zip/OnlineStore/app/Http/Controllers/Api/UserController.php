<?php

namespace App\Http\Controllers\Api;

use App\City;
use App\Country;
use App\Http\Controllers\Controller;
use App\Http\Requests\ResetPasswordRequest;
use App\Http\Traits\General;
use App\Region;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\UserRequest;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
    use General;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        if (Gate::denies('view', $request->user()))
        {
            return response()->json([
                'state' => false,
                'message' => 'access denied',
                'data' => null,
            ], 403);
        }
        $user = $request->user()->load(['city', 'city.region', 'city.region.country']);
        $response = [
            'id' => $user['id'],
            'first_name' => $user['first_name'],
            'last_name' => $user['last_name'],
            'username' => $user['username'],
            'email' => $user['email'],
            'home_address' => $user['home_address'],
            'work_address' => $user['work_address'],
            'city_id' => $user['city_id'],
            'region_id' => $user->city->region->id,
            'country_id' => $user->city->region->country->id,
            'country' => Country::all(),
            'region' => Region::where('country_id', $user->city->region->country->id)->get(),
            'city' => City::where('region_id', $user->city->region->id)->get(),
            'mobile' => $user['mobile'],
            'postal_code' => $user['postal_code'],
            'avatar' => $user['avatar_uri'],
            'cash' => $user->cash,
            'credit' => 0,
        ];
        if ($user->hasRole('super-admin'))
            $permissions = 'all';
        else
            $permissions=$user->getAllPermissions();
        return response()->json([
            'state' => true,
            'message' => null,
            'data' => [
                'profile' => $response,
                'permissions' => $permissions
            ],
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\User $user
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request)
    {
        if(Gate::denies('update', $request->user()))
        {
            return response()->json([
                'state' => false,
                'message' => "access denied",
                'data' => null,
            ], 403);
        }

        $user=$request->user();
        if(is_null($user))
        {
            return response()->json([
                'state' => false,
                'message' => "user not found!",
                'data' => null
            ], 404);
        }
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->postal_code = $request->input('postal_code');
        $user->city_id = $request->input('city');
        $user->home_address = $request->input('home_address');
        $user->work_address = $request->input('work_address');
        if($request->hasFile('avatar'))
        {
            $path = Storage::disk('public')->putFile('images/avatars', $request->file('avatar'));
            if (!empty($user->avatar_uri) and file_exists('storage/' . $user->avatar_uri));
                Storage::disk('public')->delete($user->avatar_uri);
            $user->avatar_uri = $path;

            //$user->avatar_uri = $request->file('avatar')->store('/public/images/avatars');
        }
        if($user->save())
        {
            return response()->json([
                'state' => true,
                'message' => "user updated!",
                'data' =>null
            ], 200);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        //
    }

    /**
     * Making city and region list for ajax request.
     *
     * @param Request $request
     * @return array|string
     */
    public function location(Request $request)
    {
        $request->validate([]);

        if ($request->has('region'))
        {
            if (!is_array($request->input('region')) or (is_array($request->input('region')) and count($request->input('region')) === 1))
            {
                $city = City::whereRegionId($request->input('region'))->orderBy('name', 'asc')->pluck('name', 'id')->toArray();
                return json_encode($city);
            }
            return json_encode([]);

        }
        elseif($request->has('country'))
        {
            if (!is_array($request->input('country')) or (is_array($request->input('country')) and count($request->input('country')) === 1))
            {
                $region = Region::whereCountryId($request->input('country'))->orderBy('name', 'asc')->pluck('name', 'id')->toArray();
                return json_encode(['city' => '', 'region' => $region]);
            }

            return json_encode(['city' => '', 'region' => '']);
        }
        else
            {
            $country = Country::pluck('name', 'id')->toArray();
            return json_encode($country);
        }
        //return json_encode(['city' => '', 'region' => '']);
    }

    /**
     *
     * @param ResetPasswordRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function changePassword(ResetPasswordRequest $request)
    {
        if (Gate::denies('changePassword', $request->user()))
        {
            return response()->json([
                'state' => false,
                'message' => 'access denied',
                'data' => null,
            ], 403);
        }
        $user = $request->user();

        if (is_null($user))
        {
            return response()->json([
                'state' => false,
                'message' => "user not found!",
                'data' => null
            ], 404);
        }

        if (Hash::check($request->input('current_password'), $user->password))
        {
            $user->password = Hash::make($request->input('password'));
            if ($user->save())
            {
                return response()->json([
                    'state' => true,
                    'message' => "your password successfully changed!",
                    'data' => null,
                ], 200);
            }
        }

        return response()->json([
            'state' => false,
            'message' => "your password is invalid!",
            'data' => null
        ], 401);
    }
}


