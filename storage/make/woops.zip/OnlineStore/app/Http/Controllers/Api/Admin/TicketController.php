<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Requests\TicketRequest;
use App\Ticket;
use App\Http\Controllers\Controller;
use App\TicketDetail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;

//use App\Http\Controllers\Api\TicketController as BaseTicketController;

class TicketController extends Controller
{
    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 8/22/2020 9:00Am.
     * Modified At: 8/22/2020 9:00Am.
     *
     * the method is for index ticket admin
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Gate::denies('viewAny',Ticket::class))
        {
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        }
        $ticket = Ticket::paginate(30);
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $ticket
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 8/22/2020 9:00Am.
     * Modified At: 8/22/2020 9:00Am.
     *
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     *      title(string): title of ticket
     *      body(string): Body text of ticket
     *      priority(string: high, medium, low): the importance of tickets
     * @return \Illuminate\Http\Response
     */
    /*public function store(Request $request)
    {
        $ticket=new Ticket();
        $ticket->title = $request->input('title');
        $ticket->body = $request->input('body');
        $ticket->user()->associate(Auth::id());
        $ticket->priority = $request->input('priority');
        if($ticket->save())
        {
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ], 200);
        }

        return response()->json([
            'state' => true,
            'message' => 'server error',
            'data' => null,
        ], 500);
    }*/

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/23/2020 12:10Am.
     * Modified At: 9/23/2020 12:10Am.
     *
     * Display the specified resource.
     *
     * @param  \App\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    public function show(Ticket $ticket)
    {
        if(Gate::denies('view' , $ticket))
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        $ticket->details()->where('to_id', null)->whereNull('seen_at')->update(['seen_at' => Carbon::now()]);
        $ticket->seen_at = Carbon::now();
        $ticket->save();
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $ticket->load('details'),
        ],200);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/23/2020 12:10Am.
     * Modified At: 9/23/2020 12:10Am.
     *
     * Show the form for editing the specified resource.
     *
     * @param  \App\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    /*public function edit(Ticket $ticket)
    {
        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $ticket
        ],200);
    }*/

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/23/2020 10:00Am.
     * Modified At: 9/23/2020 10:00Am.
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    /*public function update(Request $request, Ticket $ticket)
    {
        $ticket->title = $request->input('title');
        $ticket->body = $request->input('body');
        $ticket->user()->associate($request->input('user_id'));
        $ticket->priority = $request->input('priority');
        if ($ticket->save())
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ],200);

        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => null,
        ],500);
    }*/

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/23/2020 9:00Am.
     * Modified At: 9/23/2020 9:00Am.
     *
     * Remove the specified resource from storage.
     *
     * @param  \App\Ticket  $ticket
     * @return \Illuminate\Http\Response
     */
    /*public function destroy(Ticket $ticket)
    {
        if($ticket->delete())
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => null,
            ],200);

        return response()->json([
            'state' => true,
            'message' => 'server error',
            'data' => null,
        ],500);
    }*/

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 8/22/2020 9:00Am.
     * Modified At: 8/22/2020 9:00Am.
     *
     * Show all the details of a ticket
     *
     * @param Request $request: None.
     * @param Ticket $ticket: Ticket id.
     * @return \Illuminate\Http\JsonResponse
     */

    /*public function indexDetails(Request $request , Ticket $ticket)
    {
        if(Gate::denies('details' , $ticket))
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        $count=count($ticket->details);
        if($count !=0)
        {
            $ticket->details[$count-1]->seen_at = Carbon::now();
            $ticket->save();
        }

        return response()->json([
            'state' => true,
            'message' => 'success',
            'data' => $ticket->details,
        ]);
    }*/

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 8/22/2020 9:20Am.
     * Modified At: 8/22/2020 10:10Am.
     *
     * Add details ticket.
     *
     * @param TicketRequest $request
     * @param Ticket $ticket
     * @return \Illuminate\Http\JsonResponse
     */

    public function storeDetails(TicketRequest $request,Ticket $ticket)
    {
        if(Gate::denies('restoreDetails' , $ticket))
            return response()->json([
                'state' => false,
                'message' => 'Access denies',
                'data' => null,
            ] , 403);
        $ticketDetails=new TicketDetail();
        $ticketDetails->body = $request->input('body');
        $ticketDetails->from_id = Auth::id();
        $ticketDetails->to_id = $ticket->user_id;
        $ticketDetails->ticket_id = $ticket->id;
        if($ticketDetails->save()){
            return response()->json([
                'state' => true,
                'message' => 'success',
                'data' => $ticketDetails,
            ], 200);
        }
        return response()->json([
            'state' => true,
            'message' => 'server error',
            'data' => null,
        ], 500);

    }
}
