<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function filtering($array, $indexes, $depth = 1)
    {
        if (is_array($array))
        {
            foreach ($array as $i => $v)
            {
                if (!is_numeric($i))
                    foreach ($indexes as $index_id => $index_depth)
                    {
                        if ($index_depth)
                        {
                            if ($i == $index_id and $depth <= $index_depth)
                            {
                                unset($array[$i]);
                            }
                        }
                        else
                        {
                            if ($i == $index_id)
                                unset($array[$i]);
                        }
                    }
            }

            foreach ($array as $i => $v)
            {
                $res = $this->filtering($array[$i], $indexes, $depth + 1);
                if ($res)
                    $array[$i] = $res;
            }

            return $array;
        }
        else
        {
            foreach ($indexes as $index)
                if ($index == $array)
                    return null;
            return $array;
        }
    }
}
