<?php

namespace App\Http\Requests;

use App\Imports\ProductVoucherImport;
use App\ProductVoucher;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Excel;

class ProductVoucherRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {
            case 'POST':
                return [
                    'serials.*' => ['bail', 'required_without_all:serial_image,serial_code,vouchers', /*'unique:product_vouchers,serial',*/
                        Rule::unique('product_vouchers', 'serial')
                            ->where('product_id', $this->product)
                    ],
                    'vouchers' => ['bail', 'required_without_all:serial_code,serial_image,serials', 'nullable', 'mimes:xls,xlsx,xlsb', 'max:1024'],
                    'purchase_price.*' => ['bail', 'required_without:vouchers', 'nullable', 'numeric', 'max:1000'],
                    'serial_code.*' => ['bail', 'required_without_all:serial_image,serials,vouchers', 'nullable', 'min:5', 'max:170',
                        Rule::unique('product_vouchers', 'serial')
                            ->where('product_id', $this->product)],
                    'serial_image.*' => ['required_without_all:serial_code,serials,vouchers', 'nullable', 'max:1024', 'mimes:png,jpeg'],
                    'product' => ['bail', 'required', Rule::exists('products', 'id')->where('user_id', auth()->id())]
                ];
                break;
            case 'PATCH':
                if (Auth::user()->isAdmin())
                {
                    if (! is_null($this->input('img_check')))
                    {
                        return [
                            'serial' => ['nullable', 'bail',
                                Rule::unique('product_vouchers', 'serial')
                                    ->where('product_id', $this->route('voucher')->product_id)
                                    ->ignore($this->route('voucher')->id)],
                            'purchase_price' => ['bail', 'nullable', 'numeric', 'max:1000'],
                            'serial_image' => ['nullable', 'bail', 'max:1024', 'mimes:png,jpeg'],
                            'product' => ['bail', 'required', Rule::exists('products', 'id')]
                        ];
                    }
                    else
                    {
                        return [
                            'serial' => ['bail', 'required_without:serial_image',
                                Rule::unique('product_vouchers', 'serial')
                                    ->where('product_id', $this->route('voucher')->product_id)
                                    ->ignore($this->route('voucher')->id)],
                            'purchase_price' => ['bail', 'nullable', 'numeric', 'max:1000'],
                            'serial_image' => ['bail', 'required_without:serial', 'nullable', 'max:1024', 'mimes:png,jpeg'],
                            'product' => ['bail', 'required', Rule::exists('products', 'id')]
                        ];
                    }
                }
                else
                {
                    if(! is_null($this->input('img_check')))
                    {
                        return [
                            'serial' => ['nullable','bail',
                                Rule::unique('product_vouchers', 'serial')
                                    ->where('product_id', $this->route('voucher')->product_id)
                                    ->ignore($this->route('voucher')->id)],
                            'purchase_price' => ['bail', 'nullable', 'numeric', 'max:1000'],
                            'serial_image' => ['nullable', 'bail', 'max:1024', 'mimes:png,jpeg'],
                            'product' => ['bail', 'required', Rule::exists('products', 'id')->where('user_id', auth()->id())]
                        ];
                    }
                    else
                    {
                        return [
                            'serial' => ['bail', 'required_without:serial_image',
                                Rule::unique('product_vouchers', 'serial')
                                    ->where('product_id', $this->route('voucher')->product_id)
                                    ->ignore($this->route('voucher')->id)],
                            'purchase_price' => ['bail', 'nullable', 'numeric', 'max:1000'],
                            'serial_image' => ['nullable', 'bail', 'required_without:serial', 'max:1024', 'mimes:png,jpeg'],
                            'product' => ['bail', 'required', Rule::exists('products', 'id')->where('user_id', auth()->id())]
                        ];
                    }

                }

                break;
        }
    }

    /**
     * Configure the validator instance.
     *
     * @param  \Illuminate\Validation\Validator $validator
     * @return void
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator)
        {
            /*if ($this->somethingElseIsInvalid()) {
                $validator->errors()->add('field', 'Something is wrong with this field!');
            }*/
            switch ($this->method) {
                case 'POST':
                    if ($this->has('serials'))
                        $this->merge(['serials' => implode("\n", $this->input('serials'))]);
                    break;
                case 'PATCH':
                    $this->offsetUnset('product');
                    break;
            }
        });
    }

    /**
     *
     *
     *
     *
     */
    protected function prepareForValidation()
    {
        switch ($this->method())
        {
            case 'POST':
                if ($this->has('serials'))
                {
                    $serials = explode("\n", $this->input('serials'));
                    $this->merge(['serials' => $serials]);
                }
                else if ($this->hasFile('vouchers'))
                {
                    $serials = $prices = [];
                    $vouchers = Excel::toArray(new ProductVoucherImport($this->product), $this->file('vouchers'));
                    foreach ($vouchers as $sheet_index => $sheet) {
                        foreach ($sheet as $voucher_index => $voucher) {
                            $serials[] = $voucher[0];
                            $prices[] = $voucher[1];
                        }
                    }
                    $this->merge(['serials' => $serials, 'purchase_price' => $prices]);
                }
                break;
            case 'PATCH':
                $product_voucher = ProductVoucher::find($this->voucher->id);
                $this->merge(['product' => $this->route('voucher')->product_id , 'img_check' => $product_voucher->image_uri]);
                break;
        }
    }

    /**
     * @return array
     */
    public function attributes()
    {
        $order = [
            1 => 'st',
            2 => 'nd',
            3 => 'rd',
        ];
        $attributes = [];

        switch ($this->method())
        {
            case 'POST':
                if ($this->has('serials'))
                    foreach ($this->input('serials') as $index => $value)
                        $attributes["serials.$index"] = ($index + 1) . ($index + 1 <= 3 ? $order[$index + 1] : "th") . " serial";
                elseif ($this->has('serial_code'))
                    foreach ($this->input('serial_code') as $index => $value)
                        $attributes["serial_code.$index"] = ($index + 1) . ($index + 1 <= 3 ? $order[$index + 1] : "th") . " serial";
                break;
            case 'PATCH':
                $attributes['product'] = 'serial';
                break;
        }

        return $attributes;
    }

    /**
     * @return array
     */
    public function messages()
    {
        $messages = [];
        switch ($this->method())
        {
            case 'POST':
                $messages = [
                    "serials.*" => "The :attribute ':input' has already been taken.",
                    "serial_code.*" => "The :attribute ':input' has already been taken.",
                    "serial" => "The serial_code :input has already been taken.",
                    "serial_code.*.required_without_all" => 'Please choose one of the import method',
                    "serials.required_without_all" => 'Please choose one of the import method',
                    "serial_image.*.required_without_all" => 'Please choose one of the import method',
                    "vouchers.required_without_all" => 'Please choose one of the import method',
                ];
                break;
            case 'PATCH':
                $messages['product'] = "The serial is incorrect";
                break;
        }
        return $messages;
    }
}
