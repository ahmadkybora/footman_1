<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class ProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {
            case 'POST':
                if(Auth::check() and !Auth::user()->isAdmin())
                {
                    return [
                        'category' => ['bail', 'required', 'exists:product_categories,id'],
                        "price.*" => ['bail', 'nullable', 'numeric', 'min:1'],
                        "price.0" => ['required'],
                        "from.*" => ['bail', 'numeric', 'nullable', 'lt:to.*'],
                        "from.0" => ['bail', 'required', 'lt:to.0'],
                        "to.*" => ['nullable', 'numeric'],
                        "to.0" => ['required'],
                        'vouchers' => ['bail', 'required_without_all:serial_code,serial_image,serials', 'nullable', 'mimes:xls,xlsx,xlsb', 'max:1024'],
                        'purchase_price.*' => ['bail', 'required_without:vouchers', 'nullable', 'numeric', 'max:1000'],
                        'serial_code.*' => ['bail', 'required_without_all:serial_image,serials,vouchers', 'nullable', 'min:5', 'max:170'],
                        'serial_image.*' => ['bail', 'required_without_all:serial_code,serials,vouchers', 'nullable', 'max:1024', 'mimes:png,jpeg'],
                        'serials' => ['required_without_all:serial_image,serial_code,vouchers']
                    ];
                }
                else
                {
                    return [
                        'category' => ['bail', 'required', 'exists:product_categories,id'],
                        "price.*" => ['bail', 'nullable', 'numeric', 'min:1'],
                        "price.0" => ['required'],
                        "from.*" => ['bail', 'numeric', 'nullable', 'lt:to.*'],
                        "from.0" => ['bail', 'required', 'lt:to.0'],
                        "to.*" => ['nullable', 'numeric'],
                        "to.0" => ['required'],
                        'vouchers' => ['bail', 'required_without_all:serial_code,serial_image,serials', 'nullable', 'mimes:xls,xlsx,xlsb', 'max:1024'],
                        'purchase_price.*' => ['bail', 'required_without:vouchers', 'nullable', 'numeric', 'max:1000'],
                        'serial_code.*' => ['bail', 'required_without_all:serial_image,serials,vouchers', 'nullable', 'min:5', 'max:170'],
                        'serial_image.*' => ['bail', 'required_without_all:serial_code,serials,vouchers', 'nullable', 'max:1024', 'mimes:png,jpeg'],
                        'serials' => ['required_without_all:serial_image,serial_code,vouchers'],
                        'user' => ['exist:users,id']
                    ];
                    }
                /*
                * چک می کند که ایا تمام ارایه ک هست داخلشون مقدار داره یا نه
               * اگه مقدار همشون null بود خودمون به اعتبار سنجی مقدار required میدیم
                */
                /*foreach ($this->input('price') as $price)
                    if ($price != null)
                        return $valid;
                $valid['price.0'] = ['required', 'numeric', 'max:10000'];
                return $valid;*/

                break;
            case "PATCH":
                if(Auth::check() and !Auth::user()->isAdmin())
                {
                    return [
                        'category' => ['bail', 'required', 'exists:product_categories,id'],
                        "price.*" => ['required', 'numeric', 'min:1'],
                        "from.*" => ['required', 'numeric', 'lt:to.*'],
                        "to.*" => ['required', 'numeric'],
                    ];
                }
                else
                {
                    return [
                        'category' => ['bail', 'required', 'exists:product_categories,id'],
                        "price.*" => ['required', 'numeric', 'min:1'],
                        "from.*" => ['required', 'numeric', 'lt:to.*'],
                        "to.*" => ['required', 'numeric'],
                        "user" => ['exists:users,id']
                    ];
                }
                break;
        }
    }

    public function messages()
    {
        return [
            "serial_code.*.required_without_all" => 'Please choose one of the import method',
            "serials.required_without_all" => 'Please choose one of the import method',
            "serial_image.*.required_without_all" => 'Please choose one of the import method',
            "vouchers.required_without_all" => 'Please choose one of the import method',
        ];
    }
}
