<?php

namespace App\Http\Requests;

use App\ProductVoucher;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class PaymentRequest extends FormRequest
{
    private $user;

    public function __construct(array $query = [], array $request = [], array $attributes = [], array $cookies = [], array $files = [], array $server = [], $content = null)
    {
        $this->user = Auth::user();
        parent::__construct($query, $request, $attributes, $cookies, $files, $server, $content);
    }

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return !is_null($this->user->cart);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        foreach ($this->user->cart->products as $product)
        {
            $available_quantity[$product->id] = ProductVoucher::where('product_id', $product->id)->whereNull('metadata')->count();
        }

        $validation = [
            'total_price' => ['required', 'numeric', 'max:'.$this->user->cash],
        ];
        foreach ($this->user->cart->items as $item)
        {
            $validation['ordered_quantity_' . $item[0]] = ['max:' . $available_quantity[$item[0]]];
        }
        return $validation;
    }

    protected function prepareForValidation()
    {
        if (!is_null($this->user->cart))
        {
            $ordered_query = [];
            foreach ($this->user->cart->items as $item)
            {
                $ordered_query[$item[0]] = $item[1];
            }
            $this->merge(['ordered_quantity_' . $item[0] => $item[1]]);

            $this->merge(['total_price' => $this->user->cart->price]);
        }

    }

    public function messages()
    {
        $messages =  [
            'total_price.max' => 'Your wallet balance is not enough',
        ];
        foreach ($this->user->cart->items as $item)
        {
            $messages['ordered_quantity_' . $item[0] . '.max'] = 'The number requested is more than the inventory.';
        }
        return $messages;
    }
}
