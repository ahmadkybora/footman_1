<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;

class TransactionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * author: ahmad montazeri 9/13/2020 4:48 PM
     *
     * @return array
     */
    public function rules()
    {
        switch ($this->method()) {

            case "GET":
                if (Auth::check() and $this->route()->getName() == 'api.account.download-transaction')
                    return [];
            break;

            case "POST":
                if(Auth::check())
                {
                    if ($this->route()->getName() == 'api.account.transaction.store')
                    {
                        if (Schema::connection('account')->hasTable('transactions_' . Auth::id()))
                            return [
                                'serial' => ['bail', 'required', 'unique:mysql.transactions,transaction_code', 'unique:account.transactions_' . Auth::id() . ',transaction_code', 'numeric'],
                                'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                                'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512']
                            ];
                        return [
                            'serial' => ['bail', 'required'],
                            'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                            'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512']
                        ];
                    }
                    elseif ($this->route()->getName() == 'api.account.admin.transaction.store' and Auth::user()->isAdmin())
                    {
                        if (Schema::connection('account')->hasTable('transactions_' . $this->input('user')))
                            return [
                                'serial' => ['bail', 'required', 'unique:mysql.transactions,transaction_code', 'unique:account.transactions_' . Auth::id() . ',transaction_code', 'numeric'],
                                'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                                'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512'],
                                'user' => ['required', 'exists:users,id'],
                            ];
                        return [
                            'serial' => ['bail', 'required'],
                            'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                            'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512'],
                            'user' => ['required', 'exists:users,id'],
                        ];
                    }
                }
                break;

            case "PATCH":
                if (Auth::check())
                {
                    if ($this->route()->getName() == 'api.account.transaction.update')
                    {
                        return [
                            'serial' => ['bail', 'required', 'unique:mysql.transactions,transaction_code,' . $this->route('transaction')->system_transaction_id, 'unique:account.transactions_' . Auth::id() . ',transaction_code,' . $this->route('transaction')->id, 'numeric'],
                            'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                            'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512']
                        ];
                    }
                    elseif ($this->route()->getName() == 'api.account.admin.transaction.update' and Auth::user()->isAdmin())
                    {
                        return [
                            'serial' => ['bail', 'required', 'unique:mysql.transactions,transaction_code,' . $this->route('transaction')->id, 'unique:account.transactions_' . $this->input('user') . ',transaction_code,' . $this->route('transaction')->id, 'numeric'],
                            //                        'serial' => ['bail', 'required', Rule::unique('mysql.transactions', 'transaction_code')
                            //                            ->where('id', $this->route('transaction')->id)
                            //                            ->whereNotNull('confirmed_at')
                            //                            ->ignore($this->route('transaction')->id), 'numeric'],
                            'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                            'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512'],
                            'confirmed_at' => ['bail', 'required', 'in:0'],
                            'user' => ['required', 'exists:users,id']
                        ];
                    }
                }

                /*if(Auth::check() and !Auth::user()->isAdmin())
                    return [
                        'serial' => ['bail', 'required', 'unique:mysql.transactions,transaction_code,' . $this->route('transaction')->system_transaction_id, 'unique:account.transactions_' . Auth::id() . ',transaction_code,' . $this->route('transaction')->id, 'numeric'],
                        'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                        'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512']
                    ];
                else
                {
                    if($this->route()->getName() == 'api.account.transaction.update')
                        return [
                            'serial' => ['bail', 'required', 'unique:mysql.transactions,transaction_code,' . $this->route('transaction')->id, 'numeric'],
//                        'serial' => ['bail', 'required', Rule::unique('mysql.transactions', 'transaction_code')
//                            ->where('id', $this->route('transaction')->id)
//                            ->whereNotNull('confirmed_at')
//                            ->ignore($this->route('transaction')->id), 'numeric'],
                            'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                            'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512'],
                            'confirmed_at' => ['bail', 'required', 'in:0'],
                            'user' => ['exists:users,id']
                        ];
                    return [
                        'serial' => ['bail', 'required', 'unique:mysql.transactions,transaction_code,' . $this->route('transaction')->id, 'numeric'],
//                        'serial' => ['bail', 'required', Rule::unique('mysql.transactions', 'transaction_code')
//                            ->where('id', $this->route('transaction')->id)
//                            ->whereNotNull('confirmed_at')
//                            ->ignore($this->route('transaction')->id), 'numeric'],
                        'amount' => ['bail', 'required', 'numeric', 'min:1', 'max:1000000'],
                        'receipt_uri' => ['image', 'mimes:jpeg,png', 'max:512'],
                        'confirmed_at' => ['bail', 'required', 'in:0'],
                        'user' => ['exists:users,id']
                    ];
                }

                break;*/
        }
    }

    /**
     * Algorithm: engineer mr dehghan.
     * Development: haj ahmad totonchian.
     * Created At: 10/18/2020 3:15pm.
     * Modified At:
     *
     * this method for deleted validate confirmed_at after validation
     * @param $validator
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator)
        {
            if ($this->method() == 'PATCH')
            {
                $this->offsetUnset('confirmed_at');
            }
        });
    }

    /**
     * Algorithm: engineer mr dehghan.
     * Development: haj ahmad totonchian.
     * Created At: 10/18/2020 3:15pm.
     * Modified At:
     *
     * this method for prepare validation
     */
    protected function prepareForValidation()
    {
        if ($this->method() == 'PATCH')
        {
            if (!is_null($this->route('transaction')->confirmed_at))
                $this->merge(['confirmed_at' =>1]);
            else
                $this->merge(['confirmed_at' => 0]);
        }
    }

    /**
     * Algorithm: engineer mr dehghan.
     * Development: haj ahmad totonchian.
     * Created At: 10/18/2020 3:15pm.
     * Modified At:
     *
     * this method for customize message
     * @return array
     */
    public function messages()
    {
        if ($this->method() == 'PATCH')
        {
            return ['confirmed_at.in' => "The transaction has already been approved.so you cant update it"];
        }
        return [];
    }
}
