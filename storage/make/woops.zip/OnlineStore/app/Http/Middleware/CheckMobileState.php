<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class CheckMobileState
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (Auth::check())
        {
            $user = Auth::user();
            if (!is_null($user->mobile_verified_at))
                return $next($request);
        }

        return response()->json([
            'state' => false,
            'message' => "تلفن همراه شما احراز نشده است",
            'data' => null,
        ], 401);
    }
}
