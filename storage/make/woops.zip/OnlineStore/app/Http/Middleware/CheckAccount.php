<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class CheckAccount
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $account)
    {
        if (!Auth::check() or ($account == 'admin' and !Auth::user()->isAdmin()) or ($account == 'customer' and Auth::user()->isAdmin()))
            return response()->json([
                'state' => false,
                'message' => 'access denies',
                'data' => null,
            ], 403);

        return $next($request);
    }
}
