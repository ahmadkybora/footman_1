<?php
/**
 * Created by PhpStorm.
 * User: Elyass
 * Date: 07/07/2020
 * Time: 11:34 AM
 */

namespace App\Http\Traits;


use App\Product;

trait General
{
    /**
     * @param array $mobileNumbers
     * @param string $message
     */
    public function sendSms($mobileNumbers, $message)
    {
        try
        {
            $sender = "1000551451";
            $receptor = $mobileNumbers;
            //$result = Kavenegar::Send($sender,$receptor,$message);
            //$result = Kavenegar::VerifyLookup($receptor,$message);
            $api = new Kavenegar\KavenegarApi('2B71483976455846775243652F5955766D47392B4C4C4B464C50565633394B364F4C44373572393049696B3D');
            $result = $api->VerifyLookup($receptor,'123456', '', '', 'verifyHamiPlus', 'sms');
            if($result){
                return $result;
                /*foreach($result as $r){
                    echo "messageid = $r->messageid";
                    echo "message = $r->message";
                    echo "status = $r->status";
                    echo "statustext = $r->statustext";
                    echo "sender = $r->sender";
                    echo "receptor = $r->receptor";
                    echo "date = $r->date";
                    echo "cost = $r->cost";
                }*/
            }
        }
        catch(\Kavenegar\Exceptions\ApiException $e)
        {
            // در صورتی که خروجی وب سرویس 200 نباشد این خطا رخ می دهد
            echo $e->errorMessage();
        }
        catch(\Kavenegar\Exceptions\HttpException $e)
        {
            // در زمانی که مشکلی در برقرای ارتباط با وب سرویس وجود داشته باشد این خطا رخ می دهد
            echo $e->errorMessage();
        }
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 9/21/2020 10PM
     * Modified At: 9/22/2020 10:39AM
     *
     * this method for calculate price.
     *
     * @param  \Illuminate\Http\Request  $request: none
     * @return \Illuminate\Http\Response
     */
    public function calculatePrice($items)
    {
        $total_price = 0;
        foreach ($items as $item)
        {
            $selected_price = 0;
            $product = Product::where('id', $item[0])->firstOrFail();
            foreach ($product->price as $index => $price)
            {
                if ($item[1] >= $price[0] and $item[1] <= $price[1])
                {
                    $selected_price = $price[2];
                    break;
                }
            }
            $total_price += ($selected_price * $item[1]);
        }
        return $total_price;
    }
}
