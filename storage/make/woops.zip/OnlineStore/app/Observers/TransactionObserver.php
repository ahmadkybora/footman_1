<?php

namespace App\Observers;

use App\Transaction;
use App\UserTransaction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;

class TransactionObserver
{
    /**
     * Algorithm: mr engineer elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 01/06/2020 12:01PM
     * Modified At:
     *
     * Handle the transaction "created" event.
     *
     * @param  \App\Transaction  $transaction
     * @return void
     */
    public function created(Transaction $transaction)
    {
        $userTransaction = new UserTransaction($transaction->user_id);
        $userTransaction->transaction_code = $transaction->transaction_code;
        $userTransaction->amount = $transaction->amount;
        $userTransaction->system_transaction_id = $transaction->id;
        $userTransaction->type = $transaction->type;
        $userTransaction->confirmed_at = $transaction->confirmed_at;
        $userTransaction->receipt_uri = $transaction->receipt_uri;
        $userTransaction->save();
    }

    /**
     * Algorithm: mr engineer elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 01/06/2020 12:01PM
     * Modified At:
     *
     * Handle the transaction "updated" event.
     *
     * @param  \App\Transaction  $transaction
     * @return void
     */
    public function updated(Transaction $transaction)
    {
        $lastUserTransaction = Transaction::forUser($transaction->last_owner)->where('system_transaction_id', $transaction->id)->first();
        if(Auth::user()->isAdmin() and Request::route()->getName() == 'api.account.admin.transaction.update' and $lastUserTransaction)
            $lastUserTransaction->delete();

        $userTransaction = Transaction::forUser($transaction->user_id)->where('system_transaction_id', $transaction->id)->first();
//        dd($userTransaction);
        if ($userTransaction)
        {
            $userTransaction->transaction_code = $transaction->transaction_code;
            $userTransaction->amount = $transaction->amount;
            $userTransaction->system_transaction_id = $transaction->id;
            $userTransaction->receipt_uri = $transaction->receipt_uri;
            $userTransaction->confirmed_at = $transaction->confirmed_at;
            $userTransaction->save();
        }
        else
        {
            $userTransaction = new UserTransaction($transaction->user_id);
            $userTransaction->transaction_code = $transaction->transaction_code;
            $userTransaction->amount = $transaction->amount;
            $userTransaction->system_transaction_id = $transaction->id;
            $userTransaction->receipt_uri = $transaction->receipt_uri;
            $userTransaction->confirmed_at = $transaction->confirmed_at;
            $userTransaction->save();
        }

        /*Log::info('OK');
        $user = $transaction->user_id;
        $transaction->forUser($user)->save();
        die();*/
    }
    /**
     * Algorithm: elyas engineer dehghan.
     * Development: ahmad montazeri.
     * Created At: 01/06/2020 12:01PM
     * Modified At:
     *
     * Handle the transaction "deleted" event.
     *
     * @param  \App\Transaction  $transaction
     * @return void
     */
    public function deleted(Transaction $transaction)
    {
        Transaction::forUser($transaction->user_id)->where('system_transaction_id', $transaction->id)->first()->delete();
    }

    /**
     * Handle the transaction "restored" event.
     *
     * @param  \App\Transaction  $transaction
     * @return void
     */
    public function restored(Transaction $transaction)
    {
        //
    }

    /**
     * Handle the transaction "force deleted" event.
     *
     * @param  \App\Transaction  $transaction
     * @return void
     */
    public function forceDeleted(Transaction $transaction)
    {
        //
    }
}
