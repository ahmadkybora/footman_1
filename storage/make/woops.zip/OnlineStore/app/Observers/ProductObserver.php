<?php

namespace App\Observers;

use App\Http\Traits\General;
use App\Product;
use App\User;

class ProductObserver
{
    use General;

    /**
     * Handle the product "created" event.
     *
     * @param  \App\Product  $product
     * @return void
     */
    public function created(Product $product)
    {
        //
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: Sina Khaghani.
     * Created At: 9/27/2020 15:20.
     * Modified At: 9/27/2020 15:20.
     * این متد برای بروز رسلنی قیمت ها در سبد خرید کاربرانی میباشد که هنوز وضعیت آنها paid نشده است
     * Handle the product "updated" event.
     *
     * @param  \App\Product  $product
     * @return void
     */
    public function updated(Product $product)
    {
        $users = User::all();
        foreach ($users as $user)
        {
            if ($user->cart)
            {
                $total_price = $this->calculatePrice($user->cart->items);
                $cart = $user->cart;
                $cart->price = $total_price;
                $cart->save();
            }
        }
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 9/27/2020 15:00Pm.
     * Modified At: 9/27/2020 15:00Pm.
     *
     * Handle the product "deleted" event.
     *
     * @param  \App\Product  $product
     * @return void
     */
    public function deleted(Product $product)
    {
        $product->vouchers()->delete();
    }

    /**
     * Handle the product "restored" event.
     *
     * @param  \App\Product  $product
     * @return void
     */
    public function restored(Product $product)
    {
        //
    }

    /**
     * Handle the product "force deleted" event.
     *
     * @param  \App\Product  $product
     * @return void
     */
    public function forceDeleted(Product $product)
    {
        //
    }
}
