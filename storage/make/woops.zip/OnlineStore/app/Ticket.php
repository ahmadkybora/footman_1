<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'title',
        'body',
        'priority',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'user_id',
        'closer_id',
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    /**
     * This method sets relation between users and tickets.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        /*
         * "Has City" relation is "1 to Many"
         * City is "Many" side
         * Region (1)<===Has City===>(N) City
         */
        return $this->belongsTo('App\User', 'user_id');
    }

    /**
     * This method sets relation between users and tickets.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function closer()
    {
        return $this->belongsTo('App\User', 'closer_id');
    }

    /**
     * This method sets relation between ticket_details and tickets.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function details()
    {
        return $this->hasMany('App\TicketDetail', 'ticket_id');
    }
}
