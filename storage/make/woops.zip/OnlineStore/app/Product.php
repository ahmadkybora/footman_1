<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Product extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'price',
        'visited',
        'state',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'user_id',
        'category_id',
    ];

    /**
     * The attributes that have date format.
     *
     * @var array
     */
    protected $dates = [
        'stated_at',
    ];

    /**
     * The attributes that casted to specific data type.
     *
     * @var array
     */
    protected $casts = [
        'price' => 'array',
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */
    public function priceOf($quantity)
    {
        foreach ($this->price as $price)
        {
            if ($price[0] <= (int)$quantity and $price[1] >= (int)$quantity)
                return $price[2];
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    /**
     * This method sets relation between products and product_categories.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function category()
    {
        /*
         * "Has City" relation is "1 to Many"
         * City is "Many" side
         * Region (1)<===Has City===>(N) City
         */
        return $this->belongsTo('App\ProductCategory', 'category_id');
    }

    /**
     * This method sets relation between products and users.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function seller()
    {
        return $this->belongsTo('App\User', 'user_id');
    }

    /**
     * This method sets relation between products and orders.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany|string
     */
    public function orders()
    {
        $table =  'order_product';
        if (Auth::user()->isAdmin())
            return 'order_product_' . Auth::id();
        return $this->belongsToMany('App\Order', $table, 'product_id', 'order_id')->using('App\OrderProduct');
    }

    public function vouchers()
    {
        return $this->hasMany('App\ProductVoucher', 'product_id');
    }

    public function soldVouchers()
    {
        return $this->hasMany('App\ProductVouchers', 'product_id')->whereNotNull('buyer_order_id');
    }
}
