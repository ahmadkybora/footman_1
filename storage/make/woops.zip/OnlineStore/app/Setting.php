<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'option_name',
        'option_value',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */
    /**
     * Accessor to unserialize the field option_value.
     *
     * @return mixed
     */
    public function getOptionValueAttribute()
    {
        return unserialize($this->option_value);
    }

    /**
     * Mutator to serializing the value of the field option_value.
     *
     * @param $value
     */
    public function setOptionValueAttribute($value)
    {
        $this->attributes['option_value'] = serialize($value);
    }

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
}
