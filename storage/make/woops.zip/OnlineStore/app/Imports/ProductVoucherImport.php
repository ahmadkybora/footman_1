<?php

namespace App\Imports;

use App\ProductVoucher;
use Maatwebsite\Excel\Concerns\ToModel;

class ProductVoucherImport implements ToModel
{
    private $product;

    public function __construct($product)
    {
        $this->product = $product;
    }

    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        $voucher = new ProductVoucher();
        $voucher->serial = $row[0];
        $voucher->purchase_price = $row[1];
        $voucher->product()->associate($this->product);
        return $voucher;
    }
}
