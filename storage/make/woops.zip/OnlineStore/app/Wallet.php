<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wallet extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'credit',
        'cash',
        'state',
        'state_modified_at',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'owner_id',
        'state_modifier_id',
    ];

    /**
     * The attributes that have date format.
     *
     * @var array
     */
    protected $dates = [
        'locked_at',
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    /**
     * This method sets relation between wallets and users.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function owner()
    {
        /*
         * "Has Regions" relation is "1 to Many"
         * Region is "Many" side
         * Country (1)<===Has City===>(N) Region
         */
        return $this->belongsTo('App\User', 'owner_id');
    }

    /**
     * This method sets relation between wallets and users.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function stateModifier()
    {
        /*
         * "Has City" relation is "1 to Many"
         * Province is "1" side
         * Province (1)<===Has City===>(N) City
         */
        return $this->hasMany('App\User', 'state_modifier_id');
    }
}
