<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;

class UserTransaction extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'transaction_code',
        'amount',
        'type',
        'receipt_uri',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'system_transaction_id',
    ];

    private $user;

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */
    public function __construct($user = null, array $attributes = [])
    {
        if (!empty($user))
        {
            if (!is_a($user, 'App\User'))
                $this->user = User::findOrFail($user);
        }
        else
        {
            if (!Auth::check())
                exit(403);
            else
                $this->user = Auth::user();
        }

        if (!Schema::connection('account')->hasTable('transactions_' . $this->user->id))
        {
            Schema::connection('account')->create('transactions_' . $this->user->id, function (Blueprint $table){
                $table->id();
                $table->unsignedInteger('transaction_code')->unique();
                $table->decimal('amount');
                $table->foreignId('system_transaction_id')->nullable(); // This field is defined just in transactions_{x} tables for each user.
                /*
                 * Dictionary:
                 *      DCU: Decreasing Cash Of User
                 *      ICU: Increasing Cash Of User
                 *
                 * CHECKOUT: DCU.
                 * CHARGE: ICU.
                 */
                $table->enum('type', ['CHARGE', 'CHECKOUT','SELL','BUY']); // The reason of transaction.

                /*
                 * System scheduled robot checks the transactions every special period (for example every night)and performs the related operations and sets the confirmed_at.
                 *
                 * زمانیکه خریدار پرداختی را انجام بدهد، یک رکورد تراکنش به میزان پرداخت کاربر به جدول transactions که مرتبط با سیستم است اضافه میشود. فیلد confirmed_at این رکورد در لحظه ثبت پر میشود و به کیف پول سیستم مبلغ اضافه میشود.
                 * سپس یک رکورد دیگر هم در همین جدول ایجاد میشود که از نوع پرداختی است و فیلد confirmed_at آن null خواهد. این فیلد هم برای گزارشات ادمین است که مشخص کند چقدر واریزی قرار است انجام شود و هم به عنوان تراکنش واریز حق فروشنده.
                 * پس از اجرای موفق دو عملیات فوق، مقدار پرداختی کاربر منهای سود شرکت به عنوان یک رکورد تراکنش به جدول تراکنش های مختص فروشنده اضافه میشود. فیلد confirmed_at این رکورد null خواهد بود و فیلد system_transaction_id آن برابر با id تراکنش فوق خواهد بود.
                 * سپس ربات زمانبندی شده سیستم در بازه های مشخصی از زمان تراکنش ها را بررسی میکند و تراکنش های مختص فروشنده را تایید کرده و از طریق فیلد system_transaction_id تراکنش های مرتبط با این تراکنش ها را در جدول تراکنشهای سیستم تایید میکند و در نهایت مبلغ تایید شده از کیف پول سیستم کسر شده و به کیف پول فروشنده اضافه میگردد.
                 *
                 */
                $table->dateTime('confirmed_at')->nullable();

                $table->string('receipt_uri')->nullable();

                //$table->boolean('cashed_in'); // This field is defined just in transactions_{x} tables for each user.

                $table->timestamps();

            });
        }

        parent::__construct($attributes);
    }
    // به جای این روش با ایجاد متود construct در مدل Transaction مشکل تعویض کانکشن حل شد
    /*public function __destruct()
    {
        $transaction = new \App\Transaction();
        $transaction->setConnection('mysql');



        // TODO: Implement __destruct() method.
    }*/

    /**
     * Transaction model has many table.
     * Each buyer user has own self orders table.
     * This method changes the Transaction model's table according to buyer user.
     *
     * @param $table
     * @return string
     */
    public function getTable()
    {
        //if (Auth::check())
        if ($this->user)
            //$this->setTable('transactions_' . Auth::id());
            $this->setTable('transactions_' . $this->user->id);

        /*
         * Attention: We must checks the connection's table's prefix.
         */
        return parent::getTable(); // TODO: Change the autogenerated stub
    }

    /**
     * This methods changes the connection (database)for each buyer user dynamically.
     *
     * @return string
     */
    public function getConnection()
    {
        //if (Auth::check())
        if ($this->user)
            $this->setConnection('account');

        return parent::getConnection(); // TODO: Change the autogenerated stub
    }

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    /**
     * This method sets relation between orders and transactions.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function orders()
    {
        return $this->belongsTo('App\Order', 'transaction_id');
    }

    /**
     * This method used by transactions_{x} of user with id x to return .
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function systemTransaction()
    {
        return $this->belongsTo('App\Transaction', 'system_transaction_id');
    }

    /*
     * Transaction can be polymorphism relation between order, ...
     */
}
