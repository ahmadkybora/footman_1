<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'region_id',
    ];

    /**
     * This attribute revoke timestamps attributes.
     *
     * @var bool
     */
    public $timestamps = false;

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    /**
     * This method sets relation between regions and cities.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function region()
    {
        /*
         * "Has City" relation is "1 to Many"
         * City is "Many" side
         * Region (1)<===Has City===>(N) City
         */
        return $this->belongsTo('App\Region', 'region_id');
    }

    /**
     * This method sets relation between cities and users.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function users()
    {
        return $this->hasMany('App\User', 'city_id');
    }
}
