<?php

namespace App\Providers;

use App\Observers\ProductObserver;

use App\Observers\TicketObserver;
use App\Product;
use App\Ticket;
use App\Observers\TransactionObserver;
use App\Transaction;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Product::observe(ProductObserver::class);
        Ticket::observe(TicketObserver::class);
        Transaction::observe(TransactionObserver::class);
        Schema::defaultStringLength(191);
    }
}
