<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SellerTicket extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'title',
        'body',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'voucher_id',
        'buyer_id',
        'seller_id',
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */

    /**
     * Algorithm: sina khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 12:50 Am.
     * Modified At:. 10/22/2020 12:50 by ahmad montazeri.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function voucher()
    {
        return $this->belongsTo('App\ProductVoucher', 'voucher_id');
    }

    /**
     * Algorithm: sina khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 12:50 Am.
     * Modified At:. 10/22/2020 12:50 by ahmad montazeri.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function seller()
    {
        return $this->belongsTo('App\User', 'seller_id');
    }

    /**
     * Algorithm: sina khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 12:50 Am.
     * Modified At:. 10/22/2020 12:50 by ahmad montazeri.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function buyer()
    {
        return $this->belongsTo('App\User', 'buyer_id');
    }

    /**
     * Algorithm: sina khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 12:50 Am.
     * Modified At:. 10/22/2020 12:50 by ahmad montazeri.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function sellerTicketDetails()
    {
        return $this->hasMany('App\SellerTicketDetail', 'seller_ticket_id');
    }
}
