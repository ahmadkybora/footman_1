<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Auth;
use App\User;
use Illuminate\Support\Facades\Schema;
use App\Layers\Models\Transaction as SystemTransaction;

class Transaction extends SystemTransaction
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'transaction_code',
        'amount',
        'type',
        'receipt_uri',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'user_id',
        'last_owner',
    ];
    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */
    // با این متود مشکل تعویض کانکشن حل شد
    public function __construct(array $attributes = [])
    {
        self::$env['connection'] = 'mysql';
        self::$env['table'] = 'transactions';
        parent::__construct($attributes);
    }

    function __destruct()
    {
        if ($this->getTable() !== 'transactions' and !$this->count())
        {
            Schema::connection(self::$env['connection'])->dropIfExists(self::$env['table']);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */

    /**
     * This method sets relation between orders and transactions.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function orders()
    {
        return $this->hasOne('App\Order', 'transaction_id');
    }

    /**
     * This method used by transactions_{x} of user with id x to return.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function userTransaction()
    {
        return $this->hasOne('App\UserTransaction', 'system_transaction_id');
    }

    /**
     * This method sets relation between users and transactions.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function owner()
    {
        return $this->belongsTo('App\User', 'user_id');
    }

    /*
     * Transaction can be polymorphism relation between order, ...
     */
}
