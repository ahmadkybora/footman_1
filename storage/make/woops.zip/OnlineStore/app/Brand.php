<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;

class Brand extends Model
{
    use Sluggable;
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */

    /**
     * this method for slug
     * author: ahmad montazeri 9/14/2020 3:02 PM
     * @return array
     */
    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    /**
     * This method sets relation between brands and product_categories.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function categories()
    {
        return $this->hasMany('App\ProductCategory', 'brand_id');
    }
}
