<?php
/**
 * Created by PhpStorm.
 * User: PC4
 * Date: 9/16/2020
 * Time: 3:04 PM
 */

namespace App\Layers\Models;


use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;

class Order extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Properties Part
    |--------------------------------------------------------------------------
    */
    protected static $env = [
        'connection' => null,
        'table' => null,
        'lock' => false,
        'user' => null,
        'refresh' => false,
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */
    /**
     * @param $connection
     * @param $table
     */
    protected function nonStaticInitializeOrder($connection, $table)
    {
        if (!Schema::connection($connection)->hasTable($table))
        {
            Schema::connection($connection)->create($table, function (Blueprint $table){
                $table->id();
                /*
                 * این فیلد در هر دو نوع جدول مختص کاربر و سیستم وجود دارد. منتهی در جدول سفارش مختص کاربر کد جدول تراکنش مختص کاربر و در جدول سفارشات سیستم کد تراکنش سیستم قرار دارد.
                 */
                $table->foreignId('transaction_id')->index()->nullable();

                $table->foreignId('system_order_id')->nullable(); // This field is defined just in orders_{x} tables for each user.

                /*
                 * خریدار بر روی محصول کلیک کرده و در صفحه اختصاصی آن تعداد کوپن مورد تقاضا را وارد کرده و سپس بر روی دکمه افزودن به سبد خرید کلیک میکند.
                 * سپس به این ستون کد محصول و تعداد کوپن های مورد تقاضا از آن محصول افزوده میشود.
                 * هر زمان که اقدام به پرداخت سبد خرید نماید از این ستون تعداد کوپن های هر محصول استخراج شده و مقادیر metadata در جدول کوپن ها پر میشود که به معنای خرید قطعی آن کوپن ها است.
                 *
                 * Data structure as serialized string:
                 *      [[p#, quantity], [p#, quantity], ...]
                 */
                $table->text('products');

                $table->decimal('price', 10, 3); // Total price of order.

                /*
                 * در صورتیکه وضعیت سفارش بر روی PENDING باشد. سفارش در سبد خرید کاربر نیز علاوه بر لیست سفارشات نمایش داده خواهد شد.
                 */
                $table->enum('state', ['PAID', 'CANCELED', 'PENDING'])->nullable();

                $table->dateTime('stated_at')->nullable();
                $table->timestamps();
            });
        }
    }
    /**
     * @param $connection
     * @param $table
     */
    protected function staticInitializeOrder($connection, $table)
    {
        if (!Schema::connection($connection)->hasTable($table))
        {
            Schema::connection($connection)->create($table, function (Blueprint $table){
                $table->id();
                /*
                 * این فیلد در هر دو نوع جدول مختص کاربر و سیستم وجود دارد. منتهی در جدول سفارش مختص کاربر کد جدول تراکنش مختص کاربر و در جدول سفارشات سیستم کد تراکنش سیستم قرار دارد.
                 */
                $table->foreignId('transaction_id')->index()->nullable();

                $table->foreignId('system_order_id')->nullable(); // This field is defined just in orders_{x} tables for each user.

                /*
                 * خریدار بر روی محصول کلیک کرده و در صفحه اختصاصی آن تعداد کوپن مورد تقاضا را وارد کرده و سپس بر روی دکمه افزودن به سبد خرید کلیک میکند.
                 * سپس به این ستون کد محصول و تعداد کوپن های مورد تقاضا از آن محصول افزوده میشود.
                 * هر زمان که اقدام به پرداخت سبد خرید نماید از این ستون تعداد کوپن های هر محصول استخراج شده و مقادیر metadata در جدول کوپن ها پر میشود که به معنای خرید قطعی آن کوپن ها است.
                 *
                 * Data structure as serialized string:
                 *      [[p#, quantity], [p#, quantity], ...]
                 */
                $table->text('products');

                $table->decimal('price', 10, 3); // Total price of order.

                /*
                 * در صورتیکه وضعیت سفارش بر روی PENDING باشد. سفارش در سبد خرید کاربر نیز علاوه بر لیست سفارشات نمایش داده خواهد شد.
                 */
                $table->enum('state', ['PAID', 'CANCELED', 'PENDING'])->nullable();

                $table->dateTime('stated_at')->nullable();
                $table->timestamps();
            });
        }
    }

    public function save(array $options = [])
    {
        if (self::$env['lock'])
            $this->nonStaticInitializeOrder('account', 'orders_' . self::$env['user']->id);

        self::$env['refresh'] = true;
        return parent::save($options); // TODO: Change the autogenerated stub
    }

    /**
     * This methods used when calling the non static method 'owner'.
     *
     * @param null $connection
     * @param null $table
     * @return $this
     */
    protected function nonStaticForUser($user, $refresh = false)
    {
        if (is_a($user, 'App\User') and $user)
        {
            self::$env['connection'] = 'account';
            self::$env['table'] = 'orders_' . $user->id;
            self::$env['lock'] = true;
            self::$env['user'] = $user;
        }
        else
        {
            $user = User::findOrFail($user);
            self::$env['connection'] = 'account';
            self::$env['table'] = 'orders_' . $user->id;
            self::$env['lock'] = true;
            self::$env['user'] = $user;
        }

        $this->nonStaticInitializeOrder('account', 'orders_' . self::$env['user']->id);
        if (self::$env['refresh'])
        {
            /*
             * Method 1.
             */
            /*$user_transaction = new Transaction();
            //$user_transaction->amount = request()->input('amount');
            $user_transaction->amount = $this->amount;
            //$user_transaction->transaction_code = request()->input('serial');
            $user_transaction->transaction_code = $this->transaction_code;
            return $user_transaction->forUser($user);*/

            /*
             * Method 2.
             */
            // Check for update.
            $instance = Order::where('system_order_id', $this->id)->first();
            if ($instance)
            {
                $instance->products = $this->products;
                $instance->price = $this->price;
                $instance->state = $this->state;
                return $instance;
            }
            // Check for insert.
            else
            {
                $newInstance = $this->newInstance();
                $newInstance->products = serialize($this->items);
                $newInstance->price = $this->price;
                $newInstance->state = $this->state;
                $newInstance->system_order_id = $this->id;
                return $newInstance;
            }
        }

        /*
         * The below codes (A and B)are equivalent together.
         */
        return $this; // Code A
        //return $this->newQuery(); // Code B. The save() chained method does not work.
    }
    /**
     * This methods used when calling the static method 'owner'.
     *
     * @param null $connection
     * @param null $table
     * @return TransactionLayer
     */
    protected static function staticForUser($user, $refresh = false)
    {
        if (is_a($user, 'App\User') and $user)
        {
            self::$env['connection'] = 'account';
            self::$env['table'] = 'orders_' . $user->id;
            self::$env['lock'] = true;
            self::$env['user'] = $user;
        }
        else
        {
            $user = User::findOrFail($user);
            self::$env['connection'] = 'account';
            self::$env['table'] = 'orders_' . $user->id;
            self::$env['lock'] = true;
            self::$env['user'] = $user;
        }

        self::staticInitializeOrder('account', 'transactions_' . self::$env['user']->id);
        /*
         * The below codes (A and B)are equivalent together.
         */
        return new self; // Code A
        //return (new self)->newQuery(); // Code B. The save() chained method does not work.
    }

    /**
     * This is a PHP magic method for calling non static methods.
     *
     * @param string $method
     * @param array $parameters
     * @return mixed
     */
    public function __call($method, $parameters)
    {
        switch ($method)
        {
            case 'forUser':
                return call_user_func([$this, 'nonStaticForUser'], $parameters[0] ?? null, $parameters[1] ?? null);
                break;
        }

        return parent::__call($method, $parameters); // TODO: Change the autogenerated stub
    }
    /**
     * This is a PHP magic method for calling static methods.
     *
     * @param string $method
     * @param array $parameters
     * @return mixed
     */
    public static function __callStatic($method, $parameters)
    {
        switch ($method)
        {
            case 'forUser':
                return call_user_func([new self, 'staticForUser'], $parameters[0] ?? null/*, $parameters[1] ?? null*/);
                break;
        }

        return parent::__callStatic($method, $parameters); // TODO: Change the autogenerated stub
    }

    /**
     * Transaction model has many table.
     * Each buyer user has own self orders table.
     * This method changes the Transaction model's table according to buyer user.
     *
     * @param $table
     * @return string
     */
    public function getTable()
    {
        if (self::$env['lock'])
            $this->setTable(self::$env['table']);

        /*if (Auth::check() and !Auth::user()->isAdmin())
            $this->setTable('orders_' . Auth::id());*/

        /*
         * Attention: We must checks the connection's table's prefix.
         */
        return parent::getTable(); // TODO: Change the autogenerated stub
    }

    /**
     * This methods changes the connection (database)for each buyer user dynamically.
     *
     * @return string
     */
    public function getConnection()
    {
        if (self::$env['lock'])
            $this->setConnection(self::$env['connection']);

        /*if (Auth::check() and !Auth::user()->isAdmin())
            $this->setConnection('account');*/

        return parent::getConnection(); // TODO: Change the autogenerated stub
    }
}
