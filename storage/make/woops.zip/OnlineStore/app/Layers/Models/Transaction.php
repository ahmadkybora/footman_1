<?php
/**
 * Created by PhpStorm.
 * User: PC4
 * Date: 9/7/2020
 * Time: 1:31 PM
 */

namespace App\Layers\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;

class Transaction extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Properties Part
    |--------------------------------------------------------------------------
    */
    protected static $env = [
        'connection' => null,
        'table' => null,
        'lock' => false,
        'user' => null,
        'refresh' => false,
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */
    /**
     * Initialize the transaction of specific user as none static usage.
     *
     * @param $connection
     * @param $table
     */
    protected function nonStaticInitializeTransaction($connection, $table)
    {
        if (!Schema::connection($connection)->hasTable($table))
        {
            Schema::connection($connection)->create($table, function (Blueprint $table){
                $table->id();
                $table->unsignedInteger('transaction_code')->unique();
                $table->decimal('amount');
                $table->foreignId('system_transaction_id')->nullable(); // This field is defined just in transactions_{x} tables for each user.

                /*
                 * System scheduled robot checks the transactions every special period (for example every night)and performs the related operations and sets the confirmed_at.
                 *
                 * زمانیکه خریدار پرداختی را انجام بدهد، یک رکورد تراکنش به میزان پرداخت کاربر به جدول transactions که مرتبط با سیستم است اضافه میشود. فیلد confirmed_at این رکورد در لحظه ثبت پر میشود و به کیف پول سیستم مبلغ اضافه میشود.
                 * سپس یک رکورد دیگر هم در همین جدول ایجاد میشود که از نوع پرداختی است و فیلد confirmed_at آن null خواهد. این فیلد هم برای گزارشات ادمین است که مشخص کند چقدر واریزی قرار است انجام شود و هم به عنوان تراکنش واریز حق فروشنده.
                 * پس از اجرای موفق دو عملیات فوق، مقدار پرداختی کاربر منهای سود شرکت به عنوان یک رکورد تراکنش به جدول تراکنش های مختص فروشنده اضافه میشود. فیلد confirmed_at این رکورد null خواهد بود و فیلد system_transaction_id آن برابر با id تراکنش فوق خواهد بود.
                 * سپس ربات زمانبندی شده سیستم در بازه های مشخصی از زمان تراکنش ها را بررسی میکند و تراکنش های مختص فروشنده را تایید کرده و از طریق فیلد system_transaction_id تراکنش های مرتبط با این تراکنش ها را در جدول تراکنشهای سیستم تایید میکند و در نهایت مبلغ تایید شده از کیف پول سیستم کسر شده و به کیف پول فروشنده اضافه میگردد.
                 *
                 */
                $table->dateTime('confirmed_at')->nullable();

                /*
                 * Dictionary:
                 *      DCU: Decreasing Cash Of User
                 *      ICU: Increasing Cash Of User
                 *
                 * CHECKOUT: DCU.
                 * CHARGE: ICU.
                 */
                $table->enum('type', ['CHARGE', 'CHECKOUT', 'SELL', 'BUY'])->nullable(); // The reason of transaction.

                $table->string('receipt_uri')->nullable();
                //$table->boolean('cashed_in'); // This field is defined just in transactions_{x} tables for each user.

                $table->timestamps();

            });
        }
    }
    /**
     * Initialize the transaction of specific user as static usage.
     *
     * @param $connection
     * @param $table
     */
    protected static function staticInitializeTransaction($connection, $table)
    {
        if (!Schema::connection($connection)->hasTable($table))
        {
            Schema::connection($connection)->create($table, function (Blueprint $table){
                $table->id();
                $table->unsignedInteger('transaction_code')->unique();
                $table->decimal('amount');
                $table->foreignId('system_transaction_id')->nullable(); // This field is defined just in transactions_{x} tables for each user.

                /*
                 * System scheduled robot checks the transactions every special period (for example every night)and performs the related operations and sets the confirmed_at.
                 *
                 * زمانیکه خریدار پرداختی را انجام بدهد، یک رکورد تراکنش به میزان پرداخت کاربر به جدول transactions که مرتبط با سیستم است اضافه میشود. فیلد confirmed_at این رکورد در لحظه ثبت پر میشود و به کیف پول سیستم مبلغ اضافه میشود.
                 * سپس یک رکورد دیگر هم در همین جدول ایجاد میشود که از نوع پرداختی است و فیلد confirmed_at آن null خواهد. این فیلد هم برای گزارشات ادمین است که مشخص کند چقدر واریزی قرار است انجام شود و هم به عنوان تراکنش واریز حق فروشنده.
                 * پس از اجرای موفق دو عملیات فوق، مقدار پرداختی کاربر منهای سود شرکت به عنوان یک رکورد تراکنش به جدول تراکنش های مختص فروشنده اضافه میشود. فیلد confirmed_at این رکورد null خواهد بود و فیلد system_transaction_id آن برابر با id تراکنش فوق خواهد بود.
                 * سپس ربات زمانبندی شده سیستم در بازه های مشخصی از زمان تراکنش ها را بررسی میکند و تراکنش های مختص فروشنده را تایید کرده و از طریق فیلد system_transaction_id تراکنش های مرتبط با این تراکنش ها را در جدول تراکنشهای سیستم تایید میکند و در نهایت مبلغ تایید شده از کیف پول سیستم کسر شده و به کیف پول فروشنده اضافه میگردد.
                 *
                 */
                $table->dateTime('confirmed_at')->nullable();

                /*
                 * Dictionary:
                 *      DCU: Decreasing Cash Of User
                 *      ICU: Increasing Cash Of User
                 *
                 * CHECKOUT: DCU.
                 * CHARGE: ICU.
                 */
                $table->enum('type', ['CHARGE', 'CHECKOUT', 'SELL', 'BUY'])->nullbale(); // The reason of transaction.

                $table->string('receipt_uri')->nullable();
                //$table->boolean('cashed_in'); // This field is defined just in transactions_{x} tables for each user.

                $table->timestamps();

            });
        }
    }

    public function save(array $options = [])
    {
        if (self::$env['lock'])
            $this->nonStaticInitializeTransaction('account', 'transactions_' . self::$env['user']->id);

        self::$env['refresh'] = true;
        return parent::save($options); // TODO: Change the autogenerated stub
    }

    /**
     * This methods used when calling the non static method 'owner'.
     *
     * @param null $connection
     * @param null $table
     * @return $this
     */
    protected function nonStaticForUser($user, $refresh = false)
    {
        if (is_a($user, 'App\User') and $user)
        {
            self::$env['connection'] = 'account';
            self::$env['table'] = 'transactions_' . $user->id;
            self::$env['lock'] = true;
            self::$env['user'] = $user;
        }
        else
        {
            $user = User::findOrFail($user);
            self::$env['connection'] = 'account';
            self::$env['table'] = 'transactions_' . $user->id;
            self::$env['lock'] = true;
            self::$env['user'] = $user;
        }

        $this->nonStaticInitializeTransaction('account', 'transactions_' . self::$env['user']->id);
        if (self::$env['refresh'])
        {
            /*
             * Method 1.
             */
            /*$user_transaction = new Transaction();
            //$user_transaction->amount = request()->input('amount');
            $user_transaction->amount = $this->amount;
            //$user_transaction->transaction_code = request()->input('serial');
            $user_transaction->transaction_code = $this->transaction_code;
            return $user_transaction->forUser($user);*/

            /*
             * Method 2.
             */
            // Check for update.
            $instance = Transaction::where('system_transaction_id', $this->id)->first();
            if ($instance)
            {
                $instance->transaction_code = $this->transaction_code;
                $instance->amount = $this->amount;
                return $instance;
            }
            // Check for insert.
            else
            {
                $newInstance = $this->newInstance();
                $newInstance->transaction_code = $this->transaction_code;
                $newInstance->amount = $this->amount;
                $newInstance->system_transaction_id = $this->id;
                $newInstance->receipt_uri = $this->receipt_uri;
                return $newInstance;
            }
        }

        /*
         * The below codes (A and B)are equivalent together.
         */
        return $this; // Code A
        //return $this->newQuery(); // Code B. The save() chained method does not work.
    }
    /**
     * This methods used when calling the static method 'owner'.
     *
     * @param null $connection
     * @param null $table
     * @return TransactionLayer
     */
    protected static function staticForUser($user, $refresh = false)
    {
        if (is_a($user, 'App\User') and $user)
        {
            self::$env['connection'] = 'account';
            self::$env['table'] = 'transactions_' . $user->id;
            self::$env['lock'] = true;
            self::$env['user'] = $user;
        }
        else
        {
            $user = User::findOrFail($user);
            self::$env['connection'] = 'account';
            self::$env['table'] = 'transactions_' . $user->id;
            self::$env['lock'] = true;
            self::$env['user'] = $user;
        }

        self::staticInitializeTransaction('account', 'transactions_' . self::$env['user']->id);
        /*
         * The below codes (A and B)are equivalent together.
         */
        return new self; // Code A
        //return (new self)->newQuery(); // Code B. The save() chained method does not work.
    }

    /**
     * This is a PHP magic method for calling non static methods.
     *
     * @param string $method
     * @param array $parameters
     * @return mixed
     */
    public function __call($method, $parameters)
    {
        switch ($method)
        {
            case 'forUser':
                return call_user_func([$this, 'nonStaticForUser'], $parameters[0] ?? null, $parameters[1] ?? null);
                break;
        }

        return parent::__call($method, $parameters); // TODO: Change the autogenerated stub
    }
    /**
     * This is a PHP magic method for calling static methods.
     *
     * @param string $method
     * @param array $parameters
     * @return mixed
     */
    public static function __callStatic($method, $parameters)
    {
        switch ($method)
        {
            case 'forUser':
                return call_user_func([new self, 'staticForUser'], $parameters[0] ?? null/*, $parameters[1] ?? null*/);
                break;
        }

        return parent::__callStatic($method, $parameters); // TODO: Change the autogenerated stub
    }

    /**
     * Transaction model has many table.
     * Each buyer user has own self orders table.
     * This method changes the Transaction model's table according to buyer user.
     *
     * @param $table
     * @return string
     */
    public function getTable()
    {
        if (self::$env['lock'])
            $this->setTable(self::$env['table']);

        /*if (Auth::check() and !Auth::user()->isAdmin())
            $this->setTable('transactions_' . Auth::id());*/

        /*
         * Attention: We must checks the connection's table's prefix.
         */
        return parent::getTable(); // TODO: Change the autogenerated stub
    }

    /**
     * This methods changes the connection (database)for each buyer user dynamically.
     *
     * @return string
     */
    public function getConnection()
    {
        if (self::$env['lock'])
            $this->setConnection(self::$env['connection']);

        /*if (Auth::check() and !Auth::user()->isAdmin())
            $this->setConnection('account');*/

        return parent::getConnection(); // TODO: Change the autogenerated stub
    }
}
