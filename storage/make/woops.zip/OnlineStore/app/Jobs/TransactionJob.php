<?php

namespace App\Jobs;

use App\Transaction;
use App\Wallet;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class TransactionJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $data;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        DB::transaction(function (){
            foreach ($this->data as $id)
            {
                $transaction = Transaction::find($id);
                $transaction->confirmed_at = Carbon::now();
                $transaction->save();

                $wallet = Wallet::firstOrNew(['owner_id'=>$transaction->user_id]);
                $wallet->cash += $transaction->amount;
                $wallet->owner_id = $transaction->user_id;
                $wallet->save();
            }
        });
    }
}
