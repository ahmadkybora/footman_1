<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Region extends Model
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'country_id',
    ];

    /**
     * This attribute revoke timestamps attributes.
     *
     * @var bool
     */
    public $timestamps = false;

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    /**
     * This method sets relation between regions and countries.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function country()
    {
        /*
         * "Has Regions" relation is "1 to Many"
         * Region is "Many" side
         * Country (1)<===Has City===>(N) Region
         */
        return $this->belongsTo('App\Country', 'country_id');
    }

    /**
     * This method sets relation between regions and cities.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function cities()
    {
        /*
         * "Has City" relation is "1 to Many"
         * Province is "1" side
         * Province (1)<===Has City===>(N) City
         */
        return $this->hasMany('App\City', 'region_id');
    }
}
