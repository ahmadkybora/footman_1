<?php

namespace App\Policies;

use Illuminate\Auth\Access\HandlesAuthorization;
use App\ProductVoucher;
use App\User;

class ProductVoucherPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * Author: Mahtab Hakimzade
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->can('view-voucher') or true;
    }

    /**
     * Determine whether the user can view the model.
     *
     * Author: Mahtab Hakimzade
     *
     * @param  \App\User  $user
     * @param  \App\ProductVoucher  $productVoucher
     * @return mixed
     */
    public function view(User $user, ProductVoucher $productVoucher)
    {
        return $user->can('view-voucher') ? true : $user->id == $productVoucher->product->user_id;
    }

    /**
     * Determine whether the user can create models.
     *
     * Author: Mahtab Hakimzade
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user, ProductVoucher $productVoucher)
    {
        return $user->can('create-voucher') ? true : $user->id == $productVoucher->product->user_id;
    }

    /**
     * Determine whether the user can update the model.
     *
     * Author: Mahtab Hakimzade
     *
     * @param  \App\User  $user
     * @param  \App\ProductVoucher  $productVoucher
     * @return mixed
     */
    public function update(User $user, ProductVoucher $productVoucher)
    {
        return $user->can('update-voucher') ? true : $user->id == $productVoucher->product->user_id;
    }

    /**
     * Determine whether the user can delete the model.
     *
     * Author: Mahtab Hakimzade
     *
     * @param  \App\User  $user
     * @param  \App\ProductVoucher  $productVoucher
     * @return mixed
     */
    public function delete(User $user, ProductVoucher $productVoucher)
    {
        return $user->can('delete-voucher') ? true : $user->id == $productVoucher->product->user_id;
    }

    /**
     * Determine whether the user can restore the model.
     *
     * Author: Mahtab Hakimzade
     *
     * @param  \App\User  $user
     * @param  \App\ProductVoucher  $productVoucher
     * @return mixed
     */
    public function restore(User $user, ProductVoucher $productVoucher)
    {
        return false;
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * Author: Mahtab Hakimzade

     * @param  \App\User  $user
     * @param  \App\ProductVoucher  $productVoucher
     * @return mixed
     */
    public function forceDelete(User $user, ProductVoucher $productVoucher)
    {
        return false;
    }
}
