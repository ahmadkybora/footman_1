<?php

namespace App\Policies;

use Illuminate\Auth\Access\HandlesAuthorization;
use App\SellerTicket;
use App\User;

class SellerTicketPolicy
{
    use HandlesAuthorization;

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return true;
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * Determine whether the user can view the model.
     *
     * @param  \App\User  $user
     * @param  \App\SellerTicket  $sellerTicket
     * @return mixed
     */
    public function view(User $user, SellerTicket $sellerTicket)
    {
        return ($user->id == $sellerTicket->buyer_id or $user->id == $sellerTicket->seller_id);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * Determine whether the user can create models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        return true;
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * Determine whether the user can update the model.
     *
     * @param  \App\User  $user
     * @param  \App\SellerTicket  $sellerTicket
     * @return mixed
     */
    public function update(User $user, SellerTicket $sellerTicket)
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * Determine whether the user can delete the model.
     *
     * @param  \App\User  $user
     * @param  \App\SellerTicket  $sellerTicket
     * @return mixed
     */
    public function delete(User $user, SellerTicket $sellerTicket)
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * Determine whether the user can restore the model.
     *
     * @param  \App\User  $user
     * @param  \App\SellerTicket  $sellerTicket
     * @return mixed
     */
    public function restore(User $user, SellerTicket $sellerTicket)
    {
        return true;
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * @param User $user
     * @param SellerTicket $sellerTicket
     * @return bool
     */
    public function restoreDetails(User $user, SellerTicket $sellerTicket)
    {
        return ($user->id == $sellerTicket->buyer_id or $user->id == $sellerTicket->seller_id);
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * @param User $user
     * @param SellerTicket $sellerTicket
     * @return bool
     */
    public function indexDetails(User $user, SellerTicket $sellerTicket)
    {
        return $user->id == $sellerTicket->buyer_id;
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\User  $user
     * @param  \App\SellerTicket  $sellerTicket
     * @return mixed
     */
    public function forceDelete(User $user, SellerTicket $sellerTicket)
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: ahmad montazeri.
     * Created At: 10/22/2020 10:30Am.
     * Modified At:.
     *
     * @param User $user
     * @param SellerTicket $sellerTicket
     * @return bool
     */
    public function details(User $user, SellerTicket $sellerTicket)
    {
        return $user->id == $sellerTicket->buyer_id;
    }

}
