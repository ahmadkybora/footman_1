<?php

namespace App\Policies;

use Illuminate\Auth\Access\HandlesAuthorization;
use App\Transaction;
use App\User;

class TransactionPolicy
{
    use HandlesAuthorization;

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 10/03/2020 13:57.
     * Modified At:
     *
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->can('view-transactions');
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 10/03/2020 13:57.
     * Modified At:
     *
     * Determine whether the user can view the model.
     *
     * @param  \App\User  $user
     * @param  \App\Transaction  $transaction
     * @return mixed
     */
    public function view(User $user, Transaction $transaction)
    {
        return $user->can('view-transaction') or $user->id == $transaction->user_id;
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 10/03/2020 13:57.
     * Modified At:
     *
     * Determine whether the user can create models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user, int $user_id = null)
    {
        return $user->can('create-transaction') or $user->id == $user_id;
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 10/03/2020 13:57.
     * Modified At:
     *
     * Determine whether the user can update the model.
     *
     * @param  \App\User  $user
     * @param  \App\Transaction  $transaction
     * @return mixed
     */
    public function update(User $user, Transaction $transaction, int $user_id = null)
    {
        return !is_null($user_id) ? ($user->id == $user_id or $user->can('update-transaction')) : $user->id == $transaction->user_id;
    }

    /**
     * Algorithm: elyas dehghan.
     * Development: ahmad montazeri.
     * Created At: 10/03/2020 13:57.
     * Modified At:
     *
     * Determine whether the user can delete the model.
     *
     * @param  \App\User  $user
     * @param  \App\Transaction  $transaction
     * @return mixed
     */
    public function delete(User $user, Transaction $transaction)
    {
        return $user->can('delete-transaction') or $user->id == $transaction->user_id;
    }

    /**
     * Determine whether the user can restore the model.
     *
     *
     * @param  \App\User  $user
     * @param  \App\Transaction  $transaction
     * @return mixed
     */
    public function restore(User $user, Transaction $transaction)
    {
        return false;
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     *
     * @param  \App\User  $user
     * @param  \App\Transaction  $transaction
     * @return mixed
     */
    public function forceDelete(User $user, Transaction $transaction)
    {
        return false;
    }
}
