<?php

namespace App\Policies;

use App\TicketDetail;
use Illuminate\Auth\Access\HandlesAuthorization;
use App\Ticket;
use App\User;

class TicketPolicy
{
    use HandlesAuthorization;

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/11/2020 14:00Am.
     * Modified At: 10/11/2020 14:00Am.
     *
     * Determine whether the user can view any models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        return $user->can('view-tickets') or true;
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/11/2020 12:00Am.
     * Modified At: 10/11/2020 12:00Am.
     *
     * Determine whether the user can view the model.
     *
     * @param  \App\User  $user
     * @param  \App\Ticket  $ticket
     * @return mixed
     */
    public function view(User $user, Ticket $ticket)
    {
        return $user->can('view-ticket') ? true : $user->id == $ticket->user_id;
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        return $user->can('create-tickets') or true;
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\User  $user
     * @param  \App\Ticket  $ticket
     * @return mixed
     */
    public function update(User $user, Ticket $ticket)
    {
        //
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\User  $user
     * @param  \App\Ticket  $ticket
     * @return mixed
     */
    public function delete(User $user, Ticket $ticket)
    {
        //
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param  \App\User  $user
     * @param  \App\Ticket  $ticket
     * @return mixed
     */
    public function restore(User $user, Ticket $ticket)
    {
        return true;
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/11/2020 12:00Am.
     * Modified At: 10/11/2020 12:00Am.
     *
     * This method is from store details in ticket
     *
     * @param User $user
     * @param Ticket $ticket
     * @return bool
     */
    public function restoreDetails(User $user , Ticket $ticket)
    {
        return $user->can('replie-ticket') ? true : $user->id == $ticket->user_id;
    }

    /**
     * @param User $user
     * @param Ticket $ticket
     * @return bool
     */
    public function indexDetails(User $user , Ticket $ticket)
    {
        return $user->can('view-ticket') ? true : $user->id == $ticket->user_id;
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\User  $user
     * @param  \App\Ticket  $ticket
     * @return mixed
     */
    public function forceDelete(User $user, Ticket $ticket)
    {
        //
    }

    /**
     * Algorithm: Sina Khaghani.
     * Development: Sina Khaghani.
     * Created At: 10/11/2020 12:00Am.
     * Modified At: 10/11/2020 12:00Am.
     *
     * This method is from show details in tickets
     *
     * @param User $user
     * @param Ticket $ticket
     * @return bool
     */
    public function details(User $user, Ticket $ticket)
    {
        return $user->can('view-ticket') ? true : $user->id == $ticket->user_id;
    }

}
