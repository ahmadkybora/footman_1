<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;

class ProductCategory extends Model
{
    use Sluggable;
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'avatar_uri',
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'brand_id',
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */

    /**
     * this method for slug
     * author: ahmad montazeri
     * @return array
     */
    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    /**
     * This method sets relation between brands and product_categories.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function brand()
    {
        /*
         * "Has City" relation is "1 to Many"
         * City is "Many" side
         * Region (1)<===Has City===>(N) City
         */
        return $this->belongsTo('App\Brand', 'brand_id');
    }

    public function products()
    {
        return $this->hasMany('App\Product', 'category_id');
    }
}
