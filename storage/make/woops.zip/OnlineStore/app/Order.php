<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use App\Layers\Models\Order as SystemOrder;
use Illuminate\Support\Facades\Schema;

class Order extends SystemOrder
{
    /*
    |--------------------------------------------------------------------------
    | Eloquent's Part
    |--------------------------------------------------------------------------
    */
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'price',
        'state',
        'stated_at',
        'products', // Accepts serialized string.
    ];

    /**
     * The attributes that are guarded from modifying with other database method except Eloquent ORM.
     *
     * @var array
     */
    protected $guarded = [
        'id',
        'user_id',
        //'buyer_order_id',
        'transaction_id',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'stated_at' => 'datetime',
    ];

    protected $appends = [
        'items',
    ];

    /*
    |--------------------------------------------------------------------------
    | Abilities Part
    |--------------------------------------------------------------------------
    */
    function __destruct()
    {
        if ($this->getTable() !== 'orders' and !$this->count())
        {
            Schema::connection(self::$env['connection'])->dropIfExists(self::$env['table']);
        }
    }

    public function getItemsAttribute()
    {
        return unserialize($this->attributes['products']);
    }

    /*
    |--------------------------------------------------------------------------
    | Relations Part
    |--------------------------------------------------------------------------
    */
    public function getProductsAttribute()
    {
        $products = [];
        foreach (unserialize($this->attributes['products']) as $product)
            $products[] = $product[0];

        return Product::with(['category', 'vouchers' => function ($query){
            $query->whereRaw('JSON_VALUE(`metadata`, "$.order_id") = ' . $this->id);
        }])->whereIn('id', $products)->get();
    }

    /**
     * This method sets relation between orders and users.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function owner()
    {
        return $this->belongsTo('App\User', 'user_id');
    }

    /**
     * This method sets relation between orders and transactions.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function transaction()
    {
        return $this->belongsTo('App\Transaction', 'transaction_id');
    }

    /**
     * This method sets relation between products and orders.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany|string
     */
    public function products()
    {
        $products = [];
        foreach (unserialize($this->attributes['products']) as $product)
            $products[] = $product[0];

        return Product::with(['category', 'vouchers' => function ($query){
            $query->whereRaw('JSON_VALUE(`metadata`, "$.order_id") = ' . $this->id);
        }])->whereIn('id', $products);

        /*if (Auth::user()->isAdmin())
            $table = 'order_product_' . $this->user_id;
        else
            $table =  'order_product_' . Auth::id();
        return $this->belongsToMany('App\Product', $table, 'order_id', 'product_id')->using('App\OrderProduct');*/
    }
}
