<?php
/**
 * Created by PhpStorm.
 * User: kybora
 * Date: 11/1/2020
 * Time: 10:32 PM
 */

namespace App\Models;
use App\Core\Model;

class User extends Model
{
    protected static $table = 'users';
}