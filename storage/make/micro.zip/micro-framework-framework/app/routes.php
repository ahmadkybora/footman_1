<?php

$router->get('', 'HomeController@index');